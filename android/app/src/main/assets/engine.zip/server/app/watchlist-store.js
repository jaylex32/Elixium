"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WatchlistStore = exports.DEFAULT_RELEASE_TYPES = exports.ALL_RELEASE_TYPES = void 0;
const fs_1 = require("fs");
const path_1 = __importDefault(require("path"));
const brand_1 = require("./brand");
exports.ALL_RELEASE_TYPES = ['album', 'ep', 'single', 'live', 'compilation'];
exports.DEFAULT_RELEASE_TYPES = ['album', 'ep'];
const defaultSchedule = () => ({
    enabled: false,
    mode: 'interval-days',
    intervalHours: 12,
    intervalDays: 1,
    weekdays: [1],
    monthDays: [1],
    hour: 8,
    minute: 0,
    lastRunAt: null,
    nextRunAt: null,
});
const defaultWatchlistData = () => ({
    version: 2,
    watchedArtists: [],
    watchedPlaylists: [],
    favoriteGenres: [],
    processedAlbums: [],
    processedTracks: [],
    candidates: [],
    playlistCandidates: [],
    schedules: {
        artists: defaultSchedule(),
        playlists: defaultSchedule(),
    },
    monitorHistory: [],
    releaseTypes: [...exports.DEFAULT_RELEASE_TYPES],
    discographies: {},
});
class WatchlistStore {
    constructor(filePath = path_1.default.resolve(process.cwd(), brand_1.WATCHLIST_DATA_FILE)) {
        this.filePath = filePath;
        this.data = this.load();
    }
    load() {
        if (!(0, fs_1.existsSync)(this.filePath)) {
            return defaultWatchlistData();
        }
        try {
            const parsed = JSON.parse((0, fs_1.readFileSync)(this.filePath, 'utf8'));
            return {
                ...defaultWatchlistData(),
                ...parsed,
                watchedArtists: Array.isArray(parsed?.watchedArtists) ? parsed.watchedArtists : [],
                watchedPlaylists: Array.isArray(parsed?.watchedPlaylists) ? parsed.watchedPlaylists : [],
                favoriteGenres: Array.isArray(parsed?.favoriteGenres) ? parsed.favoriteGenres : [],
                processedAlbums: Array.isArray(parsed?.processedAlbums) ? parsed.processedAlbums : [],
                processedTracks: Array.isArray(parsed?.processedTracks) ? parsed.processedTracks : [],
                candidates: Array.isArray(parsed?.candidates) ? parsed.candidates : [],
                playlistCandidates: Array.isArray(parsed?.playlistCandidates) ? parsed.playlistCandidates : [],
                releaseTypes: Array.isArray(parsed?.releaseTypes) ? parsed.releaseTypes : [...exports.DEFAULT_RELEASE_TYPES],
                schedules: {
                    artists: {
                        ...defaultSchedule(),
                        ...(parsed?.schedules?.artists || {}),
                    },
                    playlists: {
                        ...defaultSchedule(),
                        ...(parsed?.schedules?.playlists || {}),
                    },
                },
                monitorHistory: Array.isArray(parsed?.monitorHistory) ? parsed.monitorHistory : [],
            };
        }
        catch {
            return defaultWatchlistData();
        }
    }
    persist() {
        (0, fs_1.mkdirSync)(path_1.default.dirname(this.filePath), { recursive: true });
        (0, fs_1.writeFileSync)(this.filePath, JSON.stringify(this.data, null, 2));
    }
    getState() {
        return JSON.parse(JSON.stringify(this.data));
    }
    read() {
        return this.data;
    }
    update(mutator) {
        mutator(this.data);
        this.persist();
        return this.getState();
    }
    replace(nextState) {
        this.data = nextState;
        this.persist();
        return this.getState();
    }
}
exports.WatchlistStore = WatchlistStore;
exports.default = WatchlistStore;
