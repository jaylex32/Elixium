"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerMediaRoutes = void 0;
const got_1 = __importDefault(require("got"));
const adm_zip_1 = __importDefault(require("adm-zip"));
const stream_1 = require("stream");
const respond_1 = require("../respond");
const quality_1 = require("../quality");
const track_cache_1 = require("../track-cache");
const lyrics_1 = require("../lyrics");
const mimeFor = (extension) => (extension === 'flac' ? 'audio/flac' : 'audio/mpeg');
const setAudioHeaders = (res, contentType) => {
    res.setHeader('Accept-Ranges', 'bytes');
    res.setHeader('Content-Type', contentType);
    res.setHeader('Cache-Control', 'private, max-age=0, must-revalidate');
    res.setHeader('Access-Control-Expose-Headers', 'Content-Length, Content-Range, Accept-Ranges, X-Elixium-Stream, X-Elixium-Stream-Reason');
};
const serveBuffer = (req, res, buffer, contentType) => {
    const total = buffer.length;
    setAudioHeaders(res, contentType);
    const range = (0, track_cache_1.parseRange)(req.headers.range, total);
    if (range === null) {
        res.status(416);
        res.setHeader('Content-Range', `bytes */${total}`);
        res.end();
        return;
    }
    if (!range) {
        res.setHeader('Content-Length', String(total));
        if (req.method === 'HEAD') {
            res.status(200).end();
            return;
        }
        res.status(200).end(buffer);
        return;
    }
    const chunkSize = range.end - range.start + 1;
    res.status(206);
    res.setHeader('Content-Range', `bytes ${range.start}-${range.end}/${total}`);
    res.setHeader('Content-Length', String(chunkSize));
    if (req.method === 'HEAD') {
        res.end();
        return;
    }
    res.end(buffer.subarray(range.start, range.end + 1));
};
const proxyStream = (req, res, url, fallbackContentType) => {
    if (req.method === 'HEAD') {
        setAudioHeaders(res, fallbackContentType);
        res.status(200).end();
        return;
    }
    const range = req.headers.range;
    const upstream = got_1.default.stream(url, range ? { headers: { Range: range } } : {});
    const relay = new stream_1.PassThrough();
    upstream.on('response', (upstreamRes) => {
        if (upstreamRes.statusCode)
            res.status(upstreamRes.statusCode);
        setAudioHeaders(res, String(upstreamRes.headers['content-type'] || fallbackContentType));
        for (const header of ['content-length', 'content-range']) {
            const value = upstreamRes.headers[header];
            if (value)
                res.setHeader(header, String(value));
        }
    });
    const failUpstream = () => {
        if (!res.headersSent) {
            res.status(502).json({ ok: false, error: { code: 'upstream_error', message: 'Stream failed' } });
        }
        else {
            res.end();
        }
    };
    upstream.on('error', failUpstream);
    relay.on('error', failUpstream);
    res.on('close', () => {
        upstream.destroy();
        relay.destroy();
    });
    upstream.pipe(relay).pipe(res);
};
const registerMediaRoutes = ({ app, io, basePath, deezer, qobuz, initDeezerForDownload, refreshDeezerSession, initQobuzForSearch, initQobuzForDownload, resolveYtMusicStream, resolveYtMusicLyrics, }) => {
    const materializeDeezerTrack = async (id, quality) => {
        const codes = (0, quality_1.deezerFormatFallbacks)(quality);
        for (const formatCode of codes) {
            const cached = track_cache_1.trackBufferCache.get(`deezer:${id}:${formatCode}`);
            if (cached)
                return cached;
        }
        const attempt = async () => {
            const trackInfo = await deezer.getTrackInfo(id);
            for (const formatCode of codes) {
                try {
                    const urlInfo = await deezer.getTrackDownloadUrl(trackInfo, formatCode);
                    if (!urlInfo)
                        continue;
                    const raw = await (0, got_1.default)(urlInfo.trackUrl).buffer();
                    const buffer = urlInfo.isEncrypted ? deezer.decryptDownload(raw, String(trackInfo.SNG_ID)) : raw;
                    const contentType = mimeFor(formatCode === 9 ? 'flac' : 'mp3');
                    track_cache_1.trackBufferCache.set(`deezer:${id}:${formatCode}`, buffer, contentType);
                    return { buffer, contentType };
                }
                catch {
                }
            }
            return undefined;
        };
        await initDeezerForDownload();
        const first = await attempt().catch(() => undefined);
        if (first)
            return first;
        try {
            await refreshDeezerSession();
        }
        catch {
        }
        return (await attempt().catch(() => undefined)) ?? undefined;
    };
    const resolveQobuzUrl = async (id, quality) => {
        try {
            await initQobuzForDownload();
        }
        catch {
            await initQobuzForSearch();
        }
        for (const formatCode of (0, quality_1.qobuzFormatFallbacks)(quality)) {
            try {
                const urlInfo = await qobuz.getTrackDownloadUrl(Number(id), formatCode);
                if (urlInfo)
                    return urlInfo;
            }
            catch {
            }
        }
        return undefined;
    };
    const streamHandler = (0, respond_1.route)(async (req, res) => {
        if (String(req.query.service ?? '').toLowerCase() === 'ytmusic') {
            const videoId = (0, respond_1.requireString)(req.params.id ?? req.query.id, 'id');
            if (!resolveYtMusicStream)
                throw respond_1.ApiError.notFound('YouTube Music is not available on this server');
            let resolved = null;
            try {
                resolved = await resolveYtMusicStream(videoId);
            }
            catch (error) {
                if (error?.kind === 'login-required') {
                    throw new respond_1.ApiError('unauthorized', 'YouTube will not play this without a signed-in session. Upload a cookies.txt in Settings.');
                }
                throw respond_1.ApiError.notFound(error?.message || 'That track could not be played');
            }
            if (!resolved)
                throw respond_1.ApiError.notFound('That track could not be played');
            res.setHeader('X-Elixium-Stream', 'full');
            proxyStream(req, res, resolved.url, resolved.mimeType || 'audio/mp4');
            return;
        }
        const service = (0, respond_1.parseService)(req.query.service);
        const id = (0, respond_1.requireString)(req.params.id ?? req.query.id, 'id');
        const quality = String(req.query.quality || (0, quality_1.defaultQualityFor)(service));
        if (service === 'deezer') {
            try {
                const materialized = await materializeDeezerTrack(id, quality);
                if (materialized) {
                    res.setHeader('X-Elixium-Stream', 'full');
                    serveBuffer(req, res, materialized.buffer, materialized.contentType);
                    return;
                }
            }
            catch {
            }
            const info = await deezer.getTrackInfoPublicApi(id).catch(() => undefined);
            const previewUrl = info?.preview || info?.HREF;
            if (!previewUrl)
                throw respond_1.ApiError.notFound('Track not available');
            res.setHeader('X-Elixium-Stream', 'preview');
            res.setHeader('X-Elixium-Stream-Reason', 'deezer-auth-unavailable');
            proxyStream(req, res, previewUrl, 'audio/mpeg');
            return;
        }
        const urlInfo = await resolveQobuzUrl(id, quality);
        if (!urlInfo)
            throw respond_1.ApiError.notFound('Track not available');
        res.setHeader('X-Elixium-Stream', 'full');
        proxyStream(req, res, urlInfo.url, urlInfo.mime_type || 'audio/flac');
    });
    app.get(`${basePath}/tracks/:id/stream`, streamHandler);
    app.head(`${basePath}/tracks/:id/stream`, streamHandler);
    app.get(`${basePath}/tracks/:id/file`, (0, respond_1.route)(async (req, res) => {
        const service = (0, respond_1.parseService)(req.query.service);
        const id = (0, respond_1.requireString)(req.params.id, 'id');
        const quality = String(req.query.quality || (0, quality_1.defaultQualityFor)(service));
        const extension = (0, quality_1.extensionFor)(service, quality);
        if (service === 'deezer') {
            await initDeezerForDownload();
            const trackInfo = await deezer.getTrackInfo(id);
            const urlInfo = await deezer.getTrackDownloadUrl(trackInfo, (0, quality_1.deezerFormatCode)(quality));
            if (!urlInfo)
                throw respond_1.ApiError.notFound('Track not available');
            const raw = await (0, got_1.default)(urlInfo.trackUrl).buffer();
            const decrypted = urlInfo.isEncrypted ? deezer.decryptDownload(raw, String(trackInfo.SNG_ID)) : raw;
            const tagged = await deezer.addTrackTags(decrypted, trackInfo, 1000);
            const filename = `${(0, quality_1.safeFilename)(trackInfo.ART_NAME)} - ${(0, quality_1.safeFilename)(trackInfo.SNG_TITLE)}.${extension}`;
            res.setHeader('Content-Type', mimeFor(extension));
            res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
            res.setHeader('Content-Length', String(tagged.length));
            res.send(tagged);
            return;
        }
        await initQobuzForSearch();
        const urlInfo = await qobuz.getTrackDownloadUrl(Number(id), (0, quality_1.qobuzFormatCode)(quality));
        if (!urlInfo)
            throw respond_1.ApiError.notFound('Track not available');
        const raw = await (0, got_1.default)(urlInfo.url, { responseType: 'buffer' }).then((r) => r.body);
        const meta = await qobuz.getTrackInfo(Number(id));
        const tagged = await qobuz.addTrackTags(raw, meta, 1000);
        const actualExt = urlInfo.mime_type?.includes('mpeg') ? 'mp3' : 'flac';
        const filename = `${(0, quality_1.safeFilename)(meta?.performer?.name)} - ${(0, quality_1.safeFilename)(meta?.title)}.${actualExt}`;
        res.setHeader('Content-Type', urlInfo.mime_type || mimeFor(actualExt));
        res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
        res.setHeader('Content-Length', String(tagged.length));
        res.send(tagged);
    }));
    app.post(`${basePath}/downloads/archive`, (0, respond_1.route)(async (req, res) => {
        const service = (0, respond_1.parseService)(req.body?.service);
        const trackIds = req.body?.trackIds ?? req.body?.itemIds;
        const quality = String(req.body?.quality || (0, quality_1.defaultQualityFor)(service));
        const structure = String(req.body?.structure || 'album');
        const jobId = req.body?.jobId ? String(req.body.jobId) : undefined;
        if (!Array.isArray(trackIds) || trackIds.length === 0) {
            throw respond_1.ApiError.badRequest('trackIds must be a non-empty array');
        }
        const zip = new adm_zip_1.default();
        const pad2 = (n) => String(Math.max(0, n)).padStart(2, '0');
        let added = 0;
        const failed = [];
        const reportProgress = (index, label) => {
            if (!jobId)
                return;
            io.emit('downloadProgress', {
                itemId: jobId,
                itemStatus: 'downloading',
                itemProgress: Math.round(((index + 1) / trackIds.length) * 100),
                currentTrack: label,
                current: index + 1,
                total: trackIds.length,
            });
        };
        if (service === 'deezer') {
            await initDeezerForDownload();
            const formatCode = (0, quality_1.deezerFormatCode)(quality);
            const extension = formatCode === 9 ? 'flac' : 'mp3';
            for (let index = 0; index < trackIds.length; index++) {
                const id = String(trackIds[index]);
                try {
                    const trackInfo = await deezer.getTrackInfo(id);
                    const urlInfo = await deezer.getTrackDownloadUrl(trackInfo, formatCode);
                    if (!urlInfo) {
                        failed.push(id);
                        continue;
                    }
                    const raw = await (0, got_1.default)(urlInfo.trackUrl).buffer();
                    const decrypted = urlInfo.isEncrypted ? deezer.decryptDownload(raw, String(trackInfo.SNG_ID)) : raw;
                    const tagged = await deezer.addTrackTags(decrypted, trackInfo, 1000);
                    const folder = structure === 'album' ? (0, quality_1.safeFilename)(trackInfo.ALB_TITLE) : '';
                    const name = `${pad2(Number(trackInfo.TRACK_NUMBER) || 0)} ${(0, quality_1.safeFilename)(trackInfo.ART_NAME)} - ${(0, quality_1.safeFilename)(trackInfo.SNG_TITLE)}.${extension}`;
                    zip.addFile(folder ? `${folder}/${name}` : name, tagged);
                    added++;
                    reportProgress(index, `${trackInfo.ART_NAME} - ${trackInfo.SNG_TITLE}`);
                }
                catch {
                    failed.push(id);
                }
            }
        }
        else {
            await initQobuzForSearch();
            const formatCode = (0, quality_1.qobuzFormatCode)(quality);
            for (let index = 0; index < trackIds.length; index++) {
                const id = String(trackIds[index]);
                try {
                    const meta = await qobuz.getTrackInfo(Number(id));
                    const urlInfo = await qobuz.getTrackDownloadUrl(Number(id), formatCode);
                    if (!urlInfo) {
                        failed.push(id);
                        continue;
                    }
                    const raw = await (0, got_1.default)(urlInfo.url, { responseType: 'buffer' }).then((r) => r.body);
                    const tagged = await qobuz.addTrackTags(raw, meta, 1000);
                    const extension = urlInfo.mime_type?.includes('mpeg') ? 'mp3' : 'flac';
                    const folder = structure === 'album' ? (0, quality_1.safeFilename)(meta?.album?.title) : '';
                    const name = `${pad2(Number(meta?.track_number) || 0)} ${(0, quality_1.safeFilename)(meta?.performer?.name)} - ${(0, quality_1.safeFilename)(meta?.title)}.${extension}`;
                    zip.addFile(folder ? `${folder}/${name}` : name, tagged);
                    added++;
                    reportProgress(index, `${meta?.performer?.name} - ${meta?.title}`);
                }
                catch {
                    failed.push(id);
                }
            }
        }
        if (added === 0) {
            throw respond_1.ApiError.notFound('None of the requested tracks could be downloaded', { failed });
        }
        const outName = (0, quality_1.safeFilename)(req.body?.zipName || `${service}-download-${Date.now()}`);
        const buffer = zip.toBuffer();
        if (jobId) {
            io.emit('downloadProgress', {
                itemId: jobId,
                itemStatus: 'completed',
                itemProgress: 100,
                current: trackIds.length,
                total: trackIds.length,
            });
        }
        res.setHeader('Content-Type', 'application/zip');
        res.setHeader('Content-Disposition', `attachment; filename="${outName}.zip"`);
        res.setHeader('Content-Length', String(buffer.length));
        res.setHeader('X-Elixium-Tracks-Added', String(added));
        res.setHeader('X-Elixium-Tracks-Failed', String(failed.length));
        res.send(buffer);
    }));
    app.get(`${basePath}/tracks/:id/lyrics`, (0, respond_1.route)(async (req, res) => {
        const id = (0, respond_1.requireString)(req.params.id, 'id');
        if (String(req.query.service ?? '').toLowerCase() === 'ytmusic') {
            const native = resolveYtMusicLyrics ? await resolveYtMusicLyrics(id).catch(() => null) : null;
            const artist = String(req.query.artist ?? '').trim();
            const title = String(req.query.title ?? '').trim();
            const found = native ?? (artist && title ? await (0, lyrics_1.fetchLrclib)({ artist, title }).catch(() => null) : null);
            if (!found)
                throw respond_1.ApiError.notFound('No lyrics available for this track');
            return (0, respond_1.sendData)(res, {
                text: found.text,
                synced: 'synced' in found ? found.synced : [],
                source: found.source,
            });
        }
        const service = (0, respond_1.parseService)(req.query.service);
        let result = null;
        let meta = {};
        if (service === 'deezer') {
            await initDeezerForDownload().catch(() => undefined);
            const info = await deezer.getTrackInfo(id).catch(() => undefined);
            if (info) {
                meta = {
                    artist: info.ART_NAME,
                    title: info.SNG_TITLE,
                    album: info.ALB_TITLE,
                    durationSec: Number(info.DURATION) || undefined,
                };
                const native = await deezer.getTrackLyrics(info).catch(() => null);
                if (native?.LYRICS_TEXT) {
                    const synced = Array.isArray(native.LYRICS_SYNC_JSON)
                        ? native.LYRICS_SYNC_JSON.filter((line) => line?.line).map((line) => ({
                            timeMs: Number(line.milliseconds) || 0,
                            durationMs: Number(line.duration) || 0,
                            text: String(line.line),
                        }))
                        : [];
                    result = { text: native.LYRICS_TEXT, synced, source: 'deezer' };
                }
            }
            else {
                const pub = await deezer.getTrackInfoPublicApi(id).catch(() => undefined);
                if (pub) {
                    meta = {
                        artist: pub.artist?.name,
                        title: pub.title,
                        album: pub.album?.title,
                        durationSec: Number(pub.duration) || undefined,
                    };
                }
            }
        }
        else {
            await initQobuzForSearch();
            const track = await qobuz.getTrackInfo(Number(id)).catch(() => undefined);
            if (!track)
                throw respond_1.ApiError.notFound('Track not found');
            meta = {
                artist: track?.performer?.name ?? track?.album?.artist?.name,
                title: track?.title,
                album: track?.album?.title,
                durationSec: Number(track?.duration) || undefined,
            };
        }
        if (!result && meta.artist && meta.title) {
            result = await (0, lyrics_1.fetchLrclib)({
                artist: meta.artist,
                title: meta.title,
                album: meta.album,
                durationSec: meta.durationSec,
            });
        }
        if (!result)
            throw respond_1.ApiError.notFound('No lyrics available for this track');
        return (0, respond_1.sendData)(res, { text: result.text, synced: result.synced, writers: null, copyright: null }, { service, id, hasSynced: result.synced.length > 0, source: result.source });
    }));
    app.get(`${basePath}/cache/stats`, (0, respond_1.route)(async (_req, res) => (0, respond_1.sendData)(res, track_cache_1.trackBufferCache.stats())));
};
exports.registerMediaRoutes = registerMediaRoutes;
