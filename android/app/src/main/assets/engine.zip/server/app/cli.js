"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildCommand = exports.printBanner = exports.ensureLegacyNodeOptions = void 0;
const commander_1 = require("commander");
const crypto_1 = require("crypto");
const child_process_1 = require("child_process");
const picocolors_1 = __importDefault(require("picocolors"));
const brand_1 = require("./brand");
const terminal_1 = require("./terminal");
const RELAUNCH_SENTINEL = 'ELIXIUM_OPENSSL_RELAUNCHED';
const canDecryptDeezer = () => {
    try {
        (0, crypto_1.createDecipheriv)('bf-cbc', Buffer.alloc(16), Buffer.alloc(8));
        return true;
    }
    catch {
        return false;
    }
};
const ensureLegacyNodeOptions = () => {
    if (canDecryptDeezer() || process.env[RELAUNCH_SENTINEL])
        return;
    if (process.pkg) {
        console.warn('Blowfish is unavailable in this build, so Deezer downloads will fail. ' +
            'Qobuz is unaffected. Please report this — the packaged Node version needs the legacy OpenSSL provider.');
        return;
    }
    const result = (0, child_process_1.spawnSync)(process.execPath, ['--openssl-legacy-provider', ...process.execArgv, ...process.argv.slice(1)], { stdio: 'inherit', env: { ...process.env, [RELAUNCH_SENTINEL]: '1' } });
    if (result.error) {
        console.warn('Blowfish is unavailable and Elixium could not relaunch with --openssl-legacy-provider. ' +
            'Deezer downloads will fail; start Node with that flag manually.');
        return;
    }
    process.exit(result.status ?? 0);
};
exports.ensureLegacyNodeOptions = ensureLegacyNodeOptions;
const printBanner = (version) => console.log((0, terminal_1.formatBanner)(version));
exports.printBanner = printBanner;
const buildCommand = () => {
    const cmd = new commander_1.Command()
        .name(brand_1.APP_COMMAND)
        .description(`${brand_1.APP_BRAND} streaming music downloader and browser control plane`)
        .option('-q, --quality <quality>', 'The quality of the files to download: 128/320/flac for Deezer, 320kbps/44khz/96khz/192khz for Qobuz')
        .option('-o, --output <template>', 'Output filename template')
        .option('-u, --url <url>', 'Deezer/Qobuz album/artist/playlist/track url')
        .option('-i, --input-file <file>', 'Downloads all urls listed in text file')
        .option('-c, --concurrency <number>', 'Download concurrency for album, artists and playlist')
        .option('-a, --set-arl <string>', 'Set arl cookie')
        .option('-d, --headless', 'Run in headless mode for scripting automation', false)
        .option('-conf, --config-file <file>', 'Custom location to your config file', brand_1.DEFAULT_CONFIG_FILE)
        .option('-rfp, --resolve-full-path', 'Use absolute path for playlists')
        .option('-cp, --create-playlist', 'Force create a playlist file for non playlists')
        .option('-b, --qobuz', 'Experimental Qobuz support')
        .option('-w, --web', 'Start web interface', false)
        .option('-p, --port <port>', 'Web interface port', '3000')
        .option('-H, --host <host>', 'Interface to bind (e.g. 127.0.0.1 for local-only)');
    cmd.showHelpAfterError('(run with --help for usage and examples)');
    cmd.configureOutput({
        outputError: (str, write) => write((0, terminal_1.formatCliError)(str)),
    });
    cmd.configureHelp({
        sortOptions: true,
        optionTerm: (option) => picocolors_1.default.cyan(option.flags),
        subcommandTerm: (subcommand) => picocolors_1.default.cyan(subcommand.name()),
    });
    cmd.usage('[options]');
    const defaultHelpInformation = cmd.helpInformation.bind(cmd);
    cmd.helpInformation = () => `${defaultHelpInformation()}\n${picocolors_1.default.dim(`Control routes through ${brand_1.DEFAULT_CONFIG_FILE}. ${brand_1.REPOSITORY_PLACEHOLDER}.`)}\n\n${(0, terminal_1.terminalExamples)()}\n\n${(0, terminal_1.terminalNotes)()}\n`;
    if (process.pkg) {
        cmd.option('-U, --update', 'Check update status for this build');
    }
    return cmd;
};
exports.buildCommand = buildCommand;
