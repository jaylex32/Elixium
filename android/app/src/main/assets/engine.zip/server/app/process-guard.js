"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.isClientDisconnect = exports.installProcessGuard = void 0;
const signale_1 = __importDefault(require("../lib/signale"));
const describe = (error) => {
    if (error instanceof Error)
        return error.stack || `${error.name}: ${error.message}`;
    if (typeof error === 'object' && error !== null) {
        try {
            return JSON.stringify(error);
        }
        catch {
            return Object.prototype.toString.call(error);
        }
    }
    return String(error);
};
let installed = false;
const installProcessGuard = ({ onError } = {}) => {
    if (installed)
        return;
    installed = true;
    process.on('unhandledRejection', (reason) => {
        console.error(signale_1.default.error('Unhandled promise rejection — logged, the server keeps running'));
        console.error(signale_1.default.note(describe(reason)));
        onError?.('rejection', reason);
    });
    process.on('uncaughtException', (error) => {
        console.error(signale_1.default.error('Uncaught exception — exiting so the process does not serve from a broken state'));
        console.error(signale_1.default.note(describe(error)));
        onError?.('exception', error);
        setTimeout(() => process.exit(1), 100).unref();
    });
    process.on('warning', (warning) => {
        if (warning.name === 'MaxListenersExceededWarning') {
            console.warn(signale_1.default.warn(`${warning.name}: ${warning.message}`));
        }
    });
};
exports.installProcessGuard = installProcessGuard;
const isClientDisconnect = (error) => {
    const code = error?.code;
    return code === 'ECONNRESET' || code === 'EPIPE' || code === 'ERR_STREAM_PREMATURE_CLOSE';
};
exports.isClientDisconnect = isClientDisconnect;
