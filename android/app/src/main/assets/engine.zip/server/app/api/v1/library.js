"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerLibraryRoutes = void 0;
const respond_1 = require("../respond");
const settings_1 = require("../settings");
const auth_1 = require("../auth");
const toArray = (value) => {
    if (!value)
        return [];
    if (Array.isArray(value))
        return value;
    if (typeof value.values === 'function')
        return [...value.values()];
    if (typeof value === 'object')
        return Object.values(value);
    return [];
};
const requireWatchlist = (watchlist) => {
    if (!watchlist) {
        throw new respond_1.ApiError('service_unavailable', 'Watchlist service is not enabled on this server');
    }
    return watchlist;
};
const registerLibraryRoutes = ({ app, basePath, conf, deezer, qobuz, initDeezerForDownload, initQobuzForDownload, settingsHooks, watchlist, activeDownloads, getCurrentDownloadQueue, getIsDownloading, startDownloadProcess, normalizeQuality, }) => {
    app.get(`${basePath}/settings`, (0, respond_1.route)(async (_req, res) => (0, respond_1.sendData)(res, (0, settings_1.readRedactedSettings)(conf))));
    app.patch(`${basePath}/settings`, (0, respond_1.route)(async (req, res) => {
        const changed = (0, settings_1.applySettings)(conf, req.body, settingsHooks);
        return (0, respond_1.sendData)(res, (0, settings_1.readRedactedSettings)(conf), { changed, count: changed.length });
    }));
    app.get(`${basePath}/auth/token`, (0, respond_1.route)(async (req, res) => {
        if (!(0, auth_1.isLoopback)(req)) {
            throw new respond_1.ApiError('forbidden', 'The token can only be read from the machine running Elixium.', 403);
        }
        return (0, respond_1.sendData)(res, {
            token: (0, auth_1.getOrCreateToken)(conf),
            enabled: (0, auth_1.isAuthEnabled)(conf),
            allowedOrigins: (0, auth_1.readAllowedOrigins)(conf),
        });
    }));
    app.post(`${basePath}/auth/rotate`, (0, respond_1.route)(async (req, res) => {
        if (!(0, auth_1.isLoopback)(req)) {
            throw new respond_1.ApiError('forbidden', 'The token can only be rotated from the machine running Elixium.', 403);
        }
        return (0, respond_1.sendData)(res, { token: (0, auth_1.rotateToken)(conf), enabled: (0, auth_1.isAuthEnabled)(conf) });
    }));
    app.post(`${basePath}/services/:service/verify`, (0, respond_1.route)(async (req, res) => {
        const service = (0, respond_1.parseService)(req.params.service);
        if (service === 'deezer') {
            const arl = conf.get('cookies.arl');
            if (!arl) {
                return (0, respond_1.sendData)(res, { service, ok: false, reason: 'missing_credential', message: 'No ARL cookie is set.' });
            }
            try {
                await initDeezerForDownload();
                const user = await deezer.getUser();
                return (0, respond_1.sendData)(res, {
                    service,
                    ok: true,
                    account: user?.BLOG_NAME ?? null,
                    message: 'Deezer session is valid.',
                });
            }
            catch (error) {
                const message = String(error?.message ?? error);
                const expired = /NEED_USER_AUTH|user auth/i.test(message);
                return (0, respond_1.sendData)(res, {
                    service,
                    ok: false,
                    reason: expired ? 'expired_credential' : 'auth_failed',
                    message: expired
                        ? 'Your ARL cookie has expired. Get a fresh one from deezer.com and paste it above.'
                        : message,
                });
            }
        }
        const token = conf.get('qobuz.token');
        if (!token) {
            return (0, respond_1.sendData)(res, { service, ok: false, reason: 'missing_credential', message: 'No Qobuz token is set.' });
        }
        try {
            await initQobuzForDownload();
            await qobuz.getTrackInfo(Number(5966783)).catch(() => undefined);
            return (0, respond_1.sendData)(res, { service, ok: true, account: null, message: 'Qobuz session is valid.' });
        }
        catch (error) {
            return (0, respond_1.sendData)(res, {
                service,
                ok: false,
                reason: 'auth_failed',
                message: String(error?.message ?? error),
            });
        }
    }));
    app.get(`${basePath}/downloads`, (0, respond_1.route)(async (_req, res) => {
        const active = toArray(activeDownloads);
        return (0, respond_1.sendData)(res, { active, queue: getCurrentDownloadQueue() ?? [] }, { isDownloading: getIsDownloading(), activeCount: active.length });
    }));
    app.post(`${basePath}/downloads`, (0, respond_1.route)(async (req, res) => {
        const service = (0, respond_1.parseService)(req.body?.service);
        const tracks = req.body?.tracks ?? req.body?.queue;
        if (!Array.isArray(tracks) || tracks.length === 0) {
            throw respond_1.ApiError.badRequest('tracks must be a non-empty array');
        }
        const requested = String(req.body?.quality || '');
        const quality = normalizeQuality ? normalizeQuality(requested, service) : requested;
        void startDownloadProcess(tracks, quality, service, req.body?.settings ?? {}).catch((error) => {
            console.error('Download process failed:', error?.message ?? error);
        });
        return (0, respond_1.sendData)(res, { accepted: tracks.length, service, quality }, { status: 'queued' });
    }));
    app.get(`${basePath}/library`, (0, respond_1.route)(async (req, res) => {
        const service = requireWatchlist(watchlist);
        if (typeof service.getLibraryOverview !== 'function') {
            throw new respond_1.ApiError('service_unavailable', 'Library overview is not available.', 503);
        }
        const artistId = typeof req.query.artistId === 'string' ? req.query.artistId : undefined;
        const fetchIfMissing = req.query.refresh === '1' || req.query.refresh === 'true';
        return (0, respond_1.sendData)(res, await service.getLibraryOverview(artistId, { fetchIfMissing }));
    }));
    app.get(`${basePath}/watchlist`, (0, respond_1.route)(async (_req, res) => {
        const service = requireWatchlist(watchlist);
        return (0, respond_1.sendData)(res, await service.getState());
    }));
    app.get(`${basePath}/watchlist/history`, (0, respond_1.route)(async (_req, res) => {
        const service = requireWatchlist(watchlist);
        return (0, respond_1.sendData)(res, await service.getWatchlistHistory());
    }));
    app.get(`${basePath}/watchlist/schedules`, (0, respond_1.route)(async (_req, res) => {
        const service = requireWatchlist(watchlist);
        return (0, respond_1.sendData)(res, await service.getMonitorSchedules());
    }));
    app.post(`${basePath}/watchlist/artists`, (0, respond_1.route)(async (req, res) => {
        const service = requireWatchlist(watchlist);
        const artistId = (0, respond_1.requireString)(req.body?.artistId ?? req.body?.id, 'artistId');
        const result = await service.addWatchedArtist({ artistId, name: req.body?.name });
        return (0, respond_1.sendData)(res, result ?? (await service.getState()));
    }));
    app.delete(`${basePath}/watchlist/artists/:id`, (0, respond_1.route)(async (req, res) => {
        const service = requireWatchlist(watchlist);
        const artistId = (0, respond_1.requireString)(req.params.id, 'id');
        await service.removeWatchedArtist({ artistId });
        return (0, respond_1.sendData)(res, { removed: artistId });
    }));
    app.post(`${basePath}/watchlist/playlists`, (0, respond_1.route)(async (req, res) => {
        const service = requireWatchlist(watchlist);
        const playlistId = (0, respond_1.requireString)(req.body?.playlistId ?? req.body?.id, 'playlistId');
        const result = await service.addWatchedPlaylist({ playlistId, name: req.body?.name });
        return (0, respond_1.sendData)(res, result ?? (await service.getState()));
    }));
    app.delete(`${basePath}/watchlist/playlists/:id`, (0, respond_1.route)(async (req, res) => {
        const service = requireWatchlist(watchlist);
        const playlistId = (0, respond_1.requireString)(req.params.id, 'id');
        await service.removeWatchedPlaylist({ playlistId });
        return (0, respond_1.sendData)(res, { removed: playlistId });
    }));
    app.post(`${basePath}/watchlist/scan`, (0, respond_1.route)(async (_req, res) => {
        const service = requireWatchlist(watchlist);
        const result = await service.runMonitorNow();
        return (0, respond_1.sendData)(res, result ?? { started: true });
    }));
    app.get(`${basePath}/watchlist/genres`, (0, respond_1.route)(async (_req, res) => {
        const service = requireWatchlist(watchlist);
        return (0, respond_1.sendData)(res, await service.getFavoriteGenres());
    }));
    app.put(`${basePath}/watchlist/genres`, (0, respond_1.route)(async (req, res) => {
        const service = requireWatchlist(watchlist);
        const genres = req.body?.genres;
        if (!Array.isArray(genres))
            throw respond_1.ApiError.badRequest('genres must be an array');
        await service.saveFavoriteGenres({ genres });
        return (0, respond_1.sendData)(res, await service.getFavoriteGenres());
    }));
};
exports.registerLibraryRoutes = registerLibraryRoutes;
