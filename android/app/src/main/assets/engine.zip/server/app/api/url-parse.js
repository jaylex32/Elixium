"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseMediaUrl = exports.detectSourceService = void 0;
const has = (url, ...needles) => needles.some((needle) => url.includes(needle));
const isSpotify = (url) => has(url, 'spotify.com', 'open.spotify.com') || url.startsWith('spotify:');
const isDeezer = (url) => has(url, 'deezer.com');
const isQobuz = (url) => has(url, 'qobuz.com', 'play.qobuz.com');
const isTidal = (url) => has(url, 'tidal.com');
const isYouTube = (url) => has(url, 'youtube.com', 'youtu.be');
const detectSourceService = (url) => {
    if (isDeezer(url))
        return 'deezer';
    if (isQobuz(url))
        return 'qobuz';
    if (isTidal(url))
        return 'tidal';
    if (isYouTube(url))
        return 'youtube';
    return 'spotify';
};
exports.detectSourceService = detectSourceService;
const detectContentKind = (url) => {
    if (url.includes('/playlist/'))
        return 'playlist';
    if (url.includes('/album/'))
        return 'album';
    if (url.includes('/track/'))
        return 'track';
    if (url.includes('/artist/'))
        return 'artist';
    return undefined;
};
const firstString = (...values) => {
    for (const value of values) {
        if (typeof value === 'string' && value.trim())
            return value.trim();
    }
    return undefined;
};
const parseMediaUrl = async (rawUrl, preferredService, deps) => {
    const url = String(rawUrl || '').trim();
    if (!url)
        throw new Error('No URL provided');
    const explicit = typeof preferredService === 'string' && preferredService.length > 0;
    const routeToQobuz = preferredService === 'qobuz' || (!explicit && (isQobuz(url) || isSpotify(url) || isTidal(url) || isYouTube(url)));
    let parsed;
    let prefix = '';
    if (isSpotify(url)) {
        await deps.ensureQobuzSearchReady();
        parsed = routeToQobuz ? await deps.parseToQobuz(url) : await deps.parseDeezerUrl(url);
        prefix = 'spotify-';
    }
    else if (isDeezer(url)) {
        parsed = routeToQobuz ? await deps.parseToQobuz(url) : await deps.parseDeezerUrl(url);
        prefix = routeToQobuz ? 'qobuz-' : '';
    }
    else if (isTidal(url) || isYouTube(url) || isQobuz(url)) {
        await deps.ensureQobuzSearchReady();
        parsed = await deps.parseToQobuz(url);
        prefix = 'qobuz-';
    }
    else {
        throw new Error('Unsupported URL format');
    }
    const kind = detectContentKind(url) ?? (isYouTube(url) ? 'track' : undefined);
    if (kind)
        parsed.linktype = `${prefix}${kind}`;
    if (!parsed?.tracks || parsed.tracks.length === 0) {
        throw new Error('No tracks found in the provided URL');
    }
    const metadata = {
        originalUrl: url,
        service: (0, exports.detectSourceService)(url),
        contentType: parsed.linktype,
        trackCount: parsed.tracks.length,
        title: firstString(parsed.linkinfo?.title, parsed.linkinfo?.name, parsed.linkinfo?.TITLE, parsed.linkinfo?.ALB_TITLE, parsed.linkinfo?.SNG_TITLE, parsed.tracks?.[0]?.SNG_TITLE, parsed.tracks?.[0]?.title) ?? 'Unknown Content',
    };
    parsed.metadata = metadata;
    return parsed;
};
exports.parseMediaUrl = parseMediaUrl;
