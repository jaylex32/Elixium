"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.matchTrack = exports.scoreCandidate = exports.MATCH_THRESHOLD = exports.secondsOf = exports.durationCloseness = exports.similarity = exports.normalise = exports.sameVersion = exports.versionTags = void 0;
const NOISE_PATTERNS = [
    /\((?:official\s+)?(?:music\s+)?video\)/gi,
    /\(official\s+audio\)/gi,
    /\(audio\)/gi,
    /\(lyrics?(?:\s+video)?\)/gi,
    /\(visualiser\)|\(visualizer\)/gi,
    /\(\d{4}\s+remaster(?:ed)?\)/gi,
    /\(remaster(?:ed)?(?:\s+\d{4})?\)/gi,
    /\[[^\]]*\]/g,
    /\bhq\b|\bhd\b|\b4k\b/gi,
];
const VERSION_TAGS = [
    ['instrumental', /\binstrumentals?\b/],
    ['karaoke', /\bkaraoke\b/],
    ['acapella', /\ba[\s-]?cappella\b|\bacapella\b/],
    ['live', /\blive\b/],
    ['remix', /\bremix(?:es)?\b|\brmx\b/],
    ['cover', /\bcover(?:ed)?\s+(?:version|by)\b|\(\s*cover\s*\)/],
    ['sped', /\bsped[\s-]?up\b|\bspeed[\s-]?up\b/],
    ['slowed', /\bslowed\b/],
    ['reverb', /\breverb\b/],
    ['nightcore', /\bnightcore\b/],
    ['eightd', /\b8d\b/],
    ['demo', /\bdemo\b/],
    ['extended', /\bextended\b/],
    ['radioedit', /\bradio\s+edit\b/],
    ['mono', /\bmono\b/],
];
const versionTags = (value) => {
    const text = String(value ?? '').toLowerCase();
    const found = new Set();
    for (const [name, pattern] of VERSION_TAGS)
        if (pattern.test(text))
            found.add(name);
    return found;
};
exports.versionTags = versionTags;
const sameVersion = (a, b) => {
    const left = (0, exports.versionTags)(a);
    const right = (0, exports.versionTags)(b);
    if (left.size !== right.size)
        return false;
    for (const tag of left)
        if (!right.has(tag))
            return false;
    return true;
};
exports.sameVersion = sameVersion;
const FEATURE_PATTERN = /\s*[([]?\s*(?:feat\.?|ft\.?|featuring|with)\s+[^)\]]*[)\]]?/gi;
const normalise = (value) => {
    let text = String(value ?? '').toLowerCase();
    for (const pattern of NOISE_PATTERNS)
        text = text.replace(pattern, ' ');
    text = text.replace(FEATURE_PATTERN, ' ');
    text = text.normalize('NFD').replace(/[̀-ͯ]/g, '');
    text = text.replace(/[^a-z0-9]+/g, ' ');
    return text.trim().replace(/\s+/g, ' ');
};
exports.normalise = normalise;
const tokens = (value) => (value ? value.split(' ').filter(Boolean) : []);
const similarity = (a, b) => {
    const left = tokens((0, exports.normalise)(a));
    const right = tokens((0, exports.normalise)(b));
    if (left.length === 0 || right.length === 0)
        return 0;
    const pool = [...right];
    let hits = 0;
    for (const token of left) {
        const index = pool.indexOf(token);
        if (index >= 0) {
            hits += 1;
            pool.splice(index, 1);
        }
    }
    return (2 * hits) / (left.length + right.length);
};
exports.similarity = similarity;
const durationCloseness = (a, b) => {
    if (!a || !b || a <= 0 || b <= 0)
        return null;
    const delta = Math.abs(a - b);
    if (delta <= 3)
        return 1;
    if (delta >= 15)
        return 0;
    return 1 - (delta - 3) / 12;
};
exports.durationCloseness = durationCloseness;
const secondsOf = (value) => {
    if (typeof value === 'number' && Number.isFinite(value) && value > 0)
        return value;
    if (typeof value !== 'string')
        return null;
    const parts = value.split(':');
    if (parts.length < 2 || parts.length > 3 || !parts.every((part) => /^\d+$/.test(part)))
        return null;
    return parts.reduce((total, part) => total * 60 + Number(part), 0);
};
exports.secondsOf = secondsOf;
const WEIGHTS = { title: 0.45, artist: 0.25, duration: 0.3 };
exports.MATCH_THRESHOLD = 0.82;
const scoreCandidate = (source, candidate) => {
    const title = (0, exports.similarity)(source.title, candidate.title);
    const artist = (0, exports.similarity)(source.artist, candidate.artist);
    const duration = (0, exports.durationCloseness)(source.durationSeconds, (0, exports.secondsOf)(candidate.duration));
    if (!(0, exports.sameVersion)(source.title, candidate.title))
        return { score: 0, title, artist, duration };
    const parts = duration === null
        ? [
            [title, WEIGHTS.title],
            [artist, WEIGHTS.artist],
        ]
        : [
            [title, WEIGHTS.title],
            [artist, WEIGHTS.artist],
            [duration, WEIGHTS.duration],
        ];
    const totalWeight = parts.reduce((sum, [, weight]) => sum + weight, 0);
    const score = parts.reduce((sum, [value, weight]) => sum + value * weight, 0) / totalWeight;
    return { score, title, artist, duration };
};
exports.scoreCandidate = scoreCandidate;
const matchTrack = async (source, search) => {
    const queries = [`${source.artist} ${source.title}`.trim(), source.title.trim()].filter((query, index, all) => query && all.indexOf(query) === index);
    const seen = new Set();
    const candidates = [];
    for (const query of queries) {
        let results = [];
        try {
            results = await search(query);
        }
        catch {
            continue;
        }
        for (const result of results) {
            if (seen.has(result.id))
                continue;
            seen.add(result.id);
            candidates.push({ result, score: (0, exports.scoreCandidate)(source, result) });
        }
        if (candidates.some((candidate) => candidate.score.score >= exports.MATCH_THRESHOLD))
            break;
    }
    candidates.sort((a, b) => b.score.score - a.score.score);
    if (candidates.length === 0)
        return { match: null, score: null, candidates, reason: 'no-results' };
    const best = candidates[0];
    if (best.score.score < exports.MATCH_THRESHOLD) {
        return { match: null, score: best.score, candidates, reason: 'low-confidence' };
    }
    return { match: best.result, score: best.score, candidates, reason: 'matched' };
};
exports.matchTrack = matchTrack;
