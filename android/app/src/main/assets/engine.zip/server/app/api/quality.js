"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.safeFilename = exports.extensionFor = exports.deezerFormatFallbacks = exports.qobuzFormatFallbacks = exports.qobuzFormatCode = exports.deezerFormatCode = exports.defaultQualityFor = exports.qualitiesFor = exports.QOBUZ_QUALITIES = exports.DEEZER_QUALITIES = void 0;
exports.DEEZER_QUALITIES = [
    { id: 'flac', label: 'FLAC', format: 'flac', detail: '16-bit / 44.1 kHz lossless' },
    { id: '320', label: 'MP3 320', format: 'mp3', detail: '320 kbps' },
    { id: '128', label: 'MP3 128', format: 'mp3', detail: '128 kbps' },
];
exports.QOBUZ_QUALITIES = [
    { id: 'hires', label: 'Hi-Res', format: 'flac', detail: 'up to 24-bit / 192 kHz' },
    { id: '96khz', label: 'Hi-Res 96', format: 'flac', detail: '24-bit / 96 kHz' },
    { id: '44khz', label: 'CD', format: 'flac', detail: '16-bit / 44.1 kHz' },
    { id: '320kbps', label: 'MP3 320', format: 'mp3', detail: '320 kbps' },
];
const qualitiesFor = (service) => service === 'deezer' ? exports.DEEZER_QUALITIES : exports.QOBUZ_QUALITIES;
exports.qualitiesFor = qualitiesFor;
const defaultQualityFor = (service) => (service === 'deezer' ? 'flac' : '44khz');
exports.defaultQualityFor = defaultQualityFor;
const deezerFormatCode = (quality) => {
    switch (String(quality || '').toLowerCase()) {
        case 'flac':
        case 'lossless':
            return 9;
        case '128':
        case '128kbps':
        case 'mp3_128':
            return 1;
        case '320':
        case '320kbps':
        case 'mp3_320':
            return 3;
        default:
            return 1;
    }
};
exports.deezerFormatCode = deezerFormatCode;
const qobuzFormatCode = (quality) => {
    switch (String(quality || '').toLowerCase()) {
        case '320kbps':
        case '320':
            return 5;
        case '44khz':
        case 'cd':
            return 6;
        case '96khz':
            return 7;
        default:
            return 27;
    }
};
exports.qobuzFormatCode = qobuzFormatCode;
const descendingFrom = (requested, ladder) => [
    requested,
    ...ladder.filter((code) => code < requested),
];
const qobuzFormatFallbacks = (quality) => descendingFrom((0, exports.qobuzFormatCode)(quality), [27, 7, 6, 5]);
exports.qobuzFormatFallbacks = qobuzFormatFallbacks;
const deezerFormatFallbacks = (quality) => descendingFrom((0, exports.deezerFormatCode)(quality), [9, 3, 1]);
exports.deezerFormatFallbacks = deezerFormatFallbacks;
const extensionFor = (service, quality) => {
    if (service === 'deezer')
        return (0, exports.deezerFormatCode)(quality) === 9 ? 'flac' : 'mp3';
    return (0, exports.qobuzFormatCode)(quality) === 5 ? 'mp3' : 'flac';
};
exports.extensionFor = extensionFor;
const safeFilename = (value) => String(value ?? '')
    .replace(/[\\/:*?"<>|]+/g, '_')
    .replace(/\s+/g, ' ')
    .trim() || 'Unknown';
exports.safeFilename = safeFilename;
