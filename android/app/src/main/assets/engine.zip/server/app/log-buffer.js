"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.clearLogEntries = exports.getLogEntries = exports.attachLogBroadcast = exports.installLogCapture = void 0;
const MAX_ENTRIES = 500;
const ANSI = /\[[0-9;]*m/g;
const entries = [];
let sequence = 0;
let broadcast = null;
let installed = false;
const record = (level, args) => {
    const message = args
        .map((arg) => {
        if (typeof arg === 'string')
            return arg;
        if (arg instanceof Error)
            return arg.stack || arg.message;
        try {
            return JSON.stringify(arg);
        }
        catch {
            return String(arg);
        }
    })
        .join(' ')
        .replace(ANSI, '')
        .trimEnd();
    if (!message)
        return;
    const entry = { seq: ++sequence, at: Date.now(), level, message };
    entries.push(entry);
    if (entries.length > MAX_ENTRIES)
        entries.splice(0, entries.length - MAX_ENTRIES);
    try {
        broadcast?.(entry);
    }
    catch {
    }
};
const installLogCapture = () => {
    if (installed)
        return;
    installed = true;
    const original = {
        log: console.log.bind(console),
        info: console.info.bind(console),
        warn: console.warn.bind(console),
        error: console.error.bind(console),
    };
    console.log = (...args) => {
        record('info', args);
        original.log(...args);
    };
    console.info = (...args) => {
        record('info', args);
        original.info(...args);
    };
    console.warn = (...args) => {
        record('warn', args);
        original.warn(...args);
    };
    console.error = (...args) => {
        record('error', args);
        original.error(...args);
    };
};
exports.installLogCapture = installLogCapture;
const attachLogBroadcast = (io) => {
    broadcast = (entry) => io.emit('logLine', entry);
};
exports.attachLogBroadcast = attachLogBroadcast;
const getLogEntries = (since = 0, limit = MAX_ENTRIES) => {
    const selected = since > 0 ? entries.filter((entry) => entry.seq > since) : entries;
    return selected.slice(-limit);
};
exports.getLogEntries = getLogEntries;
const clearLogEntries = () => {
    entries.length = 0;
};
exports.clearLogEntries = clearLogEntries;
