"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPlaylistSearch = exports.PLAYLIST_SEARCH_SERVICES = void 0;
const axios_1 = __importDefault(require("axios"));
let appToken = null;
const getAppToken = async (clientId, clientSecret) => {
    if (appToken && appToken.expiresAt > Date.now())
        return appToken.value;
    const credentials = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
    const { data } = await axios_1.default.post('https://accounts.spotify.com/api/token', 'grant_type=client_credentials', {
        headers: { Authorization: `Basic ${credentials}`, 'Content-Type': 'application/x-www-form-urlencoded' },
        timeout: 15000,
    });
    appToken = { value: data.access_token, expiresAt: Date.now() + (Number(data.expires_in || 3600) - 60) * 1000 };
    return appToken.value;
};
exports.PLAYLIST_SEARCH_SERVICES = ['deezer', 'qobuz', 'spotify'];
const createPlaylistSearch = ({ qobuz, deezer, ensureQobuzSearchReady, setSpotifyAnonymousToken, getSpotifyApi, getSpotifyCredentials, }) => {
    const searchPlaylists = async (service, query, limit = 30, offset = 0) => {
        const trimmed = String(query || '').trim();
        if (!trimmed)
            return [];
        if (service === 'deezer') {
            const result = await deezer.searchMusicPaged(trimmed, 'PLAYLIST', Number(limit), Number(offset));
            return (result?.data || []).map((playlist) => ({
                id: String(playlist.PLAYLIST_ID || playlist.id),
                title: playlist.TITLE || playlist.title,
                artist: playlist.PARENT_USERNAME || playlist.user?.name || 'Deezer',
                album: 'Playlist',
                type: 'playlist',
                duration: `${playlist.NB_SONG || playlist.nb_tracks || 0} tracks`,
                url: `https://www.deezer.com/playlist/${playlist.PLAYLIST_ID || playlist.id}`,
                sourceService: 'deezer',
                rawData: playlist,
            }));
        }
        if (service === 'qobuz') {
            await ensureQobuzSearchReady();
            const result = await qobuz.searchMusic(trimmed, 'playlist', Number(limit), Number(offset));
            return (result.playlists?.items || []).map((playlist) => ({
                id: String(playlist.id),
                title: playlist.name,
                artist: playlist.owner?.name || 'Qobuz',
                album: 'Playlist',
                type: 'playlist',
                duration: `${playlist.tracks_count || 0} tracks`,
                url: `https://play.qobuz.com/playlist/${playlist.id}`,
                sourceService: 'qobuz',
                rawData: playlist,
            }));
        }
        const { clientId, clientSecret } = getSpotifyCredentials();
        let items = [];
        if (clientId && clientSecret) {
            const token = await getAppToken(clientId, clientSecret);
            const { data } = await axios_1.default.get('https://api.spotify.com/v1/search', {
                params: { q: trimmed, type: 'playlist', limit: Number(limit), offset: Number(offset) },
                headers: { Authorization: `Bearer ${token}` },
                timeout: 15000,
            });
            items = data?.playlists?.items || [];
        }
        else {
            try {
                await setSpotifyAnonymousToken();
                const response = await getSpotifyApi().searchPlaylists(trimmed, {
                    limit: Number(limit),
                    offset: Number(offset),
                });
                items = response?.body?.playlists?.items || [];
            }
            catch (error) {
                const status = error?.statusCode ?? error?.response?.status;
                throw new Error(status === 429 || status === 401
                    ? 'Spotify playlist search needs a free Spotify developer app. Add its Client ID and Secret in Settings; pasting a Spotify playlist link works without one.'
                    : error?.message || 'Spotify search failed');
            }
        }
        return (items
            .filter((playlist) => playlist && playlist.id)
            .map((playlist) => ({
            id: String(playlist.id),
            title: playlist.name,
            artist: playlist.owner?.display_name || 'Spotify',
            album: 'Playlist',
            type: 'playlist',
            duration: `${playlist.tracks?.total || 0} tracks`,
            url: playlist.external_urls?.spotify || `https://open.spotify.com/playlist/${playlist.id}`,
            sourceService: 'spotify',
            rawData: {
                ...playlist,
                picture_medium: playlist.images?.[0]?.url,
            },
        })));
    };
    return { searchPlaylists };
};
exports.createPlaylistSearch = createPlaylistSearch;
