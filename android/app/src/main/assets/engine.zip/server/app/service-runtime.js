"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createServiceRuntime = void 0;
const log_update_1 = __importDefault(require("log-update"));
const signale_1 = __importDefault(require("../lib/signale"));
const createServiceRuntime = ({ options, conf, deezer, qobuz, appCommand, getIsDeezerInitialized, setIsDeezerInitialized, getIsQobuzInitialized, setIsQobuzInitialized, getIsDeezerDownloadReady, setIsDeezerDownloadReady, getIsQobuzDownloadReady, setIsQobuzDownloadReady, }) => {
    const initDeezerForSearch = async () => {
        setIsDeezerInitialized(true);
        console.log(signale_1.default.success('Deezer search ready (no authentication needed for browsing)'));
    };
    let deezerLogin = null;
    const loginToDeezer = async () => {
        (0, log_update_1.default)(signale_1.default.pending('Initializing Deezer for downloads...'));
        const arl = conf.get('cookies.arl');
        if (!arl) {
            throw new Error(`Deezer ARL cookie required for downloads. Please set it using: ${appCommand} --set-arl "your_arl_here"`);
        }
        (0, log_update_1.default)(signale_1.default.pending('Verifying Deezer session...'));
        try {
            await deezer.initDeezerApi(arl);
            const { BLOG_NAME } = await deezer.getUser();
            (0, log_update_1.default)(signale_1.default.success('Logged in to Deezer as ' + BLOG_NAME));
            log_update_1.default.done();
            setIsDeezerDownloadReady(true);
        }
        catch (error) {
            log_update_1.default.clear();
            console.log(signale_1.default.error('Deezer authentication failed: ' + error.message));
            console.log(signale_1.default.note('Your ARL cookie may have expired. Please get a fresh one from deezer.com'));
            throw error;
        }
    };
    const initDeezerForDownload = async () => {
        if (getIsDeezerDownloadReady())
            return;
        if (!deezerLogin) {
            deezerLogin = loginToDeezer().finally(() => {
                deezerLogin = null;
            });
        }
        return deezerLogin;
    };
    const refreshDeezerSession = async () => {
        setIsDeezerDownloadReady(false);
        return initDeezerForDownload();
    };
    const usableAppId = (value) => {
        const id = Number(value);
        return Number.isFinite(id) && id > 0 ? id : null;
    };
    const scrapeQobuzCredentials = async () => {
        const spoofer = new qobuz.QobuzSpoofer();
        await spoofer.init();
        const appId = usableAppId(spoofer.get_app_id());
        if (appId === null) {
            throw new Error('Could not read the Qobuz app id from their web player — Qobuz has changed their site and Elixium needs an update');
        }
        return { appId, secrets: spoofer.get_secrets() };
    };
    const initQobuzForSearch = async () => {
        if (getIsQobuzInitialized())
            return;
        (0, log_update_1.default)(signale_1.default.pending('Loading Qobuz API for search...'));
        let appId = usableAppId(conf.get('qobuz.app_id'));
        const configuredSecrets = conf.get('qobuz.secrets') || '';
        let secrets = configuredSecrets.split(',').filter(Boolean);
        if (appId === null || secrets.length < 1) {
            const scraped = await scrapeQobuzCredentials();
            if (appId === null) {
                appId = scraped.appId;
                conf.set('qobuz.app_id', appId);
            }
            if (secrets.length < 1 && scraped.secrets.length > 0) {
                secrets = scraped.secrets;
                conf.set('qobuz.secrets', secrets.join(','));
            }
        }
        const authToken = conf.get('qobuz.token') || '';
        if (!authToken) {
            log_update_1.default.clear();
            throw new Error('Qobuz needs an account: add your Qobuz Token in Settings to browse or download');
        }
        await qobuz.initQobuzApi(authToken, appId, secrets);
        (0, log_update_1.default)(signale_1.default.success('Qobuz search ready'));
        log_update_1.default.done();
        setIsQobuzInitialized(true);
    };
    const initQobuzForDownload = async () => {
        if (getIsQobuzDownloadReady())
            return;
        if (!getIsQobuzInitialized()) {
            await initQobuzForSearch();
        }
        (0, log_update_1.default)(signale_1.default.pending('Initializing Qobuz for downloads...'));
        const authToken = conf.get('qobuz.token');
        const appId = conf.get('qobuz.app_id');
        const secrets = conf.get('qobuz.secrets').split(',');
        if (!authToken) {
            if (options.web) {
                (0, log_update_1.default)(signale_1.default.warn('Qobuz token not set - downloads will require authentication'));
                log_update_1.default.done();
                return;
            }
            throw new Error('Qobuz token required for downloads. Please configure your token in the web interface or config file');
        }
        await qobuz.initQobuzApi(authToken, appId, secrets);
        (0, log_update_1.default)(signale_1.default.success('Qobuz downloads ready'));
        log_update_1.default.done();
        setIsQobuzDownloadReady(true);
    };
    return {
        initDeezerForSearch,
        initDeezerForDownload,
        refreshDeezerSession,
        initQobuzForSearch,
        initQobuzForDownload,
    };
};
exports.createServiceRuntime = createServiceRuntime;
