"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProviderRegistry = exports.classifyFailure = exports.withTimeout = exports.ProviderTimeoutError = void 0;
class ProviderTimeoutError extends Error {
    constructor(name, timeoutMs) {
        super(`${name} did not initialise within ${timeoutMs}ms`);
        this.name = 'ProviderTimeoutError';
        this.timeoutMs = timeoutMs;
    }
}
exports.ProviderTimeoutError = ProviderTimeoutError;
const withTimeout = (task, timeoutMs, name) => {
    if (!Number.isFinite(timeoutMs) || timeoutMs <= 0)
        return task;
    return new Promise((resolve, reject) => {
        let settled = false;
        const timer = setTimeout(() => {
            if (settled)
                return;
            settled = true;
            reject(new ProviderTimeoutError(name, timeoutMs));
        }, timeoutMs);
        task.then((value) => {
            if (settled)
                return;
            settled = true;
            clearTimeout(timer);
            resolve(value);
        }, (error) => {
            if (settled)
                return;
            settled = true;
            clearTimeout(timer);
            reject(error);
        });
    });
};
exports.withTimeout = withTimeout;
const OFFLINE_CODES = new Set([
    'ENOTFOUND',
    'EAI_AGAIN',
    'ECONNREFUSED',
    'ECONNRESET',
    'ENETUNREACH',
    'EHOSTUNREACH',
    'EPIPE',
    'ETIMEDOUT',
    'ECONNABORTED',
]);
const classifyFailure = (error) => {
    if (error instanceof ProviderTimeoutError)
        return 'timeout';
    const err = error;
    const code = typeof err?.code === 'string' ? err.code.toUpperCase() : '';
    if (code && OFFLINE_CODES.has(code))
        return code === 'ETIMEDOUT' || code === 'ECONNABORTED' ? 'timeout' : 'offline';
    const status = err?.response?.status;
    if (status === 401 || status === 403)
        return 'auth';
    const message = String(err?.message ?? '').toLowerCase();
    if (message.includes('timeout') || message.includes('timed out'))
        return 'timeout';
    if (message.includes('getaddrinfo') || message.includes('dns') || message.includes('network'))
        return 'offline';
    if (message.includes('unauthor') || message.includes('auth') || message.includes('credential'))
        return 'auth';
    if (message.includes('account') || message.includes('sign in') || message.includes('rejected'))
        return 'auth';
    if (message.includes('token') || message.includes('secret') || message.includes('app id'))
        return 'config';
    if (message.includes('required') || message.includes('not set') || message.includes('missing'))
        return 'config';
    return 'unknown';
};
exports.classifyFailure = classifyFailure;
class ProviderRegistry {
    constructor(options = {}) {
        this.providers = new Map();
        this.lifecycle = 'starting';
        this.now = options.now ?? (() => Date.now());
        this.onEvent = options.onEvent;
    }
    register(definition) {
        this.providers.set(definition.name, {
            ...definition,
            state: 'idle',
            attempts: 0,
            inFlight: null,
        });
    }
    has(name) {
        return this.providers.has(name);
    }
    getLifecycle() {
        return this.lifecycle;
    }
    markCoreReady() {
        if (this.lifecycle === 'shutting_down' || this.lifecycle === 'failed')
            return;
        this.lifecycle = 'core_ready';
        this.refreshLifecycle();
    }
    markShuttingDown() {
        this.lifecycle = 'shutting_down';
    }
    markFailed() {
        this.lifecycle = 'failed';
    }
    async start(name) {
        const record = this.providers.get(name);
        if (!record)
            throw new Error(`Unknown provider: ${name}`);
        if (record.state === 'ready')
            return this.statusOf(record);
        if (record.inFlight) {
            await record.inFlight;
            return this.statusOf(record);
        }
        record.state = 'starting';
        record.attempts += 1;
        record.startedAt = this.now();
        record.failure = undefined;
        this.emit(record);
        const attempt = (0, exports.withTimeout)(Promise.resolve().then(() => record.init()), record.timeoutMs, record.name).then(() => {
            record.state = 'ready';
            record.settledAt = this.now();
            record.durationMs = record.settledAt - (record.startedAt ?? record.settledAt);
            record.failure = undefined;
        }, (error) => {
            const kind = (0, exports.classifyFailure)(error);
            record.state = record.optional ? 'unavailable' : 'failed';
            record.settledAt = this.now();
            record.durationMs = record.settledAt - (record.startedAt ?? record.settledAt);
            record.failure = {
                kind,
                message: String(error?.message ?? error ?? 'unknown error'),
                ...(error instanceof ProviderTimeoutError ? { timeoutMs: error.timeoutMs } : {}),
            };
        });
        record.inFlight = attempt.finally(() => {
            record.inFlight = null;
        });
        await record.inFlight;
        this.emit(record);
        this.refreshLifecycle();
        return this.statusOf(record);
    }
    async ensure(name) {
        const status = await this.start(name);
        if (status.state === 'ready')
            return;
        const failure = status.failure;
        const reason = failure ? `${failure.message}` : 'initialisation did not succeed';
        const error = new Error(`${name} is unavailable: ${reason}`);
        error.providerName = name;
        error.providerFailure = failure;
        throw error;
    }
    async retry(name) {
        const record = this.providers.get(name);
        if (!record)
            throw new Error(`Unknown provider: ${name}`);
        if (record.inFlight) {
            await record.inFlight;
            if (record.state === 'ready')
                return this.statusOf(record);
        }
        record.state = 'idle';
        record.failure = undefined;
        return this.start(name);
    }
    warmUpOptional() {
        for (const record of this.providers.values()) {
            if (!record.optional || record.state !== 'idle')
                continue;
            void this.start(record.name);
        }
    }
    statuses() {
        return [...this.providers.values()].map((record) => this.statusOf(record));
    }
    snapshot() {
        return { lifecycle: this.getLifecycle(), providers: this.statuses() };
    }
    statusOf(record) {
        return {
            name: record.name,
            optional: record.optional,
            state: record.state,
            attempts: record.attempts,
            ...(record.durationMs != null ? { durationMs: record.durationMs } : {}),
            ...(record.startedAt != null ? { startedAt: new Date(record.startedAt).toISOString() } : {}),
            ...(record.settledAt != null ? { settledAt: new Date(record.settledAt).toISOString() } : {}),
            ...(record.failure ? { failure: record.failure } : {}),
        };
    }
    emit(record) {
        this.onEvent?.({ provider: record.name, state: record.state, failure: record.failure });
    }
    refreshLifecycle() {
        if (this.lifecycle === 'starting' || this.lifecycle === 'shutting_down' || this.lifecycle === 'failed')
            return;
        const all = [...this.providers.values()];
        if (all.some((record) => !record.optional && record.state === 'failed')) {
            this.lifecycle = 'failed';
            return;
        }
        const optional = all.filter((record) => record.optional);
        const settled = optional.every((record) => record.state === 'ready' || record.state === 'unavailable');
        if (!settled) {
            this.lifecycle = 'core_ready';
            return;
        }
        this.lifecycle = optional.every((record) => record.state === 'ready') ? 'fully_ready' : 'degraded';
    }
}
exports.ProviderRegistry = ProviderRegistry;
