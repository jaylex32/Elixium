"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildCorsOptions = exports.readAllowedOrigins = exports.createAuthMiddleware = exports.authorize = exports.isAuthEnabled = exports.rotateToken = exports.getOrCreateToken = exports.extractToken = exports.isLoopback = exports.LOOPBACK_ADDRESSES = exports.TOKEN_QUERY = exports.TOKEN_HEADER = void 0;
const crypto_1 = require("crypto");
exports.TOKEN_HEADER = 'x-elixium-token';
exports.TOKEN_QUERY = 'token';
const PUBLIC_PATHS = new Set(['/health', '/v1/health']);
exports.LOOPBACK_ADDRESSES = new Set(['127.0.0.1', '::1', '::ffff:127.0.0.1']);
const isLoopback = (req) => {
    const address = req.socket?.remoteAddress ?? '';
    return exports.LOOPBACK_ADDRESSES.has(address);
};
exports.isLoopback = isLoopback;
const tokensMatch = (a, b) => {
    if (!a || !b)
        return false;
    const left = (0, crypto_1.createHash)('sha256').update(a).digest();
    const right = (0, crypto_1.createHash)('sha256').update(b).digest();
    return (0, crypto_1.timingSafeEqual)(left, right);
};
const extractToken = (req) => {
    const header = req.headers[exports.TOKEN_HEADER];
    if (typeof header === 'string' && header.trim())
        return header.trim();
    const auth = req.headers.authorization;
    if (typeof auth === 'string' && /^Bearer\s+/i.test(auth)) {
        return auth.replace(/^Bearer\s+/i, '').trim();
    }
    const query = req.query?.[exports.TOKEN_QUERY];
    if (typeof query === 'string' && query.trim())
        return query.trim();
    return '';
};
exports.extractToken = extractToken;
const getOrCreateToken = (conf) => {
    const existing = conf.get('auth.token');
    if (typeof existing === 'string' && existing.length >= 32)
        return existing;
    const token = (0, crypto_1.randomBytes)(32).toString('base64url');
    conf.set('auth.token', token);
    return token;
};
exports.getOrCreateToken = getOrCreateToken;
const rotateToken = (conf) => {
    const token = (0, crypto_1.randomBytes)(32).toString('base64url');
    conf.set('auth.token', token);
    return token;
};
exports.rotateToken = rotateToken;
const isAuthEnabled = (conf) => conf.get('auth.enabled') !== false;
exports.isAuthEnabled = isAuthEnabled;
const authorize = (conf, presented, loopback) => {
    if (!(0, exports.isAuthEnabled)(conf))
        return { ok: true };
    if (loopback)
        return { ok: true };
    const expected = (0, exports.getOrCreateToken)(conf);
    if (!presented)
        return { ok: false, reason: 'missing_token' };
    if (!tokensMatch(presented, expected))
        return { ok: false, reason: 'invalid_token' };
    return { ok: true };
};
exports.authorize = authorize;
const createAuthMiddleware = (conf, basePath) => {
    return (req, res, next) => {
        const relative = req.path.startsWith(basePath) ? req.path.slice(basePath.length) : req.path;
        if (PUBLIC_PATHS.has(relative)) {
            next();
            return;
        }
        const decision = (0, exports.authorize)(conf, (0, exports.extractToken)(req), (0, exports.isLoopback)(req));
        if (decision.ok) {
            next();
            return;
        }
        res.status(401).json({
            ok: false,
            error: {
                code: 'unauthorized',
                message: decision.reason === 'missing_token'
                    ? 'This request needs an API token. Send it as an Authorization: Bearer header, an X-Elixium-Token header, or a ?token= query parameter.'
                    : 'The API token is not valid. It may have been rotated in Settings.',
            },
        });
    };
};
exports.createAuthMiddleware = createAuthMiddleware;
const readAllowedOrigins = (conf) => {
    const raw = conf.get('auth.allowedOrigins');
    if (!Array.isArray(raw))
        return [];
    return raw.filter((entry) => typeof entry === 'string' && entry.trim().length > 0);
};
exports.readAllowedOrigins = readAllowedOrigins;
const buildCorsOptions = (conf) => ({
    origin: (origin, callback) => {
        if (!origin) {
            callback(null, true);
            return;
        }
        const allowed = (0, exports.readAllowedOrigins)(conf);
        if (allowed.includes('*') || allowed.includes(origin)) {
            callback(null, true);
            return;
        }
        if (/^https?:\/\/(localhost|127\.0\.0\.1|\[::1\])(:\d+)?$/i.test(origin)) {
            callback(null, true);
            return;
        }
        callback(null, false);
    },
    credentials: true,
});
exports.buildCorsOptions = buildCorsOptions;
