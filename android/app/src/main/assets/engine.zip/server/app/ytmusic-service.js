"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createYtMusicService = void 0;
const innertube_1 = require("../core/ytmusic/innertube");
const parse_1 = require("../core/ytmusic/parse");
const ytmusic_match_1 = require("./ytmusic-match");
const lyrics_embed_1 = require("../lib/lyrics-embed");
const download_1 = require("../core/ytmusic/download");
const player_1 = require("../core/ytmusic/player");
const cookies_txt_1 = require("../core/ytmusic/cookies-txt");
const axios_1 = __importDefault(require("axios"));
const cookie_jar_1 = require("../core/ytmusic/cookie-jar");
const path_1 = __importDefault(require("path"));
const fs_1 = require("fs");
const util_1 = require("../lib/util");
const CANDIDATE_LIMIT = 8;
const BATCH_SIZE = 4;
const createYtMusicService = ({ search, client, getCookie, setCookie, getDownloadPath, getLayout, getNumberWidth, preferOpus, preferAlbumAudio, strictAlbumAudio, embedLyrics, saveLrcFile, writeProvenance, }) => {
    const http = axios_1.default.create({
        timeout: 60000,
        validateStatus: () => true,
        headers: { 'User-Agent': innertube_1.USER_AGENT, 'Accept-Language': 'en-US,en;q=0.9' },
    });
    http.interceptors.response.use((response) => {
        const current = getCookie?.();
        if (!current)
            return response;
        const rotated = (0, cookie_jar_1.mergeSetCookie)(current, response.headers?.['set-cookie']);
        if (rotated)
            setCookie?.(rotated);
        return response;
    });
    const yt = client ?? new innertube_1.YtMusicClient(http);
    const searchCatalog = async (query, type, limit = 25) => {
        if (!query.trim())
            return [];
        const response = await yt.search(query, type);
        return (0, parse_1.parseSearch)(response, type, limit);
    };
    const searchPage = async (query, type, limit = 25, cursor) => {
        if (!query.trim())
            return { items: [], cursor: null };
        if (cursor) {
            const response = await yt.searchContinuation(cursor);
            return { items: (0, parse_1.parseSearchContinuation)(response, type, limit), cursor: (0, parse_1.continuationOf)(response) };
        }
        const response = await yt.search(query, type);
        return { items: (0, parse_1.parseSearch)(response, type, limit), cursor: (0, parse_1.continuationOf)(response) };
    };
    const artistContent = async (browseId, kind) => {
        const page = await artist(browseId);
        if (!page)
            return [];
        if (kind === 'tracks') {
            const seen = new Set(page.topTracks.map((t) => String(t.id)));
            const found = await searchCatalog(page.name, 'track', 50).catch(() => []);
            return [...page.topTracks, ...found.filter((t) => !seen.has(String(t.id)))];
        }
        const wanted = kind === 'albums' ? 'album' : 'playlist';
        const items = page.releases.filter((item) => item.type === wanted);
        const seen = new Set(items.map((item) => item.id));
        for (const link of page.more[kind] ?? []) {
            try {
                const more = await yt.browseMore(link.browseId, link.params);
                for (const item of (0, parse_1.parseGrid)(more, page.name, 100, browseId)) {
                    if (item.type === wanted && !seen.has(item.id)) {
                        seen.add(item.id);
                        items.push(item);
                    }
                }
            }
            catch {
            }
        }
        return items;
    };
    const album = async (browseId) => (0, parse_1.parseCollection)(await yt.browse(browseId), browseId);
    const playlist = async (browseId) => (0, parse_1.parseCollection)(await yt.browse(browseId), browseId);
    const artist = async (browseId) => (0, parse_1.parseArtist)(await yt.browse(browseId), browseId);
    const home = async (pages = 4) => {
        let response = await yt.browse('FEmusic_home');
        const shelves = (0, parse_1.parseShelves)(response);
        for (let page = 1; page < pages; page += 1) {
            const cursor = (0, parse_1.shelfContinuationOf)(response);
            if (!cursor)
                break;
            try {
                response = await yt.call('browse', { continuation: cursor });
            }
            catch {
                break;
            }
            shelves.push(...(0, parse_1.parseShelves)(response));
        }
        return shelves;
    };
    const newReleases = async () => (0, parse_1.parseShelves)(await yt.browse('FEmusic_new_releases'));
    const charts = async () => (0, parse_1.parseShelves)(await yt.browse('FEmusic_charts'));
    const genres = async () => (0, parse_1.parseGenres)(await yt.browse('FEmusic_moods_and_genres'));
    const shelves = async () => {
        const groups = await Promise.all([home(), charts(), newReleases()].map((p) => p.catch(() => [])));
        const seen = new Set();
        return groups
            .flat()
            .filter((shelf) => shelf.items.length > 0)
            .filter((shelf) => {
            const key = shelf.title.trim().toLowerCase();
            if (!key || seen.has(key))
                return false;
            seen.add(key);
            return true;
        });
    };
    const genreContent = async (params) => (0, parse_1.parseShelves)(await yt.call('browse', { browseId: 'FEmusic_moods_and_genres_category', params }));
    const genreItems = async (params, kind) => {
        const wanted = kind === 'albums' ? 'album' : kind === 'tracks' ? 'track' : kind === 'artists' ? 'artist' : 'playlist';
        const shelves = await genreContent(params);
        const items = [];
        const seen = new Set();
        for (const shelf of shelves) {
            for (const item of shelf.items) {
                if (item.type !== wanted || seen.has(item.id))
                    continue;
                seen.add(item.id);
                items.push(item);
            }
        }
        return items;
    };
    const albumFor = async (title, artist) => {
        const simplify = (text) => text
            .toLowerCase()
            .replace(/\(.*?\)|\[.*?\]/g, '')
            .replace(/[^a-z0-9]+/g, ' ')
            .trim();
        try {
            const found = await searchCatalog(`${title} ${artist}`.trim(), 'track', 5);
            const wanted = simplify(title);
            const hit = found.find((result) => simplify(result.title) === wanted);
            if (hit?.album)
                return hit.album;
        }
        catch {
        }
        return title;
    };
    const withAlbum = (metadata) => metadata.album && metadata.album.trim() ? metadata : { ...metadata, album: metadata.title };
    const swapCache = new Map();
    const remember = (videoId, choice) => {
        swapCache.set(videoId, choice);
        return choice;
    };
    const videoKind = async (videoId) => {
        try {
            const response = await yt.call('player', { videoId });
            const details = response?.videoDetails ?? {};
            const seconds = Number(details.lengthSeconds);
            return {
                kind: String(details.musicVideoType ?? ''),
                title: String(details.title ?? ''),
                artist: String(details.author ?? '').replace(/ - Topic$/, ''),
                durationSeconds: Number.isFinite(seconds) && seconds > 0 ? seconds : null,
            };
        }
        catch {
            return { kind: '', title: '', artist: '', durationSeconds: null };
        }
    };
    const albumAudioFor = async (videoId, hint) => {
        if (!preferAlbumAudio?.())
            return { videoId, replacement: null, outcome: 'already-audio' };
        const cached = swapCache.get(videoId);
        if (cached)
            return cached;
        let kind = String(hint?.musicVideoType ?? '');
        let title = String(hint?.title ?? '');
        let artist = String(hint?.artist ?? '');
        let durationSeconds = hint?.durationSeconds ?? null;
        if (!kind || !title) {
            const details = await videoKind(videoId);
            kind = kind || details.kind;
            title = title || details.title;
            artist = artist || details.artist;
            durationSeconds = durationSeconds ?? details.durationSeconds;
        }
        if (!kind)
            return remember(videoId, { videoId, replacement: null, outcome: 'unknown' });
        if ((0, parse_1.isAlbumAudio)(kind))
            return remember(videoId, { videoId, replacement: null, outcome: 'already-audio' });
        if (!title.trim())
            return remember(videoId, { videoId, replacement: null, outcome: 'unknown' });
        const outcome = await (0, ytmusic_match_1.matchTrack)({ title, artist, durationSeconds: null }, async (query) => {
            const results = await searchCatalog(query, 'track', CANDIDATE_LIMIT);
            return results.filter((result) => {
                if (!(0, parse_1.isAlbumAudio)(result.rawData?.musicVideoType))
                    return false;
                const candidateSeconds = (0, ytmusic_match_1.secondsOf)(result.duration);
                if (!durationSeconds || !candidateSeconds)
                    return true;
                return Math.abs(candidateSeconds - durationSeconds) <= 300;
            });
        });
        const replacement = outcome.match;
        if (!replacement || replacement.id === videoId) {
            const missing = { videoId, replacement: null, outcome: 'kept-video' };
            if (strictAlbumAudio?.())
                return { ...missing, outcome: 'no-audio-found' };
            return remember(videoId, missing);
        }
        return remember(videoId, { videoId: replacement.id, replacement, outcome: 'swapped' });
    };
    const resolveUrl = async (rawUrl) => {
        let parsed;
        try {
            parsed = new URL(rawUrl.trim());
        }
        catch {
            return null;
        }
        const host = parsed.hostname.replace(/^www\./, '');
        if (!/(^|\.)youtube\.com$/.test(host) && host !== 'youtu.be' && host !== 'music.youtube.com')
            return null;
        const path = parsed.pathname;
        const listId = parsed.searchParams.get('list');
        const videoId = host === 'youtu.be' ? path.slice(1).split('/')[0] : parsed.searchParams.get('v');
        const browseMatch = /\/(?:browse|playlist)\/([\w-]+)/.exec(path);
        const browseId = browseMatch?.[1];
        if (browseId?.startsWith('MPRE')) {
            const found = await album(browseId);
            return found ? { kind: 'album', title: found.title, tracks: found.tracks } : null;
        }
        const channel = /\/channel\/([\w-]+)/.exec(path)?.[1];
        if (channel) {
            const found = await artist(channel);
            return found ? { kind: 'artist', title: found.name, tracks: found.topTracks } : null;
        }
        const list = listId ?? (browseId && !browseId.startsWith('MPRE') ? browseId : undefined);
        if (list) {
            const id = list.startsWith('VL') || list.startsWith('MPRE') ? list : `VL${list}`;
            const found = await playlist(id);
            if (found)
                return { kind: 'playlist', title: found.title, tracks: found.tracks };
        }
        if (videoId && /^[\w-]{11}$/.test(videoId)) {
            const details = (await yt.call('player', { videoId }))?.videoDetails;
            if (!details)
                return null;
            const seconds = Number(details.lengthSeconds) || 0;
            const cover = details?.thumbnail?.thumbnails?.slice(-1)?.[0]?.url ?? '';
            const name = String(details.title ?? '');
            const by = String(details.author ?? '').replace(/ - Topic$/, '');
            return {
                kind: 'track',
                title: name,
                tracks: [
                    {
                        id: videoId,
                        title: name,
                        artist: by,
                        album: await albumFor(name, by),
                        duration: seconds ? `${Math.floor(seconds / 60)}:${String(seconds % 60).padStart(2, '0')}` : '',
                        type: 'track',
                        rawData: { ytmusic: true, videoId, cover, durationSeconds: seconds },
                    },
                ],
            };
        }
        return null;
    };
    const resolveTrack = async (track, preferred = 'deezer') => {
        const source = {
            title: track.title,
            artist: track.artist,
            durationSeconds: track.rawData?.durationSeconds ?? null,
        };
        const order = preferred === 'deezer' ? ['deezer', 'qobuz'] : ['qobuz', 'deezer'];
        let best = null;
        for (const service of order) {
            const outcome = await (0, ytmusic_match_1.matchTrack)(source, (query) => search(service, query, 'track', CANDIDATE_LIMIT));
            if (outcome.reason === 'matched') {
                return {
                    source: track,
                    match: outcome.match,
                    service,
                    confidence: outcome.score?.score ?? null,
                    reason: 'matched',
                };
            }
            if (!best || (outcome.score?.score ?? 0) > (best.outcome.score?.score ?? 0))
                best = { outcome, service };
        }
        return {
            source: track,
            match: null,
            service: null,
            confidence: best?.outcome.score?.score ?? null,
            reason: best?.outcome.reason ?? 'no-results',
        };
    };
    const matchToYtMusic = async (sources) => {
        const matched = [];
        for (let index = 0; index < sources.length; index += BATCH_SIZE) {
            const batch = sources.slice(index, index + BATCH_SIZE);
            matched.push(...(await Promise.all(batch.map(async (source) => {
                const outcome = await (0, ytmusic_match_1.matchTrack)({ title: source.title, artist: source.artist, durationSeconds: source.durationSeconds ?? null }, (query) => searchCatalog(query, 'track', CANDIDATE_LIMIT));
                return {
                    source: { title: source.title, artist: source.artist },
                    match: outcome.match,
                    reason: outcome.reason,
                };
            }))));
        }
        return matched;
    };
    const resolveTracks = async (tracks, preferred = 'deezer') => {
        const resolved = [];
        for (let index = 0; index < tracks.length; index += BATCH_SIZE) {
            const batch = tracks.slice(index, index + BATCH_SIZE);
            resolved.push(...(await Promise.all(batch.map((track) => resolveTrack(track, preferred)))));
        }
        return resolved;
    };
    const check = async () => {
        const results = await searchCatalog('daft punk', 'track', 1);
        if (results.length === 0) {
            throw new innertube_1.YtMusicError('parse', 'YouTube Music returned nothing recognisable — their page layout may have changed');
        }
    };
    const download = async (videoId, metadata, outputBase, onProgress) => (0, download_1.downloadTrack)(videoId, withAlbum(metadata), outputBase, {
        cookie: getCookie?.(),
        preferOpus: preferOpus?.(),
        onProgress,
        http,
    });
    const importCookiesTxt = async (text) => {
        const summary = (0, cookies_txt_1.cookieHeaderFromCookiesTxt)(text);
        setCookie?.(summary.cookie);
        const check = await (0, cookies_txt_1.verifyYouTubeSession)(summary.cookie);
        return { ...summary, signedIn: check ? check.signedIn : null, ...(check?.account ? { account: check.account } : {}) };
    };
    const downloadToLibrary = async (videoId, raw, onProgress, formatOverride) => {
        const choice = await albumAudioFor(videoId, {
            title: raw.title,
            artist: raw.artist,
            musicVideoType: raw.musicVideoType,
        });
        if (choice.outcome === 'no-audio-found') {
            throw new Error(`No album audio exists for "${raw.title}" — only a music video, which strict mode refuses`);
        }
        const chosenId = choice.videoId;
        const named = choice.replacement
            ? {
                ...raw,
                title: choice.replacement.title || raw.title,
                artist: choice.replacement.artist || raw.artist,
                album: choice.replacement.album || raw.album,
                coverUrl: (choice.replacement.rawData?.cover ?? raw.coverUrl) || raw.coverUrl,
            }
            : raw;
        const metadata = withAlbum(named);
        const root = getDownloadPath?.() || path_1.default.join('Music', 'YouTube Music');
        const template = getLayout?.() || '{album_artist}/{album}/{track_number} {title}';
        const relative = (0, util_1.ytmusicSaveLayout)({
            fields: {
                title: metadata.title,
                artist: metadata.artist,
                album: metadata.album,
                albumArtist: metadata.albumArtist,
                year: metadata.year ?? null,
                trackNumber: metadata.trackNumber ?? null,
                trackTotal: metadata.trackTotal ?? null,
                videoId: chosenId,
            },
            path: template,
            minimumIntegerDigits: getNumberWidth?.() || 2,
        });
        const base = path_1.default.join(root, relative);
        const folder = path_1.default.dirname(base);
        for (const extension of ['.m4a', '.opus']) {
            const existing = base + extension;
            if ((0, fs_1.existsSync)(existing)) {
                return { path: existing, folder, tagged: true, bitrate: 0, skipped: true };
            }
        }
        const wantsLyrics = Boolean(embedLyrics?.() || saveLrcFile?.());
        const found = wantsLyrics
            ? await (0, lyrics_embed_1.lookupLyrics)({
                artist: metadata.artist,
                title: metadata.title,
                album: metadata.album,
            }).catch(() => null)
            : null;
        const tagged = found?.text && embedLyrics?.() ? { ...metadata, lyrics: found.text } : metadata;
        const withProvenance = writeProvenance?.() === false ? { ...tagged, comment: undefined } : tagged;
        const result = await (0, download_1.downloadTrack)(chosenId, withProvenance, base, {
            cookie: getCookie?.(),
            preferOpus: formatOverride ? formatOverride === 'opus' : preferOpus?.(),
            onProgress,
            http,
        });
        if (found?.synced?.length && saveLrcFile?.()) {
            try {
                (0, fs_1.writeFileSync)((0, lyrics_embed_1.lrcPathFor)(result.path), (0, lyrics_embed_1.toLrc)(found, { artist: metadata.artist, title: metadata.title, album: metadata.album }), 'utf8');
            }
            catch {
            }
        }
        return { path: result.path, folder, tagged: result.tagged, bitrate: result.bitrate, skipped: false };
    };
    const streamUrl = async (videoId) => {
        const stream = await (0, player_1.getAudioStream)(videoId, { cookie: getCookie?.(), http });
        return stream ? { url: stream.url, mimeType: stream.mimeType || 'audio/mp4' } : null;
    };
    const lyrics = async (videoId) => {
        const next = await yt.call('next', { videoId });
        const tabs = next?.contents?.singleColumnMusicWatchNextResultsRenderer?.tabbedRenderer?.watchNextTabbedResultsRenderer?.tabs;
        const tab = (Array.isArray(tabs) ? tabs : []).find((entry) => /lyric/i.test(String(entry?.tabRenderer?.title ?? '')));
        const browseId = tab?.tabRenderer?.endpoint?.browseEndpoint?.browseId;
        if (!browseId)
            return null;
        const page = await yt.browse(String(browseId));
        const shelf = page?.contents?.sectionListRenderer?.contents?.[0]?.musicDescriptionShelfRenderer;
        const text = (shelf?.description?.runs ?? []).map((run) => String(run?.text ?? '')).join('');
        if (!text.trim())
            return null;
        const footer = (shelf?.footer?.runs ?? []).map((run) => String(run?.text ?? '')).join('');
        return { text, source: footer.replace(/^Source:\s*/i, '').trim() || 'YouTube Music' };
    };
    const isSignedIn = () => Boolean(getCookie?.());
    return {
        searchCatalog,
        album,
        playlist,
        artist,
        resolveTrack,
        resolveTracks,
        download,
        downloadToLibrary,
        albumAudioFor,
        streamUrl,
        home,
        newReleases,
        charts,
        genres,
        genreContent,
        shelves,
        searchPage,
        artistContent,
        genreItems,
        resolveUrl,
        matchToYtMusic,
        importCookiesTxt,
        lyrics,
        isSignedIn,
        check,
    };
};
exports.createYtMusicService = createYtMusicService;
