"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createArtistContent = void 0;
const util_1 = require("../lib/util");
const toReleaseDate = (value) => {
    if (typeof value !== 'string' || value.length === 0)
        return null;
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime()))
        return null;
    return parsed.toISOString().slice(0, 10);
};
const toYear = (value) => {
    const date = toReleaseDate(value);
    return date ? Number(date.slice(0, 4)) : null;
};
const dedupeReleases = (items) => {
    const seen = new Set();
    return items.filter((item) => {
        const key = `${item.title.toLowerCase()}|${item.releaseDate ?? ''}`;
        if (seen.has(key))
            return false;
        seen.add(key);
        return true;
    });
};
const COUNT_TTL = 30 * 60 * 1000;
const COUNT_CONCURRENCY = 6;
const COUNT_BUDGET_MS = 2500;
const albumTrackCounts = new Map();
const publicTrackCounts = async (makeHttpRequest, albumIds) => {
    const counts = new Map();
    const pending = [];
    for (const id of albumIds) {
        const cached = albumTrackCounts.get(id);
        if (cached && Date.now() - cached.at < COUNT_TTL)
            counts.set(id, cached.count);
        else
            pending.push(id);
    }
    if (pending.length === 0)
        return counts;
    const deadline = Date.now() + COUNT_BUDGET_MS;
    let cursor = 0;
    const worker = async () => {
        while (cursor < pending.length && Date.now() < deadline) {
            const id = pending[cursor++];
            try {
                const album = await makeHttpRequest(`https://api.deezer.com/album/${encodeURIComponent(id)}`);
                const count = Number(album?.nb_tracks || 0);
                if (count > 0) {
                    counts.set(id, count);
                    albumTrackCounts.set(id, { at: Date.now(), count });
                }
            }
            catch {
            }
        }
    };
    await Promise.all(Array.from({ length: Math.min(COUNT_CONCURRENCY, pending.length) }, worker));
    if (albumTrackCounts.size > 2000)
        albumTrackCounts.clear();
    return counts;
};
const toTrackCount = (value) => {
    const count = Number(value || 0);
    return Number.isFinite(count) && count > 0 ? count : undefined;
};
const releaseLabel = (recordType, trackCount) => {
    const count = Number(trackCount || 0);
    if (count > 0)
        return `${count} track${count === 1 ? '' : 's'}`;
    const kind = String(recordType || '').trim();
    if (!kind)
        return '';
    return kind.toUpperCase() === 'EP' ? 'EP' : kind.charAt(0).toUpperCase() + kind.slice(1).toLowerCase();
};
const createArtistContent = ({ deezer, qobuz, makeHttpRequest, ensureQobuzSearchReady, }) => {
    const getArtistAlbums = async (service, artistId, limit = 30, offset = 0, artistName) => {
        const knownArtist = artistName && String(artistName).trim().length > 0 ? String(artistName).trim() : '';
        if (service === 'deezer') {
            const url = `https://api.deezer.com/artist/${encodeURIComponent(artistId)}/albums?limit=${Number(limit)}&index=${Number(offset)}`;
            const response = await makeHttpRequest(url);
            const releases = (response && response.data) || [];
            const counts = await publicTrackCounts(makeHttpRequest, releases.map((album) => String(album.id)));
            return dedupeReleases(releases.map((album) => ({
                id: String(album.id),
                title: album.title,
                artist: album.artist?.name || knownArtist || 'Unknown Artist',
                album: album.title,
                type: 'album',
                duration: releaseLabel(album.record_type, album.nb_tracks),
                trackCount: counts.get(String(album.id)) ?? toTrackCount(album.nb_tracks),
                year: toYear(album.release_date),
                releaseDate: toReleaseDate(album.release_date),
                rawData: album,
            })));
        }
        if (service === 'qobuz') {
            await ensureQobuzSearchReady();
            const response = await qobuz.qobuzRequest?.('artist/get', {
                artist_id: artistId,
                extra: 'albums',
                offset: Number(offset),
                limit: Number(limit),
            });
            return dedupeReleases((response?.albums?.items || []).map((album) => ({
                id: String(album.id),
                title: album.title,
                artist: album.artist?.name || knownArtist || 'Unknown Artist',
                album: album.title,
                type: 'album',
                duration: releaseLabel(album.release_type, album.tracks_count),
                trackCount: toTrackCount(album.tracks_count),
                year: toYear(album.release_date_original),
                releaseDate: toReleaseDate(album.release_date_original),
                maximum_bit_depth: album.maximum_bit_depth,
                maximum_sampling_rate: album.maximum_sampling_rate,
                hires: album.hires,
                rawData: album,
            })));
        }
        return [];
    };
    const getArtistTracks = async (service, artistId, limit = 50, offset = 0, artistName) => {
        const knownArtist = artistName && String(artistName).trim().length > 0 ? String(artistName).trim() : '';
        if (service === 'deezer') {
            const url = `https://api.deezer.com/artist/${encodeURIComponent(artistId)}/top?limit=${Number(limit)}&index=${Number(offset)}`;
            const response = await makeHttpRequest(url);
            return ((response && response.data) || []).map((track) => ({
                id: String(track.id),
                title: track.title + (track.version ? ` ${track.version}` : ''),
                artist: track.artist?.name || knownArtist || 'Unknown Artist',
                album: track.album?.title || '',
                type: 'track',
                duration: (0, util_1.formatSecondsReadable)(Number(track.duration || 0)),
                rawData: track,
            }));
        }
        if (service === 'qobuz') {
            await ensureQobuzSearchReady();
            const response = await qobuz.qobuzRequest?.('artist/get', {
                artist_id: artistId,
                extra: 'tracks',
                offset: Number(offset),
                limit: Number(limit),
            });
            return (response?.tracks?.items || []).map((track) => ({
                id: String(track.id),
                title: track.title + (track.version ? ` (${track.version})` : ''),
                artist: track.performer?.name || knownArtist || 'Unknown Artist',
                album: track.album?.title || '',
                type: 'track',
                duration: (0, util_1.formatSecondsReadable)(Number(track.duration || 0)),
                rawData: track,
            }));
        }
        return [];
    };
    const getArtistPlaylists = async (service, artistId, artistName, limit = 30, offset = 0) => {
        const query = artistName && String(artistName).trim().length > 0 ? String(artistName) : String(artistId);
        if (service === 'deezer') {
            const result = await deezer.searchMusicPaged(query, 'PLAYLIST', Number(limit), Number(offset));
            return (result?.data || []).map((playlist) => ({
                id: String(playlist.PLAYLIST_ID || playlist.id),
                title: playlist.TITLE || playlist.title,
                artist: playlist.PARENT_USERNAME || playlist.user?.name || 'Deezer',
                album: 'Playlist',
                type: 'playlist',
                duration: `${playlist.NB_SONG || playlist.nb_tracks || 0} tracks`,
                rawData: playlist,
            }));
        }
        if (service === 'qobuz') {
            await ensureQobuzSearchReady();
            const result = await qobuz.searchMusic(query, 'playlist', Number(limit), Number(offset));
            return (result.playlists?.items || []).map((playlist) => ({
                id: String(playlist.id),
                title: playlist.name,
                artist: playlist.owner?.name || 'Qobuz',
                album: 'Playlist',
                type: 'playlist',
                duration: `${playlist.tracks_count || 0} tracks`,
                rawData: playlist,
            }));
        }
        return [];
    };
    return { getArtistAlbums, getArtistTracks, getArtistPlaylists };
};
exports.createArtistContent = createArtistContent;
