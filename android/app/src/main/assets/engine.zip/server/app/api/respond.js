"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parsePaging = exports.parseInt_ = exports.requireString = exports.parseService = exports.route = exports.sendError = exports.upstreamStatus = exports.retryAfterSeconds = exports.sendData = exports.ApiError = void 0;
const STATUS_BY_CODE = {
    bad_request: 400,
    not_found: 404,
    unsupported_service: 400,
    service_unavailable: 503,
    upstream_error: 502,
    not_configured: 409,
    rate_limited: 429,
    unauthorized: 401,
    forbidden: 403,
    internal_error: 500,
};
class ApiError extends Error {
    constructor(code, message, details) {
        super(message);
        this.name = 'ApiError';
        this.code = code;
        this.details = details;
    }
    get status() {
        return STATUS_BY_CODE[this.code] ?? 500;
    }
    static badRequest(message, details) {
        return new ApiError('bad_request', message, details);
    }
    static notFound(message, details) {
        return new ApiError('not_found', message, details);
    }
    static unsupportedService(service) {
        return new ApiError('unsupported_service', `Unsupported service: ${service || '(none)'}`, {
            supported: ['deezer', 'qobuz'],
        });
    }
    static notConfigured(message, details) {
        return new ApiError('not_configured', message, details);
    }
}
exports.ApiError = ApiError;
const sendData = (res, data, meta) => {
    return res.json(meta ? { ok: true, data, meta } : { ok: true, data });
};
exports.sendData = sendData;
const retryAfterSeconds = (error) => {
    const header = error?.headers?.['retry-after'];
    const seconds = Number(header);
    return Number.isFinite(seconds) && seconds > 0 ? seconds : undefined;
};
exports.retryAfterSeconds = retryAfterSeconds;
const upstreamStatus = (error) => {
    const status = error?.statusCode;
    return Number.isFinite(status) ? status : undefined;
};
exports.upstreamStatus = upstreamStatus;
const toMessage = (error) => {
    if (typeof error === 'string')
        return error;
    const status = (0, exports.upstreamStatus)(error);
    if (status) {
        const retry = (0, exports.retryAfterSeconds)(error);
        const nested = error?.body;
        const detail = nested?.error?.message;
        if (status === 429) {
            return `Spotify is rate limiting this server${retry ? ` — retry in ${retry}s` : ''}.`;
        }
        if (status === 401 || status === 403) {
            return detail ?? 'Spotify rejected the request — the sp_dc cookie may need renewing.';
        }
        if (detail)
            return `Spotify error ${status}: ${detail}`;
    }
    if (error instanceof Error) {
        if (error.message && error.message !== '[object Object]')
            return error.message;
        const cause = error.cause;
        if (cause)
            return toMessage(cause);
    }
    if (error && typeof error === 'object') {
        const asRecord = error;
        for (const key of ['message', 'error', 'description', 'reason']) {
            const value = asRecord[key];
            if (typeof value === 'string' && value && value !== '[object Object]')
                return value;
        }
        try {
            const json = JSON.stringify(error);
            if (json && json !== '{}')
                return json.slice(0, 300);
        }
        catch {
        }
    }
    return 'Internal error';
};
const NOT_FOUND_PATTERNS = /no match|not found|no tracks found|could not find|unavailable/i;
const sendError = (res, error) => {
    if (error instanceof ApiError) {
        return res.status(error.status).json({
            ok: false,
            error: { code: error.code, message: error.message, ...(error.details ? { details: error.details } : {}) },
        });
    }
    const message = toMessage(error);
    if ((0, exports.upstreamStatus)(error) === 429) {
        const retry = (0, exports.retryAfterSeconds)(error);
        if (retry)
            res.setHeader('Retry-After', String(retry));
        return res.status(429).json({
            ok: false,
            error: { code: 'rate_limited', message, ...(retry ? { details: { retryAfterSeconds: retry } } : {}) },
        });
    }
    const providerFailure = error;
    if (typeof providerFailure?.providerName === 'string') {
        return res.status(503).json({
            ok: false,
            error: {
                code: 'service_unavailable',
                message,
                details: {
                    provider: providerFailure.providerName,
                    ...(providerFailure.providerFailure?.kind ? { kind: providerFailure.providerFailure.kind } : {}),
                    retryable: true,
                },
            },
        });
    }
    if (NOT_FOUND_PATTERNS.test(message)) {
        return res.status(404).json({ ok: false, error: { code: 'not_found', message } });
    }
    return res.status(500).json({ ok: false, error: { code: 'internal_error', message } });
};
exports.sendError = sendError;
const route = (handler) => {
    return (req, res, next) => {
        Promise.resolve(handler(req, res)).catch((error) => {
            if (res.headersSent)
                return next(error);
            (0, exports.sendError)(res, error);
        });
    };
};
exports.route = route;
const parseService = (value) => {
    const service = String(value ?? '')
        .trim()
        .toLowerCase();
    if (service === 'deezer' || service === 'qobuz')
        return service;
    throw ApiError.unsupportedService(service);
};
exports.parseService = parseService;
const requireString = (value, field) => {
    const parsed = String(value ?? '').trim();
    if (!parsed)
        throw ApiError.badRequest(`Missing required field: ${field}`);
    return parsed;
};
exports.requireString = requireString;
const parseInt_ = (value, fallback, min, max) => {
    const parsed = Number(value);
    if (!Number.isFinite(parsed))
        return fallback;
    return Math.min(max, Math.max(min, Math.trunc(parsed)));
};
exports.parseInt_ = parseInt_;
const parsePaging = (query, defaultLimit = 50, maxLimit = 200) => {
    return {
        limit: (0, exports.parseInt_)(query.limit, defaultLimit, 1, maxLimit),
        offset: (0, exports.parseInt_)(query.offset, 0, 0, 1000000),
    };
};
exports.parsePaging = parsePaging;
