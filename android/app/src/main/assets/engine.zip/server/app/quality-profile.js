"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isReadablePath = exports.needsUpgrade = exports.bestAvailableTier = exports.writeQualityProfile = exports.readQualityProfile = exports.DEFAULT_QUALITY_PROFILE = exports.classifyFileQuality = exports.meetsCutoff = exports.QUALITY_TIER_LABELS = exports.QUALITY_TIERS = void 0;
const fs_1 = require("fs");
exports.QUALITY_TIERS = ['mp3', 'lossless', 'hires'];
exports.QUALITY_TIER_LABELS = {
    mp3: 'MP3',
    lossless: 'FLAC 16-bit',
    hires: 'FLAC 24-bit (hi-res)',
};
const tierRank = (tier) => exports.QUALITY_TIERS.indexOf(tier);
const meetsCutoff = (have, cutoff) => have !== null && tierRank(have) >= tierRank(cutoff);
exports.meetsCutoff = meetsCutoff;
const readFlacBitDepth = (filePath) => {
    let fd = null;
    try {
        fd = (0, fs_1.openSync)(filePath, 'r');
        const buf = Buffer.alloc(26);
        const read = (0, fs_1.readSync)(fd, buf, 0, 26, 0);
        if (read < 26 || buf.toString('latin1', 0, 4) !== 'fLaC')
            return null;
        const packed = buf.readUInt32BE(18);
        const bitDepth = ((packed >>> 4) & 0x1f) + 1;
        return bitDepth > 0 && bitDepth <= 32 ? bitDepth : null;
    }
    catch {
        return null;
    }
    finally {
        if (fd !== null) {
            try {
                (0, fs_1.closeSync)(fd);
            }
            catch {
            }
        }
    }
};
const classifyFileQuality = (filePath, probeDepth = false) => {
    const lower = filePath.toLowerCase();
    if (lower.endsWith('.flac')) {
        if (!probeDepth)
            return 'lossless';
        const depth = readFlacBitDepth(filePath);
        return depth !== null && depth > 16 ? 'hires' : 'lossless';
    }
    if (lower.endsWith('.mp3') || lower.endsWith('.m4a') || lower.endsWith('.aac') || lower.endsWith('.ogg')) {
        return 'mp3';
    }
    return null;
};
exports.classifyFileQuality = classifyFileQuality;
exports.DEFAULT_QUALITY_PROFILE = {
    cutoff: 'lossless',
    upgradeExisting: false,
};
const readQualityProfile = (conf) => {
    const raw = conf.get('qualityProfile');
    const cutoff = raw?.cutoff;
    return {
        cutoff: exports.QUALITY_TIERS.includes(cutoff) ? cutoff : exports.DEFAULT_QUALITY_PROFILE.cutoff,
        upgradeExisting: raw?.upgradeExisting === true,
    };
};
exports.readQualityProfile = readQualityProfile;
const writeQualityProfile = (conf, patch) => {
    const current = (0, exports.readQualityProfile)(conf);
    const next = {
        cutoff: exports.QUALITY_TIERS.includes(patch.cutoff) ? patch.cutoff : current.cutoff,
        upgradeExisting: typeof patch.upgradeExisting === 'boolean' ? patch.upgradeExisting : current.upgradeExisting,
    };
    conf.set('qualityProfile', next);
    return next;
};
exports.writeQualityProfile = writeQualityProfile;
const bestAvailableTier = (service, album) => {
    if (service === 'deezer')
        return 'lossless';
    return Number(album?.maximum_bit_depth) > 16 ? 'hires' : 'lossless';
};
exports.bestAvailableTier = bestAvailableTier;
const needsUpgrade = (have, profile, available) => {
    if (!profile.upgradeExisting)
        return false;
    if (have === null)
        return false;
    if ((0, exports.meetsCutoff)(have, profile.cutoff))
        return false;
    return tierRank(available) > tierRank(have);
};
exports.needsUpgrade = needsUpgrade;
const isReadablePath = (target) => Boolean(target) && (0, fs_1.existsSync)(target);
exports.isReadablePath = isReadablePath;
