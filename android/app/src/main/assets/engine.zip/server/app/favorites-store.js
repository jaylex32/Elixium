"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createFavoritesStore = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const keyOf = (service, type, id) => `${service}:${type}:${id}`;
const createFavoritesStore = (filePath) => {
    let favorites = [];
    let loaded = false;
    const load = () => {
        if (loaded)
            return;
        loaded = true;
        try {
            const raw = fs_1.default.readFileSync(filePath, 'utf8');
            const parsed = JSON.parse(raw);
            favorites = Array.isArray(parsed?.favorites) ? parsed.favorites : [];
        }
        catch {
            favorites = [];
        }
    };
    const persist = () => {
        try {
            fs_1.default.mkdirSync(path_1.default.dirname(filePath), { recursive: true });
            fs_1.default.writeFileSync(filePath, JSON.stringify({ favorites }, null, 2), 'utf8');
        }
        catch (error) {
            console.error('Could not save favorites:', error?.message ?? error);
        }
    };
    const list = (type, service) => {
        load();
        return favorites
            .filter((entry) => (!type || entry.type === type) && (!service || entry.service === service))
            .sort((a, b) => b.addedAt - a.addedAt);
    };
    const has = (service, type, id) => {
        load();
        return favorites.some((entry) => keyOf(entry.service, entry.type, entry.id) === keyOf(service, type, id));
    };
    const add = (record) => {
        load();
        const key = keyOf(record.service, record.type, record.id);
        favorites = favorites.filter((entry) => keyOf(entry.service, entry.type, entry.id) !== key);
        favorites.push({ ...record, addedAt: Date.now() });
        persist();
        return list();
    };
    const remove = (service, type, id) => {
        load();
        const key = keyOf(service, type, id);
        favorites = favorites.filter((entry) => keyOf(entry.service, entry.type, entry.id) !== key);
        persist();
        return list();
    };
    const toggle = (record) => {
        if (has(record.service, record.type, record.id)) {
            return { favorited: false, favorites: remove(record.service, record.type, record.id) };
        }
        return { favorited: true, favorites: add(record) };
    };
    const clear = () => {
        load();
        favorites = [];
        persist();
        return [];
    };
    return { list, has, add, remove, toggle, clear };
};
exports.createFavoritesStore = createFavoritesStore;
