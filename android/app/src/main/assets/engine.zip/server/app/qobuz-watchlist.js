"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createQobuzWatchlistService = exports.invalidateLibraryIndex = exports.classifyReleaseType = exports.stripEditionMarkers = exports.normalizeWatchlistText = void 0;
const fs_1 = require("fs");
const quality_profile_1 = require("./quality-profile");
const path_1 = __importDefault(require("path"));
const core_1 = require("../core");
const spotify_1 = require("../core/converter/spotify");
const to_qobuz_parser_1 = require("../lib/to-qobuz-parser");
const watchlist_store_1 = require("./watchlist-store");
const FALLBACK_QOBUZ_GENRES = [
    { id: 'pop', label: 'Pop', service: 'qobuz' },
    { id: 'hip-hop', label: 'Hip-Hop', service: 'qobuz' },
    { id: 'jazz', label: 'Jazz', service: 'qobuz' },
    { id: 'electronic', label: 'Electronic', service: 'qobuz' },
    { id: 'classical', label: 'Classical', service: 'qobuz' },
    { id: 'rock', label: 'Rock', service: 'qobuz' },
];
const normalizeWatchlistText = (value) => String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/&/g, ' and ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
exports.normalizeWatchlistText = normalizeWatchlistText;
const EDITION_MARKERS = [
    'deluxe',
    'deluxe edition',
    'super deluxe',
    'expanded',
    'expanded edition',
    'remaster',
    'remastered',
    'remastered version',
    'anniversary edition',
    'special edition',
    'limited edition',
    'collectors edition',
    'bonus track version',
    'bonus tracks',
    'explicit',
    'clean',
    'standard edition',
    'original mix',
    'single version',
    'radio edit',
];
const stripEditionMarkers = (value) => {
    let text = String(value || '');
    text = text.replace(/[([]([^)\]]*)[)\]]/g, (match, inner) => {
        const cleaned = (0, exports.normalizeWatchlistText)(inner)
            .replace(/\b(19|20)\d{2}\b/g, '')
            .replace(/\b\d+(st|nd|rd|th)\b/g, '')
            .replace(/\s+/g, ' ')
            .trim();
        if (!cleaned)
            return '';
        return EDITION_MARKERS.includes(cleaned) ? '' : match;
    });
    text = text.replace(/\s[-–—]\s([^-–—]+)$/, (match, tail) => {
        const cleaned = (0, exports.normalizeWatchlistText)(tail)
            .replace(/\b(19|20)\d{2}\b/g, '')
            .replace(/\b\d+(st|nd|rd|th)\b/g, '')
            .replace(/\s+/g, ' ')
            .trim();
        return EDITION_MARKERS.includes(cleaned) ? '' : match;
    });
    return text.trim();
};
exports.stripEditionMarkers = stripEditionMarkers;
const classifyReleaseType = (album) => {
    const title = (0, exports.normalizeWatchlistText)(album?.title || album?.name || '');
    const version = (0, exports.normalizeWatchlistText)(album?.version || '');
    const artistName = (0, exports.normalizeWatchlistText)(album?.artist?.name || '');
    const trackCount = Number(album?.tracks_count) || 0;
    const durationSec = Number(album?.duration) || 0;
    const haystack = `${title} ${version}`;
    if (/\blive\b|\bin concert\b|\bunplugged\b|\bsession(s)?\b/.test(haystack))
        return 'live';
    if (/\bcompilation\b|\bgreatest hits\b|\bbest of\b|\banthology\b|\bcollection\b/.test(haystack)) {
        return 'compilation';
    }
    if (/\bvarious artists\b|\bva\b/.test(artistName))
        return 'compilation';
    if (/\bsingle\b/.test(haystack))
        return 'single';
    if (/\bep\b/.test(haystack))
        return 'ep';
    if (trackCount > 0) {
        if (trackCount <= 2)
            return 'single';
        if (trackCount <= 6 && durationSec > 0 && durationSec < 30 * 60)
            return 'ep';
        if (trackCount <= 4)
            return 'ep';
    }
    return 'album';
};
exports.classifyReleaseType = classifyReleaseType;
const buildAlbumKey = (artist, title) => `${(0, exports.normalizeWatchlistText)(artist)}::${(0, exports.normalizeWatchlistText)((0, exports.stripEditionMarkers)(title))}`;
const buildLegacyAlbumKey = (artist, title) => `${(0, exports.normalizeWatchlistText)(artist)}::${(0, exports.normalizeWatchlistText)(title)}`;
const buildTrackKey = (artist, title) => buildAlbumKey(artist, title);
const WATCHLIST_ARTIST_ALBUM_PAGE_SIZE = 100;
const WATCHLIST_PLAYLIST_TRACK_PAGE_SIZE = 100;
const SCHEDULER_TICK_MS = 60000;
const normalizePlaylistImage = (...values) => {
    for (const value of values) {
        const normalized = String(value || '').trim();
        if (normalized)
            return normalized;
    }
    return '';
};
const extractPlaylistTrackImage = (tracks) => {
    if (!Array.isArray(tracks))
        return '';
    for (const track of tracks) {
        const image = normalizePlaylistImage(track?.album?.image?.large, track?.album?.image?.thumbnail, track?.album?.image?.small, track?.image, track?.rawData?.album?.image?.large, track?.rawData?.album?.image?.thumbnail, track?.rawData?.album?.image?.small, track?.rawData?.album?.cover, track?.rawData?.cover);
        if (image)
            return image;
    }
    return '';
};
const libraryIndexCache = new Map();
const libraryIndexInflight = new Map();
const LIBRARY_INDEX_TTL_MS = 60000;
const invalidateLibraryIndex = () => {
    libraryIndexCache.clear();
};
exports.invalidateLibraryIndex = invalidateLibraryIndex;
const scanLibrary = async (rootPath, probeDepth) => {
    const names = new Map();
    if (!rootPath || !(0, fs_1.existsSync)(rootPath))
        return names;
    const write = (key, tier) => {
        if (!key)
            return;
        if (!tier) {
            if (!names.has(key))
                names.set(key, 'mp3');
            return;
        }
        const existing = names.get(key);
        if (!existing || quality_profile_1.QUALITY_TIERS.indexOf(tier) > quality_profile_1.QUALITY_TIERS.indexOf(existing))
            names.set(key, tier);
    };
    const record = (rawName, tier) => {
        const normalized = (0, exports.normalizeWatchlistText)(rawName);
        write(normalized, tier);
        const separator = rawName.indexOf(' - ');
        if (separator > 0) {
            write((0, exports.normalizeWatchlistText)(rawName.slice(separator + 3)), tier);
            write((0, exports.normalizeWatchlistText)((0, exports.stripEditionMarkers)(rawName.slice(separator + 3))), tier);
        }
        write((0, exports.normalizeWatchlistText)((0, exports.stripEditionMarkers)(rawName)), tier);
    };
    const stack = [{ dir: rootPath, ancestors: [] }];
    let filesSinceYield = 0;
    while (stack.length > 0) {
        if (filesSinceYield >= 200) {
            filesSinceYield = 0;
            await new Promise((resolve) => setImmediate(resolve));
        }
        const { dir, ancestors } = stack.pop();
        let entries;
        try {
            entries = (0, fs_1.readdirSync)(dir, { withFileTypes: true });
        }
        catch {
            continue;
        }
        for (const entry of entries) {
            const fullPath = path_1.default.join(dir, entry.name);
            const rawName = path_1.default.parse(entry.name).name || entry.name;
            if (entry.isDirectory()) {
                record(rawName, null);
                stack.push({ dir: fullPath, ancestors: rawName ? [...ancestors, rawName] : ancestors });
                continue;
            }
            const tier = (0, quality_profile_1.classifyFileQuality)(fullPath, probeDepth);
            filesSinceYield++;
            record(rawName, tier);
            if (tier)
                for (const ancestor of ancestors)
                    record(ancestor, tier);
        }
    }
    return names;
};
const collectFilesystemTokens = async (rootPath, probeDepth = false) => {
    if (!rootPath || !(0, fs_1.existsSync)(rootPath))
        return new Map();
    const cacheKey = rootPath + (probeDepth ? '::deep' : '');
    const cached = libraryIndexCache.get(cacheKey);
    if (cached && Date.now() - cached.at < LIBRARY_INDEX_TTL_MS)
        return cached.index;
    const inflight = libraryIndexInflight.get(cacheKey);
    if (inflight)
        return inflight;
    const run = scanLibrary(rootPath, probeDepth)
        .then((index) => {
        libraryIndexCache.set(cacheKey, { at: Date.now(), index });
        return index;
    })
        .finally(() => {
        libraryIndexInflight.delete(cacheKey);
    });
    libraryIndexInflight.set(cacheKey, run);
    return run;
};
const clampNumber = (value, min, max, fallback) => {
    const parsed = Number(value);
    if (!Number.isFinite(parsed))
        return fallback;
    return Math.min(max, Math.max(min, Math.floor(parsed)));
};
const normalizeSchedule = (schedule) => {
    const mode = ['interval-hours', 'interval-days', 'weekdays', 'monthly'].includes(String(schedule?.mode))
        ? schedule?.mode
        : 'interval-days';
    const weekdays = Array.isArray(schedule?.weekdays)
        ? [...new Set((schedule?.weekdays || []).map((entry) => clampNumber(entry, 0, 6, 0)))]
        : [1];
    const monthDays = Array.isArray(schedule?.monthDays)
        ? [...new Set((schedule?.monthDays || []).map((entry) => clampNumber(entry, 1, 31, 1)))]
        : [1];
    return {
        enabled: Boolean(schedule?.enabled),
        mode,
        intervalHours: clampNumber(schedule?.intervalHours, 1, 168, 12),
        intervalDays: clampNumber(schedule?.intervalDays, 1, 30, 1),
        weekdays: weekdays.length ? weekdays : [1],
        monthDays: monthDays.length ? monthDays : [1],
        hour: clampNumber(schedule?.hour, 0, 23, 8),
        minute: clampNumber(schedule?.minute, 0, 59, 0),
        lastRunAt: schedule?.lastRunAt ? String(schedule.lastRunAt) : null,
        nextRunAt: schedule?.nextRunAt ? String(schedule.nextRunAt) : null,
    };
};
const setTime = (date, hour, minute) => {
    const next = new Date(date);
    next.setSeconds(0, 0);
    next.setHours(hour, minute, 0, 0);
    return next;
};
const computeNextRunAt = (schedule, now = new Date()) => {
    if (!schedule.enabled)
        return null;
    if (schedule.mode === 'interval-hours') {
        const last = schedule.lastRunAt ? new Date(schedule.lastRunAt) : now;
        return new Date(last.getTime() + schedule.intervalHours * 60 * 60 * 1000).toISOString();
    }
    if (schedule.mode === 'interval-days') {
        const base = schedule.lastRunAt ? new Date(schedule.lastRunAt) : now;
        const next = setTime(base, schedule.hour, schedule.minute);
        if (schedule.lastRunAt) {
            next.setDate(next.getDate() + schedule.intervalDays);
        }
        else if (next <= now) {
            next.setDate(next.getDate() + schedule.intervalDays);
        }
        return next.toISOString();
    }
    if (schedule.mode === 'monthly') {
        const targetDays = schedule.monthDays.length ? [...schedule.monthDays].sort((a, b) => a - b) : [1];
        for (let offset = 0; offset < 62; offset += 1) {
            const candidate = new Date(now);
            candidate.setDate(now.getDate() + offset);
            if (!targetDays.includes(candidate.getDate()))
                continue;
            const withTime = setTime(candidate, schedule.hour, schedule.minute);
            if (withTime > now)
                return withTime.toISOString();
        }
        const fallback = new Date(now);
        fallback.setMonth(fallback.getMonth() + 1, targetDays[0]);
        return setTime(fallback, schedule.hour, schedule.minute).toISOString();
    }
    const today = new Date(now);
    for (let offset = 0; offset < 14; offset += 1) {
        const candidate = new Date(today);
        candidate.setDate(today.getDate() + offset);
        if (!schedule.weekdays.includes(candidate.getDay()))
            continue;
        const withTime = setTime(candidate, schedule.hour, schedule.minute);
        if (withTime > now)
            return withTime.toISOString();
    }
    return setTime(new Date(now.getTime() + 24 * 60 * 60 * 1000), schedule.hour, schedule.minute).toISOString();
};
const createQobuzWatchlistService = ({ conf, qobuz, ensureQobuzSearchReady, fetchDeezerArtistAlbums, dispatchQueueItems, broadcastState, }) => {
    const store = new watchlist_store_1.WatchlistStore();
    let availableGenres = [...FALLBACK_QOBUZ_GENRES];
    let schedulerRunning = false;
    let schedulerTimer = null;
    const getQobuzPath = () => {
        const configured = conf?.get?.('paths.qobuz') || './Music/Qobuz';
        return path_1.default.resolve(process.cwd(), configured);
    };
    const pushMonitorHistory = (kind, level, message, details = '') => {
        store.update((draft) => {
            draft.monitorHistory.unshift({
                id: `${kind}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
                kind,
                level,
                message,
                details,
                createdAt: new Date().toISOString(),
            });
            draft.monitorHistory = draft.monitorHistory.slice(0, 300);
        });
    };
    const artistKeyOf = (artist) => String(artist.artistId ?? artist.id ?? '').trim();
    const normaliseService = (service) => String(service || '').toLowerCase() === 'deezer' ? 'deezer' : 'qobuz';
    const toWatchedArtist = (artist) => ({
        id: artistKeyOf(artist),
        name: String(artist.name || 'Unknown Artist'),
        service: normaliseService(artist.service),
        image: String(artist.image || ''),
        lastCheckedAt: null,
        status: 'idle',
        rules: {
            autoQueueAlbums: false,
            autoQueueTracks: false,
            trackLimit: 20,
        },
    });
    const enrichState = (state) => {
        const albumCountByArtist = new Map();
        const trackCountByPlaylist = new Map();
        state.candidates.forEach((candidate) => {
            if (candidate.reason === 'new' || candidate.reason === 'needs-review') {
                albumCountByArtist.set(candidate.artistId, (albumCountByArtist.get(candidate.artistId) || 0) + 1);
            }
        });
        state.playlistCandidates.forEach((candidate) => {
            if (candidate.reason === 'new' || candidate.reason === 'needs-review') {
                trackCountByPlaylist.set(candidate.playlistId, (trackCountByPlaylist.get(candidate.playlistId) || 0) + 1);
            }
        });
        const schedules = {
            artists: normalizeSchedule(state.schedules?.artists),
            playlists: normalizeSchedule(state.schedules?.playlists),
        };
        return {
            ...state,
            schedules,
            availableGenres,
            watchedArtists: state.watchedArtists.map((artist) => ({
                ...artist,
                newReleaseCount: albumCountByArtist.get(String(artist.id)) || 0,
            })),
            watchedPlaylists: state.watchedPlaylists.map((playlist) => ({
                ...playlist,
                newTrackCount: trackCountByPlaylist.get(String(playlist.id)) || 0,
            })),
            summary: {
                watchedArtists: state.watchedArtists.length,
                watchedPlaylists: state.watchedPlaylists.length,
                newCandidates: state.candidates.filter((candidate) => candidate.reason === 'new' || candidate.reason === 'needs-review').length,
                newPlaylistCandidates: state.playlistCandidates.filter((candidate) => candidate.reason === 'new' || candidate.reason === 'needs-review').length,
                favoriteGenres: state.favoriteGenres.length,
            },
        };
    };
    const getState = () => enrichState(store.read());
    const getLibraryOverview = async (artistId, options = {}) => {
        const profile = (0, quality_profile_1.readQualityProfile)(conf);
        const libraryTokens = await collectFilesystemTokens(getQobuzPath(), profile.cutoff === 'hires');
        const selected = () => {
            const state = store.read();
            return artistId
                ? state.watchedArtists.filter((entry) => String(entry.id) === String(artistId))
                : state.watchedArtists;
        };
        if (options.fetchIfMissing) {
            for (const artist of selected()) {
                const existing = store.read().discographies?.[String(artist.id)];
                if (existing && existing.releases.length > 0)
                    continue;
                try {
                    await ensureQobuzSearchReady();
                    recordDiscography(String(artist.id), await fetchAllArtistAlbums(artist));
                }
                catch {
                }
            }
        }
        const state = store.read();
        const processedByKey = new Map(state.processedAlbums.map((entry) => [entry.normalizedKey, entry]));
        const summaries = selected().map((artist) => {
            const snapshot = state.discographies?.[String(artist.id)];
            const stored = snapshot?.releases ?? [];
            const releases = stored.map((release) => {
                const normalizedTitle = (0, exports.normalizeWatchlistText)((0, exports.stripEditionMarkers)(release.title));
                const haveTier = libraryTokens.get(normalizedTitle) ?? null;
                const availableTier = (0, quality_profile_1.bestAvailableTier)('qobuz', { maximum_bit_depth: release.maximumBitDepth });
                const key = buildAlbumKey(artist.name, release.title);
                const downloaded = processedByKey.get(key)?.reason === 'downloaded';
                const owned = haveTier !== null || downloaded;
                return {
                    id: release.id,
                    title: release.title,
                    year: release.year,
                    image: release.image,
                    releaseType: release.releaseType,
                    owned,
                    quality: haveTier,
                    availableQuality: availableTier,
                    upgradable: haveTier !== null && !(0, quality_profile_1.meetsCutoff)(haveTier, profile.cutoff) && availableTier !== haveTier,
                    reason: owned ? 'owned' : 'missing',
                };
            });
            const owned = releases.filter((r) => r.owned).length;
            return {
                artistId: String(artist.id),
                name: artist.name,
                image: artist.image ?? '',
                total: releases.length,
                owned,
                missing: releases.length - owned,
                upgradable: releases.filter((r) => r.upgradable).length,
                scannedAt: snapshot?.fetchedAt ?? null,
                releases: releases.sort((a, b) => (b.year ?? 0) - (a.year ?? 0)),
            };
        });
        return { cutoff: profile.cutoff, artists: summaries };
    };
    const parseGenreList = (payload) => {
        const rawItems = payload?.genres?.items || payload?.genres || payload?.items || [];
        if (!Array.isArray(rawItems))
            return [];
        return rawItems
            .map((genre) => {
            const id = String(genre?.id || genre?.slug || '').trim();
            const label = String(genre?.name || genre?.title || '').trim();
            if (!id || !label)
                return null;
            return { id, label, service: 'qobuz' };
        })
            .filter(Boolean);
    };
    const loadAvailableGenres = async () => {
        try {
            await ensureQobuzSearchReady();
            const response = await qobuz.qobuzRequest?.('genre/list', { limit: 200, offset: 0 });
            const fetched = parseGenreList(response);
            if (fetched.length > 0)
                availableGenres = fetched;
        }
        catch {
            availableGenres = [...FALLBACK_QOBUZ_GENRES];
        }
        return availableGenres;
    };
    const getFavoriteGenres = () => ({
        genres: [...store.read().favoriteGenres],
        availableGenres,
    });
    const getMonitorSchedules = () => {
        const state = store.getState();
        return {
            artists: normalizeSchedule(state.schedules?.artists),
            playlists: normalizeSchedule(state.schedules?.playlists),
        };
    };
    const getReleaseTypes = () => {
        const current = store.getState().releaseTypes;
        return Array.isArray(current) && current.length > 0 ? current : [...watchlist_store_1.DEFAULT_RELEASE_TYPES];
    };
    const saveReleaseTypes = (types) => {
        const allowed = new Set(watchlist_store_1.ALL_RELEASE_TYPES);
        const next = [...new Set((types || []).map(String))].filter((t) => allowed.has(t));
        const effective = next.length > 0 ? next : [...watchlist_store_1.DEFAULT_RELEASE_TYPES];
        const state = store.update((draft) => {
            draft.releaseTypes = effective;
        });
        pushMonitorHistory('artists', 'info', `Release types set to ${effective.join(', ')}`);
        return enrichState(state);
    };
    const saveFavoriteGenres = (genreIds) => {
        const allowed = new Set(availableGenres.map((genre) => genre.id));
        const nextGenres = availableGenres.filter((genre) => allowed.has(genre.id) && genreIds.includes(genre.id));
        const state = store.update((draft) => {
            draft.favoriteGenres = nextGenres;
        });
        return enrichState(state);
    };
    const addWatchedArtist = (artist) => {
        const id = artistKeyOf(artist);
        if (!id)
            throw new Error('That artist has no id, so it cannot be watched.');
        const service = normaliseService(artist.service);
        const state = store.update((draft) => {
            const existing = draft.watchedArtists.find((entry) => String(entry.id) === id && normaliseService(entry.service) === service);
            if (existing) {
                existing.name = String(artist.name || existing.name);
                existing.image = String(artist.image || existing.image || '');
                existing.service = service;
                return;
            }
            draft.watchedArtists.unshift(toWatchedArtist(artist));
        });
        pushMonitorHistory('artists', 'success', `Added ${artist.name || 'artist'} to monitor`);
        return enrichState(state);
    };
    const isAlbumOwnedByWatchedArtist = (album, artist) => String(album?.artist?.id || '') === String(artist.id);
    const recordDiscography = (artistId, albums) => {
        if (!Array.isArray(albums) || albums.length === 0)
            return;
        const releases = albums.map((album) => ({
            id: String(album?.id ?? ''),
            title: String(album?.title || album?.name || 'Unknown Album'),
            year: album?.release_date_original ? new Date(album.release_date_original).getFullYear() : null,
            image: String(album?.image?.large || album?.image?.small || album?.image?.thumbnail || ''),
            releaseType: (0, exports.classifyReleaseType)(album),
            maximumBitDepth: Number(album?.maximum_bit_depth) || 16,
        }));
        store.update((draft) => {
            if (!draft.discographies)
                draft.discographies = {};
            draft.discographies[artistId] = {
                artistId,
                fetchedAt: new Date().toISOString(),
                releases,
            };
        });
    };
    const fetchDeezerAlbumsFor = async (artist) => {
        if (!fetchDeezerArtistAlbums)
            return [];
        const albums = await fetchDeezerArtistAlbums(String(artist.id));
        return albums.map((album) => {
            const raw = album?.rawData ?? album;
            return {
                id: String(raw?.id ?? album?.id ?? ''),
                title: String(raw?.title ?? album?.title ?? 'Unknown Album'),
                artist: { id: String(artist.id), name: artist.name },
                release_date_original: raw?.release_date ?? null,
                tracks_count: Number(raw?.nb_tracks) || 0,
                duration: Number(raw?.duration) || 0,
                maximum_bit_depth: 16,
                image: {
                    large: raw?.cover_xl || raw?.cover_big || raw?.cover_medium || '',
                    small: raw?.cover_medium || '',
                    thumbnail: raw?.cover_small || '',
                },
                version: raw?.record_type && String(raw.record_type).toLowerCase() !== 'album' ? String(raw.record_type) : '',
            };
        });
    };
    const fetchAllArtistAlbums = async (artist) => {
        if (artist.service === 'deezer')
            return fetchDeezerAlbumsFor(artist);
        const albumById = new Map();
        let offset = 0;
        let total = Number.MAX_SAFE_INTEGER;
        while (offset < total) {
            const response = await qobuz.getArtistAlbums(String(artist.id), {
                offset,
                limit: WATCHLIST_ARTIST_ALBUM_PAGE_SIZE,
            });
            const albumsPayload = response?.albums || {};
            const items = Array.isArray(albumsPayload?.items)
                ? albumsPayload.items
                : Array.isArray(albumsPayload)
                    ? albumsPayload
                    : [];
            total = Number(albumsPayload?.total || items.length || 0);
            if (!items.length)
                break;
            items.forEach((album) => {
                if (!album?.id)
                    return;
                if (!isAlbumOwnedByWatchedArtist(album, artist))
                    return;
                albumById.set(String(album.id), album);
            });
            offset += items.length;
            if (items.length < WATCHLIST_ARTIST_ALBUM_PAGE_SIZE)
                break;
        }
        return Array.from(albumById.values());
    };
    const fetchAllPlaylistTracks = async (playlistId) => {
        const trackById = new Map();
        let playlistInfo = null;
        let offset = 0;
        let total = Number.MAX_SAFE_INTEGER;
        while (offset < total) {
            const response = await qobuz.getPlaylistTracks(String(playlistId), {
                offset,
                limit: WATCHLIST_PLAYLIST_TRACK_PAGE_SIZE,
            });
            const tracksPayload = response?.tracks || {};
            const items = Array.isArray(tracksPayload?.items)
                ? tracksPayload.items
                : Array.isArray(tracksPayload)
                    ? tracksPayload
                    : [];
            if (!playlistInfo)
                playlistInfo = response;
            total = Number(tracksPayload?.total || items.length || 0);
            if (!items.length)
                break;
            items.forEach((track) => {
                if (!track?.id)
                    return;
                trackById.set(String(track.id), track);
            });
            offset += items.length;
            if (items.length < WATCHLIST_PLAYLIST_TRACK_PAGE_SIZE)
                break;
        }
        return { playlistInfo, tracks: Array.from(trackById.values()) };
    };
    const fetchSpotifyWatchlistPlaylistMeta = async (playlistId) => {
        try {
            const bundle = await (0, spotify_1.getSpotifyPlaylistBundle)(String(playlistId));
            return {
                id: String(bundle.id || playlistId),
                title: String(bundle.name || 'Playlist'),
                owner: String(bundle.ownerName || bundle.ownerId || 'Spotify'),
                image: normalizePlaylistImage(bundle.imageUrl),
            };
        }
        catch {
            return null;
        }
    };
    const fetchTidalWatchlistPlaylistMeta = async (playlistId) => {
        try {
            const playlistInfo = await core_1.tidal.getPlaylist(String(playlistId));
            const imageUrls = playlistInfo?.image ? core_1.tidal.albumArtToUrl(String(playlistInfo.image)) : null;
            return {
                id: String(playlistInfo?.uuid || playlistId),
                title: String(playlistInfo?.title || 'Playlist'),
                owner: String(playlistInfo?.creator?.id || 'TIDAL'),
                image: normalizePlaylistImage(imageUrls?.xl, imageUrls?.lg, imageUrls?.md, imageUrls?.sm),
            };
        }
        catch {
            return null;
        }
    };
    const fetchWatchedPlaylistSource = async (playlist) => {
        if (playlist.service === 'qobuz') {
            const { playlistInfo, tracks } = await fetchAllPlaylistTracks(String(playlist.id));
            return {
                playlistInfo: {
                    id: String(playlist.id),
                    title: String(playlistInfo?.name || playlistInfo?.title || 'Playlist'),
                    owner: String(playlistInfo?.owner?.name || playlistInfo?.owner?.display_name || ''),
                    image: normalizePlaylistImage(playlistInfo?.image_rectangle?.[0]?.url ||
                        playlistInfo?.images300?.[0] ||
                        playlistInfo?.images150?.[0] ||
                        playlistInfo?.image?.large ||
                        ''),
                },
                tracks,
            };
        }
        await ensureQobuzSearchReady();
        const parsedData = await (0, to_qobuz_parser_1.parseToQobuz)(String(playlist.url));
        if (!['qobuz-playlist', 'spotify-playlist'].includes(parsedData.linktype)) {
            throw new Error(`Unsupported monitored playlist type: ${playlist.service}`);
        }
        const spotifyMeta = playlist.service === 'spotify' ? await fetchSpotifyWatchlistPlaylistMeta(playlist.id) : null;
        const tidalMeta = playlist.service === 'tidal' ? await fetchTidalWatchlistPlaylistMeta(playlist.id) : null;
        const fallbackMeta = spotifyMeta || tidalMeta;
        const trackImage = extractPlaylistTrackImage(parsedData.tracks || []);
        const playlistImage = playlist.service === 'tidal'
            ? normalizePlaylistImage(trackImage, parsedData.linkinfo?.image?.large, parsedData.linkinfo?.image?.thumbnail, parsedData.linkinfo?.image?.small, fallbackMeta?.image)
            : normalizePlaylistImage(fallbackMeta?.image, parsedData.linkinfo?.image?.large, parsedData.linkinfo?.image?.thumbnail, parsedData.linkinfo?.image?.small, trackImage);
        return {
            playlistInfo: {
                id: String(parsedData.linkinfo?.id || fallbackMeta?.id || playlist.id),
                title: String(parsedData.linkinfo?.title || parsedData.linkinfo?.name || fallbackMeta?.title || 'Playlist'),
                owner: String(parsedData.linkinfo?.owner?.name || parsedData.linkinfo?.owner?.id || fallbackMeta?.owner || playlist.service),
                image: playlistImage,
            },
            tracks: parsedData.tracks || [],
        };
    };
    const removeWatchedArtist = (artistId) => {
        const state = store.update((draft) => {
            draft.watchedArtists = draft.watchedArtists.filter((artist) => String(artist.id) !== String(artistId));
            draft.candidates = draft.candidates.filter((candidate) => String(candidate.artistId) !== String(artistId));
        });
        pushMonitorHistory('artists', 'info', `Removed artist monitor`, `Artist ${artistId}`);
        return enrichState(state);
    };
    const classifyAlbums = async (artist, albums) => {
        const state = store.getState();
        const processedByKey = new Map(state.processedAlbums.map((entry) => [entry.normalizedKey, entry]));
        const qualityProfile = (0, quality_profile_1.readQualityProfile)(conf);
        const libraryTokens = await collectFilesystemTokens(getQobuzPath(), qualityProfile.cutoff === 'hires');
        const nextCandidates = [];
        const allowedTypes = new Set(Array.isArray(state.releaseTypes) && state.releaseTypes.length > 0 ? state.releaseTypes : watchlist_store_1.DEFAULT_RELEASE_TYPES);
        albums.forEach((album) => {
            const title = String(album?.title || album?.name || 'Unknown Album');
            const rawArtist = album?.artist?.name || artist.name;
            const releaseType = (0, exports.classifyReleaseType)(album);
            const normalizedTitle = (0, exports.normalizeWatchlistText)((0, exports.stripEditionMarkers)(title));
            const normalizedKey = buildAlbumKey(rawArtist, title);
            const legacyKey = buildLegacyAlbumKey(rawArtist, title);
            let reason = 'new';
            let duplicateSource = '';
            const matchedKey = processedByKey.has(normalizedKey)
                ? normalizedKey
                : processedByKey.has(legacyKey)
                    ? legacyKey
                    : '';
            const haveTier = libraryTokens.get(normalizedTitle) ?? null;
            const availableTier = (0, quality_profile_1.bestAvailableTier)('qobuz', album);
            const upgradable = (0, quality_profile_1.needsUpgrade)(haveTier, qualityProfile, availableTier);
            if (upgradable) {
                reason = 'new';
                duplicateSource = `upgrade:${haveTier}->${availableTier}`;
            }
            else if (matchedKey) {
                const processedReason = processedByKey.get(matchedKey)?.reason || 'history';
                if (['downloaded', 'dismissed', 'duplicate'].includes(processedReason)) {
                    reason = 'already-processed';
                    duplicateSource = processedReason;
                }
                else {
                    reason = 'needs-review';
                    duplicateSource = processedReason;
                }
            }
            else if (libraryTokens.has(normalizedTitle)) {
                reason = 'needs-review';
                duplicateSource = 'local-library';
            }
            else if (!allowedTypes.has(releaseType)) {
                reason = 'filtered-type';
                duplicateSource = releaseType;
            }
            nextCandidates.push({
                id: String(album.id),
                releaseType,
                artistId: String(artist.id),
                artist: String(album?.artist?.name || artist.name),
                title,
                year: album?.release_date_original ? new Date(album.release_date_original).getFullYear() : null,
                image: String(album?.image?.large || album?.image?.thumbnail || album?.image?.small || album?.cover || ''),
                service: normaliseService(artist.service),
                normalizedKey,
                reason,
                duplicateSource: duplicateSource || undefined,
                rawData: album,
                checkedAt: new Date().toISOString(),
            });
        });
        return nextCandidates.sort((left, right) => {
            const leftYear = left.year || 0;
            const rightYear = right.year || 0;
            return rightYear - leftYear || left.title.localeCompare(right.title);
        });
    };
    const classifyPlaylistTracks = async (playlist, tracks) => {
        const state = store.getState();
        const processedByKey = new Map(state.processedTracks.map((entry) => [entry.normalizedKey, entry]));
        const nextCandidates = [];
        tracks.forEach((track) => {
            const artist = String(track?.performer?.name || track?.artist?.name || 'Unknown Artist');
            const title = String(track?.title || 'Unknown Track');
            const normalizedKey = buildTrackKey(artist, title);
            let reason = 'new';
            let duplicateSource = '';
            if (processedByKey.has(normalizedKey)) {
                const processedReason = processedByKey.get(normalizedKey)?.reason || 'history';
                if (['downloaded', 'dismissed', 'duplicate'].includes(processedReason)) {
                    reason = 'already-processed';
                    duplicateSource = processedReason;
                }
                else if (processedReason === 'queued') {
                    reason = 'new';
                }
                else {
                    reason = 'needs-review';
                    duplicateSource = processedReason;
                }
            }
            nextCandidates.push({
                id: String(track.id),
                playlistId: String(playlist.id),
                playlistTitle: playlist.title,
                artist,
                title,
                album: String(track?.album?.title || ''),
                image: String(track?.album?.image?.thumbnail || track?.album?.image?.small || track?.album?.image?.large || ''),
                service: normaliseService(playlist?.service),
                normalizedKey,
                reason,
                duplicateSource: duplicateSource || undefined,
                rawData: track,
                checkedAt: new Date().toISOString(),
            });
        });
        return nextCandidates;
    };
    const getArtistTracks = async (artist, limit = 20) => {
        await ensureQobuzSearchReady();
        let items = [];
        try {
            const response = await qobuz.qobuzRequest?.('artist/get', {
                artist_id: String(artist.id),
                extra: 'tracks',
            });
            items = response?.tracks?.items || response?.tracks || [];
        }
        catch { }
        if (!items.length) {
            const result = await qobuz.searchMusic(artist.name, 'track', Math.max(25, Number(limit) * 2), 0);
            items = (result?.tracks?.items || []).filter((track) => (0, exports.normalizeWatchlistText)(track?.performer?.name || track?.artist?.name || '') ===
                (0, exports.normalizeWatchlistText)(artist.name));
        }
        return items.slice(0, Math.max(1, Number(limit)));
    };
    const createTrackQueueItem = (artist, track, playlistTitle = '') => ({
        id: String(track?.id || track?.track_id || ''),
        title: String(track?.title || 'Unknown Track'),
        artist: String(track?.performer?.name || track?.artist?.name || artist?.name || 'Unknown Artist'),
        album: String(track?.album?.title || playlistTitle || ''),
        type: 'track',
        service: artist ? normaliseService(artist.service) : 'qobuz',
        duration: Number(track?.duration || 0),
        rawData: track,
    });
    const queueArtistTracks = async (artistId, options = {}) => {
        const state = store.getState();
        const artist = state.watchedArtists.find((entry) => String(entry.id) === String(artistId));
        if (!artist)
            return { state: getState(), queueItems: [] };
        const processedByKey = new Map(state.processedTracks.map((entry) => [entry.normalizedKey, entry]));
        const libraryTokens = await collectFilesystemTokens(getQobuzPath());
        const tracks = await getArtistTracks(artist, options.limit || artist.rules?.trackLimit || 20);
        const queueItems = tracks
            .filter((track) => {
            const normalizedKey = buildTrackKey(track?.performer?.name || track?.artist?.name || artist.name, track?.title || '');
            const normalizedTitle = (0, exports.normalizeWatchlistText)(track?.title || '');
            return !processedByKey.has(normalizedKey) && !libraryTokens.has(normalizedTitle);
        })
            .map((track) => createTrackQueueItem(artist, track));
        const nextState = store.update((draft) => {
            const processedAt = new Date().toISOString();
            queueItems.forEach((trackItem) => {
                const normalizedKey = buildTrackKey(trackItem.artist, trackItem.title);
                const exists = draft.processedTracks.find((entry) => entry.normalizedKey === normalizedKey);
                if (exists)
                    return;
                draft.processedTracks.unshift({
                    id: trackItem.id,
                    artistId: String(artist.id),
                    artist: trackItem.artist,
                    title: trackItem.title,
                    album: trackItem.album,
                    image: String(trackItem.rawData?.album?.image?.thumbnail || trackItem.rawData?.album?.image?.small || ''),
                    service: normaliseService(trackItem.service),
                    normalizedKey,
                    reason: options.reason || 'queued',
                    processedAt,
                });
            });
            draft.processedTracks = draft.processedTracks.slice(0, 1000);
        });
        return { state: enrichState(nextState), queueItems };
    };
    const addWatchedPlaylist = async (url) => {
        const info = await (0, core_1.getUrlParts)(String(url || '').trim(), true);
        const serviceByType = {
            'qobuz-playlist': 'qobuz',
            'spotify-playlist': 'spotify',
            'tidal-playlist': 'tidal',
            playlist: 'deezer',
        };
        const playlistService = serviceByType[String(info.type)];
        if (!playlistService) {
            throw new Error('That URL is not a supported playlist link.');
        }
        const { playlistInfo, tracks } = await fetchWatchedPlaylistSource({
            id: String(info.id),
            url: String(url),
            service: playlistService,
        });
        const state = store.update((draft) => {
            const existing = draft.watchedPlaylists.find((entry) => String(entry.id) === String(info.id) && entry.service === playlistService);
            const nextImage = String(playlistInfo?.image || '');
            const nextTitle = String(playlistInfo?.title || 'Playlist');
            const nextOwner = String(playlistInfo?.owner || '');
            if (existing) {
                existing.url = String(url);
                existing.title = nextTitle;
                existing.owner = nextOwner;
                existing.image = nextImage || existing.image;
                existing.service = playlistService;
                existing.status = 'idle';
                existing.lastError = '';
                existing.lastTrackCount = tracks.length;
                return;
            }
            draft.watchedPlaylists.unshift({
                id: String(info.id),
                url: String(url),
                title: nextTitle,
                owner: nextOwner,
                service: playlistService,
                image: nextImage,
                lastCheckedAt: null,
                status: 'idle',
                lastTrackCount: tracks.length,
                rules: {
                    autoQueueTracks: false,
                },
            });
        });
        pushMonitorHistory('playlists', 'success', `Added playlist monitor`, String(url));
        return enrichState(state);
    };
    const removeWatchedPlaylist = (playlistId) => {
        const state = store.update((draft) => {
            draft.watchedPlaylists = draft.watchedPlaylists.filter((entry) => String(entry.id) !== String(playlistId));
            draft.playlistCandidates = draft.playlistCandidates.filter((entry) => String(entry.playlistId) !== String(playlistId));
        });
        pushMonitorHistory('playlists', 'info', `Removed playlist monitor`, `Playlist ${playlistId}`);
        return enrichState(state);
    };
    const queueWatchedPlaylistTracks = async (playlistId, trackIds, options = {}) => {
        const current = store.getState();
        const watchedPlaylist = current.watchedPlaylists.find((entry) => String(entry.id) === String(playlistId));
        if (!watchedPlaylist) {
            return { state: getState(), queueItems: [] };
        }
        const targets = current.playlistCandidates.filter((candidate) => String(candidate.playlistId) === String(playlistId) && trackIds.includes(String(candidate.id)));
        const queueableTargets = targets.filter((candidate) => ['new', 'needs-review'].includes(candidate.reason));
        const queueableIds = new Set(queueableTargets.map((candidate) => String(candidate.id)));
        const playlistTitle = options.playlistTitle || queueableTargets[0]?.playlistTitle || watchedPlaylist.title || 'Watchlist Playlist';
        let allPlaylistTracks = Array.isArray(options.sourceTracks) ? options.sourceTracks.filter(Boolean) : [];
        if (!allPlaylistTracks.length) {
            try {
                const sourceSnapshot = await fetchWatchedPlaylistSource({
                    id: String(watchedPlaylist.id),
                    url: String(watchedPlaylist.url),
                    service: watchedPlaylist.service,
                });
                allPlaylistTracks = sourceSnapshot.tracks.filter(Boolean);
            }
            catch {
                allPlaylistTracks = current.playlistCandidates
                    .filter((candidate) => String(candidate.playlistId) === String(playlistId))
                    .map((candidate) => candidate.rawData)
                    .filter(Boolean);
            }
        }
        const queueItems = queueableTargets.length
            ? [
                {
                    id: `watchlist-playlist-${playlistId}-${Date.now()}`,
                    title: playlistTitle,
                    artist: `${queueableTargets.length} tracks`,
                    type: 'playlist',
                    service: 'user-playlist',
                    playlistData: {
                        id: playlistId,
                        title: playlistTitle,
                        source: 'watchlist',
                        allTracks: allPlaylistTracks,
                    },
                    tracks: queueableTargets.map((candidate) => ({
                        ...createTrackQueueItem(null, candidate.rawData, candidate.playlistTitle),
                        service: normaliseService(candidate.service),
                    })),
                },
            ]
            : [];
        const state = store.update((draft) => {
            const processedAt = new Date().toISOString();
            queueableTargets.forEach((candidate) => {
                const exists = draft.processedTracks.find((entry) => entry.normalizedKey === candidate.normalizedKey && entry.artistId === `playlist:${candidate.playlistId}`);
                if (exists)
                    return;
                draft.processedTracks.unshift({
                    id: candidate.id,
                    artistId: `playlist:${candidate.playlistId}`,
                    artist: candidate.artist,
                    title: candidate.title,
                    album: candidate.album,
                    image: candidate.image,
                    service: normaliseService(candidate.service),
                    normalizedKey: candidate.normalizedKey,
                    reason: 'queued',
                    processedAt,
                });
            });
            draft.playlistCandidates = draft.playlistCandidates.filter((candidate) => !(String(candidate.playlistId) === String(playlistId) && queueableIds.has(String(candidate.id))));
            draft.processedTracks = draft.processedTracks.slice(0, 1000);
        });
        return { state: enrichState(state), queueItems };
    };
    const refreshWatchedPlaylist = async (playlistId, options = {}) => {
        const current = store.getState();
        const watchedPlaylist = current.watchedPlaylists.find((entry) => String(entry.id) === String(playlistId));
        if (!watchedPlaylist)
            return { state: getState(), queueItems: [] };
        store.update((draft) => {
            const playlist = draft.watchedPlaylists.find((entry) => String(entry.id) === String(playlistId));
            if (playlist) {
                playlist.status = 'checking';
                playlist.lastError = '';
            }
        });
        try {
            const { playlistInfo, tracks } = await fetchWatchedPlaylistSource({
                id: String(watchedPlaylist.id),
                url: String(watchedPlaylist.url),
                service: watchedPlaylist.service,
            });
            const candidates = await classifyPlaylistTracks(watchedPlaylist, tracks);
            const state = store.update((draft) => {
                const playlist = draft.watchedPlaylists.find((entry) => String(entry.id) === String(playlistId));
                if (playlist) {
                    playlist.status = 'ready';
                    playlist.lastCheckedAt = new Date().toISOString();
                    playlist.lastError = '';
                    playlist.lastTrackCount = tracks.length;
                    playlist.title = String(playlistInfo?.title || playlist.title);
                    playlist.owner = String(playlistInfo?.owner || playlist.owner);
                    playlist.image = String(playlistInfo?.image || playlist.image || '');
                }
                draft.playlistCandidates = draft.playlistCandidates.filter((candidate) => String(candidate.playlistId) !== String(playlistId));
                draft.playlistCandidates.push(...candidates);
            });
            let nextState = enrichState(state);
            const queueItems = [];
            if (options.allowAutoQueue && watchedPlaylist.rules?.autoQueueTracks) {
                const autoTrackIds = candidates
                    .filter((candidate) => candidate.reason === 'new')
                    .map((candidate) => String(candidate.id));
                if (autoTrackIds.length) {
                    const queued = await queueWatchedPlaylistTracks(String(playlistId), autoTrackIds, {
                        sourceTracks: tracks,
                        playlistTitle: String(playlistInfo?.title || watchedPlaylist.title),
                    });
                    nextState = queued.state;
                    queueItems.push(...queued.queueItems);
                }
            }
            return { state: nextState, queueItems };
        }
        catch (error) {
            const state = store.update((draft) => {
                const playlist = draft.watchedPlaylists.find((entry) => String(entry.id) === String(playlistId));
                if (playlist) {
                    playlist.status = 'error';
                    playlist.lastCheckedAt = new Date().toISOString();
                    playlist.lastError = error?.message || 'Unable to refresh playlist';
                }
            });
            return { state: enrichState(state), queueItems: [] };
        }
    };
    const refreshAllWatchedPlaylists = async (options = {}) => {
        const state = store.getState();
        let nextState = getState();
        const queueItems = [];
        for (const playlist of state.watchedPlaylists) {
            const refreshed = await refreshWatchedPlaylist(String(playlist.id), options);
            nextState = refreshed.state;
            queueItems.push(...refreshed.queueItems);
        }
        return { state: nextState, queueItems };
    };
    const refreshWatchedArtist = async (artistId, options = {}) => {
        const current = store.getState();
        const watchedArtist = current.watchedArtists.find((artist) => String(artist.id) === String(artistId));
        if (!watchedArtist)
            return { state: getState(), queueItems: [] };
        store.update((draft) => {
            const artist = draft.watchedArtists.find((entry) => String(entry.id) === String(artistId));
            if (artist) {
                artist.status = 'checking';
                artist.lastError = '';
            }
        });
        try {
            if (watchedArtist.service !== 'deezer')
                await ensureQobuzSearchReady();
            const albums = await fetchAllArtistAlbums(watchedArtist);
            recordDiscography(String(watchedArtist.id), albums);
            const candidates = await classifyAlbums(watchedArtist, albums);
            const state = store.update((draft) => {
                const artist = draft.watchedArtists.find((entry) => String(entry.id) === String(artistId));
                if (artist) {
                    artist.status = 'ready';
                    artist.lastCheckedAt = new Date().toISOString();
                    artist.lastError = '';
                }
                draft.candidates = draft.candidates.filter((candidate) => String(candidate.artistId) !== String(artistId));
                draft.candidates.push(...candidates);
            });
            let nextState = enrichState(state);
            const queueItems = [];
            if (options.allowAutoQueue && watchedArtist.rules?.autoQueueAlbums) {
                const autoAlbumIds = candidates
                    .filter((candidate) => candidate.reason === 'new' || candidate.reason === 'needs-review')
                    .map((candidate) => String(candidate.id));
                if (autoAlbumIds.length) {
                    const queued = queueWatchedArtistReleases(autoAlbumIds);
                    nextState = queued.state;
                    queueItems.push(...queued.queueItems);
                }
            }
            if (options.allowAutoQueue && watchedArtist.rules?.autoQueueTracks) {
                const queuedTracks = await queueArtistTracks(String(artistId), { reason: 'queued' });
                nextState = queuedTracks.state;
                queueItems.push(...queuedTracks.queueItems);
            }
            return { state: nextState, queueItems };
        }
        catch (error) {
            const state = store.update((draft) => {
                const artist = draft.watchedArtists.find((entry) => String(entry.id) === String(artistId));
                if (artist) {
                    artist.status = 'error';
                    artist.lastCheckedAt = new Date().toISOString();
                    artist.lastError = error?.message || 'Unable to refresh artist';
                }
            });
            return { state: enrichState(state), queueItems: [] };
        }
    };
    const refreshAllWatchedArtists = async (options = {}) => {
        const state = store.getState();
        let nextState = getState();
        const queueItems = [];
        for (const artist of state.watchedArtists) {
            const refreshed = await refreshWatchedArtist(String(artist.id), options);
            nextState = refreshed.state;
            queueItems.push(...refreshed.queueItems);
        }
        return { state: nextState, queueItems };
    };
    const createQueueItem = (candidate) => ({
        id: String(candidate.id),
        title: candidate.title,
        artist: candidate.artist,
        album: candidate.title,
        type: 'album',
        service: normaliseService(candidate.service),
        duration: candidate.year ? `${candidate.year}` : 'Album',
        year: candidate.year,
        rawData: candidate.rawData,
    });
    const queueWatchedArtistReleases = (albumIds) => {
        const current = store.getState();
        const queuedCandidates = current.candidates.filter((candidate) => albumIds.includes(String(candidate.id)));
        const queueableCandidates = queuedCandidates.filter((candidate) => ['new', 'needs-review'].includes(candidate.reason));
        const queueableIds = queueableCandidates.map((candidate) => String(candidate.id));
        const queueItems = queueableCandidates.map(createQueueItem);
        const state = store.update((draft) => {
            const processedAt = new Date().toISOString();
            queueableCandidates.forEach((candidate) => {
                const exists = draft.processedAlbums.find((entry) => entry.normalizedKey === candidate.normalizedKey);
                if (!exists) {
                    draft.processedAlbums.unshift({
                        id: candidate.id,
                        artistId: candidate.artistId,
                        artist: candidate.artist,
                        title: candidate.title,
                        year: candidate.year,
                        image: candidate.image,
                        service: normaliseService(candidate.service),
                        normalizedKey: candidate.normalizedKey,
                        reason: 'queued',
                        duplicateSource: candidate.duplicateSource,
                        processedAt,
                    });
                }
            });
            draft.candidates = draft.candidates.filter((candidate) => !queueableIds.includes(String(candidate.id)));
            draft.processedAlbums = draft.processedAlbums.slice(0, 600);
        });
        return { state: enrichState(state), queueItems };
    };
    const queueWatchedArtistDiscography = async (artistId) => {
        const state = store.getState();
        const artist = state.watchedArtists.find((entry) => String(entry.id) === String(artistId));
        if (!artist)
            return { state: getState(), queueItems: [] };
        const existingCandidates = state.candidates.filter((candidate) => String(candidate.artistId) === String(artistId));
        let targetCandidates = existingCandidates;
        if (!targetCandidates.length) {
            const refreshed = await refreshWatchedArtist(String(artistId));
            targetCandidates = refreshed.state.candidates.filter((candidate) => String(candidate.artistId) === String(artistId));
        }
        return queueWatchedArtistReleases(targetCandidates.map((candidate) => String(candidate.id)));
    };
    const updateWatchedArtistRules = (artistId, rules) => {
        const nextState = store.update((draft) => {
            const artist = draft.watchedArtists.find((entry) => String(entry.id) === String(artistId));
            if (!artist)
                return;
            artist.rules = {
                autoQueueAlbums: Boolean(rules?.autoQueueAlbums),
                autoQueueTracks: Boolean(rules?.autoQueueTracks),
                trackLimit: Math.max(5, Number(rules?.trackLimit || artist.rules?.trackLimit || 20)),
            };
        });
        return enrichState(nextState);
    };
    const updateWatchedPlaylistRules = (playlistId, rules) => {
        const nextState = store.update((draft) => {
            const playlist = draft.watchedPlaylists.find((entry) => String(entry.id) === String(playlistId));
            if (!playlist)
                return;
            playlist.rules = {
                autoQueueTracks: Boolean(rules?.autoQueueTracks),
            };
        });
        return enrichState(nextState);
    };
    const markWatchlistAlbumsProcessed = (albumIds, reason = 'dismissed') => {
        const current = store.getState();
        const targets = current.candidates.filter((candidate) => albumIds.includes(String(candidate.id)));
        const state = store.update((draft) => {
            const processedAt = new Date().toISOString();
            targets.forEach((candidate) => {
                const exists = draft.processedAlbums.find((entry) => entry.normalizedKey === candidate.normalizedKey);
                if (!exists) {
                    draft.processedAlbums.unshift({
                        id: candidate.id,
                        artistId: candidate.artistId,
                        artist: candidate.artist,
                        title: candidate.title,
                        year: candidate.year,
                        image: candidate.image,
                        service: normaliseService(candidate.service),
                        normalizedKey: candidate.normalizedKey,
                        reason,
                        duplicateSource: candidate.duplicateSource,
                        processedAt,
                    });
                }
            });
            draft.candidates = draft.candidates.filter((candidate) => !albumIds.includes(String(candidate.id)));
            draft.processedAlbums = draft.processedAlbums.slice(0, 600);
        });
        return enrichState(state);
    };
    const markWatchlistTracksProcessed = (playlistId, trackIds, reason = 'dismissed') => {
        const current = store.getState();
        const targets = current.playlistCandidates.filter((candidate) => String(candidate.playlistId) === String(playlistId) && trackIds.includes(String(candidate.id)));
        const state = store.update((draft) => {
            const processedAt = new Date().toISOString();
            targets.forEach((candidate) => {
                const exists = draft.processedTracks.find((entry) => entry.normalizedKey === candidate.normalizedKey && entry.artistId === `playlist:${candidate.playlistId}`);
                if (!exists) {
                    draft.processedTracks.unshift({
                        id: candidate.id,
                        artistId: `playlist:${candidate.playlistId}`,
                        artist: candidate.artist,
                        title: candidate.title,
                        album: candidate.album,
                        image: candidate.image,
                        service: normaliseService(candidate.service),
                        normalizedKey: candidate.normalizedKey,
                        reason,
                        duplicateSource: candidate.duplicateSource,
                        processedAt,
                    });
                }
            });
            draft.playlistCandidates = draft.playlistCandidates.filter((candidate) => !(String(candidate.playlistId) === String(playlistId) && trackIds.includes(String(candidate.id))));
            draft.processedTracks = draft.processedTracks.slice(0, 1000);
        });
        return enrichState(state);
    };
    const getWatchlistHistory = () => {
        const state = store.getState();
        const albumItems = state.processedAlbums.map((entry) => ({ ...entry, entryType: 'album' }));
        const trackItems = state.processedTracks.map((entry) => ({ ...entry, entryType: 'track' }));
        return [...albumItems, ...trackItems].sort((left, right) => new Date(right.processedAt).getTime() - new Date(left.processedAt).getTime());
    };
    const getMonitorHistory = () => store
        .getState()
        .monitorHistory.slice()
        .sort((left, right) => new Date(right.createdAt).getTime() - new Date(left.createdAt).getTime());
    const getGenreDiscovery = async (genreId, limit = 18, offset = 0) => {
        await ensureQobuzSearchReady();
        if (!availableGenres.length)
            await loadAvailableGenres();
        const genre = availableGenres.find((entry) => String(entry.id) === String(genreId));
        let items = [];
        try {
            const featured = await qobuz.qobuzRequest?.('album/getFeatured', {
                type: 'new-releases-full',
                genre_ids: String(genreId),
                offset: Number(offset),
                limit: Number(limit),
            });
            items = featured?.albums?.items || featured?.items || [];
        }
        catch { }
        if (!items.length) {
            const query = genre?.label || genreId;
            const result = await qobuz.searchMusic(query, 'album', Number(limit), Number(offset));
            items = result?.albums?.items || [];
        }
        const mapped = items.slice(0, Number(limit)).map((album) => ({
            id: String(album.id),
            title: album.title || 'Unknown Album',
            artist: album.artist?.name || 'Unknown Artist',
            type: 'album',
            year: album.release_date_original ? new Date(album.release_date_original).getFullYear() : null,
            duration: `${album.tracks_count || 0} tracks`,
            rawData: album,
        }));
        return {
            items: mapped,
            hasMore: items.length >= Number(limit),
            offset: Number(offset),
            limit: Number(limit),
        };
    };
    const saveMonitorSchedule = (kind, input) => {
        const current = getMonitorSchedules()[kind];
        const next = normalizeSchedule({ ...current, ...input });
        next.lastRunAt = null;
        next.nextRunAt = computeNextRunAt(next);
        const state = store.update((draft) => {
            draft.schedules[kind] = next;
        });
        pushMonitorHistory(kind, 'info', `${kind === 'artists' ? 'Artist' : 'Playlist'} schedule updated`);
        return enrichState(state);
    };
    const maybeDispatchQueueItems = async (queueItems, source) => {
        if (!queueItems.length || !dispatchQueueItems)
            return;
        await Promise.resolve(dispatchQueueItems(queueItems, { autoStart: true, source }));
    };
    const executeMonitorRun = async (kind, reason = 'scheduled') => {
        if (kind === 'artists') {
            const result = await refreshAllWatchedArtists({ allowAutoQueue: true });
            const nextState = store.update((draft) => {
                const schedule = normalizeSchedule(draft.schedules.artists);
                schedule.lastRunAt = new Date().toISOString();
                schedule.nextRunAt = computeNextRunAt(schedule);
                draft.schedules.artists = schedule;
            });
            pushMonitorHistory('artists', 'success', `Artist scan completed`, `${result.queueItems.length} queue items (${reason})`);
            const enriched = enrichState(nextState);
            broadcastState?.(enriched);
            await maybeDispatchQueueItems(result.queueItems, `artists-${reason}`);
            return { state: enriched, queueItems: result.queueItems };
        }
        const result = await refreshAllWatchedPlaylists({ allowAutoQueue: true });
        const nextState = store.update((draft) => {
            const schedule = normalizeSchedule(draft.schedules.playlists);
            schedule.lastRunAt = new Date().toISOString();
            schedule.nextRunAt = computeNextRunAt(schedule);
            draft.schedules.playlists = schedule;
        });
        pushMonitorHistory('playlists', 'success', `Playlist scan completed`, `${result.queueItems.length} queue items (${reason})`);
        const enriched = enrichState(nextState);
        broadcastState?.(enriched);
        await maybeDispatchQueueItems(result.queueItems, `playlists-${reason}`);
        return { state: enriched, queueItems: result.queueItems };
    };
    const runMonitorNow = async (kind) => executeMonitorRun(kind, 'manual');
    const schedulerTick = async () => {
        if (schedulerRunning)
            return;
        schedulerRunning = true;
        try {
            const schedules = getMonitorSchedules();
            const now = new Date();
            for (const kind of ['artists', 'playlists']) {
                const schedule = schedules[kind];
                if (!schedule.enabled || !schedule.nextRunAt)
                    continue;
                if (new Date(schedule.nextRunAt).getTime() > now.getTime())
                    continue;
                try {
                    await executeMonitorRun(kind, 'scheduled');
                }
                catch (error) {
                    pushMonitorHistory(kind, 'error', `${kind === 'artists' ? 'Artist' : 'Playlist'} scan failed`, error?.message || 'Unknown error');
                }
            }
        }
        finally {
            schedulerRunning = false;
        }
    };
    const startScheduler = () => {
        if (schedulerTimer)
            return;
        store.update((draft) => {
            draft.schedules.artists = normalizeSchedule(draft.schedules.artists);
            draft.schedules.playlists = normalizeSchedule(draft.schedules.playlists);
            if (draft.schedules.artists.enabled && !draft.schedules.artists.nextRunAt) {
                draft.schedules.artists.nextRunAt = computeNextRunAt(draft.schedules.artists);
            }
            if (draft.schedules.playlists.enabled && !draft.schedules.playlists.nextRunAt) {
                draft.schedules.playlists.nextRunAt = computeNextRunAt(draft.schedules.playlists);
            }
        });
        schedulerTimer = setInterval(() => {
            schedulerTick().catch((error) => {
                console.error(`Watchlist scheduler tick failed: ${error?.message || error}`);
            });
        }, SCHEDULER_TICK_MS);
    };
    startScheduler();
    return {
        loadAvailableGenres,
        getState,
        getLibraryOverview,
        getFavoriteGenres,
        getMonitorSchedules,
        getMonitorHistory,
        saveMonitorSchedule,
        runMonitorNow,
        saveFavoriteGenres,
        getReleaseTypes,
        saveReleaseTypes,
        addWatchedArtist,
        addWatchedPlaylist,
        removeWatchedArtist,
        removeWatchedPlaylist,
        updateWatchedArtistRules,
        updateWatchedPlaylistRules,
        refreshWatchedArtist,
        refreshAllWatchedArtists,
        refreshWatchedPlaylist,
        refreshAllWatchedPlaylists,
        queueWatchedArtistReleases,
        queueWatchedArtistDiscography,
        queueWatchedArtistTracks: queueArtistTracks,
        queueWatchedPlaylistTracks,
        markWatchlistAlbumsProcessed,
        markWatchlistTracksProcessed,
        getWatchlistHistory,
        getGenreDiscovery,
        getAvailableGenres: () => availableGenres,
    };
};
exports.createQobuzWatchlistService = createQobuzWatchlistService;
