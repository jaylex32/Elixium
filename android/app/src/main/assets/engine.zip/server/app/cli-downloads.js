"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCliDownloads = void 0;
const os_1 = require("os");
const fs_1 = require("fs");
const path_1 = require("path");
const prompts_1 = __importDefault(require("prompts"));
const chalk_1 = __importDefault(require("chalk"));
const true_case_path_1 = require("true-case-path");
const core_1 = require("../core");
const download_qobuz_track_1 = __importDefault(require("../lib/download-qobuz-track"));
const to_qobuz_parser_1 = require("../lib/to-qobuz-parser");
const signale_1 = __importDefault(require("../lib/signale"));
const download_track_1 = __importDefault(require("../lib/download-track"));
const util_1 = require("../lib/util");
const terminal_progress_1 = require("../lib/terminal-progress");
const createCliDownloads = ({ options, conf, queue, urlRegex, normalizeQuality, collectSessionQueue, resolveDeezerQueueItem, resolveQobuzQueueItem, promptGroupedSearchSelection, promptDeezerArtistAlbumSelection, promptQobuzArtistAlbumSelection, promptTrackSubsetSelection, buildDeezerQueuePreview, buildQobuzQueuePreview, describeQobuzTrack, onCancel, }) => {
    const startDownload = async (saveLayout, url, skipPrompt) => {
        try {
            if (!options.quality) {
                const { musicQuality } = await (0, prompts_1.default)({
                    type: 'select',
                    name: 'musicQuality',
                    message: 'Select music quality:',
                    choices: [
                        { title: 'MP3  - 128 kbps', value: '128' },
                        { title: 'MP3  - 320 kbps', value: '320' },
                        { title: 'FLAC - 1411 kbps', value: 'flac' },
                    ],
                    initial: 1,
                }, { onCancel });
                options.quality = musicQuality;
            }
            if (!url) {
                const runDeezerExplorerSession = async () => {
                    const queueItems = await collectSessionQueue('deezer', 'Search Deezer or paste a URL:', resolveDeezerQueueItem);
                    for (const [index, item] of queueItems.entries()) {
                        const itemsLeft = queueItems.length - index - 1;
                        console.log(signale_1.default.info(`Starting queue item ${index + 1}/${queueItems.length}: ${item.label}${itemsLeft ? ` (${itemsLeft} left)` : ''}`));
                        await startDownload(saveLayout, item.url, true);
                    }
                    console.log(signale_1.default.success('Deezer queue complete. Returning to explorer.'));
                    await runDeezerExplorerSession();
                };
                await runDeezerExplorerSession();
                return;
            }
            let searchData = null;
            if (!url.match(urlRegex)) {
                if (options.headless) {
                    throw new Error('Please provide a valid URL. Unknown URL: ' + url);
                }
                const selectedResult = await promptGroupedSearchSelection('deezer', url);
                if (selectedResult.type === 'artist') {
                    url = (await promptDeezerArtistAlbumSelection(selectedResult)).url;
                }
                else if (selectedResult.type === 'album') {
                    url = `https://deezer.com/us/album/${selectedResult.id}`;
                }
                else if (selectedResult.type === 'playlist') {
                    url = `https://deezer.com/us/playlist/${selectedResult.id}`;
                }
                else {
                    const selectedTrack = selectedResult.rawData;
                    if (selectedTrack.VERSION && !selectedTrack.SNG_TITLE.includes(selectedTrack.VERSION)) {
                        selectedTrack.SNG_TITLE += ' ' + selectedTrack.VERSION;
                    }
                    searchData = {
                        info: { type: 'track', id: String(selectedTrack.SNG_ID) },
                        linktype: 'track',
                        linkinfo: {},
                        tracks: [selectedTrack],
                    };
                }
            }
            else if (url.match(/playlist|artist/)) {
                console.log(signale_1.default.info('Fetching data. Please hold on.'));
            }
            const data = searchData ? searchData : await (0, core_1.parseInfo)(url);
            if (!options.headless && data.tracks.length > 1) {
                data.tracks = await promptTrackSubsetSelection(buildDeezerQueuePreview(data), data.tracks, (t) => ({
                    title: t.SNG_TITLE,
                    value: t,
                    description: `Artist: ${t.ART_NAME}\nAlbum: ${t.ALB_TITLE}\nDuration: ${(0, util_1.formatSecondsReadable)(Number(t.DURATION))}`,
                }));
            }
            if (data && data.tracks.length > 0) {
                console.log(signale_1.default.info(`Proceeding to download ${data.tracks.length} tracks. Be patient.`));
                if (data.linktype === 'playlist') {
                    const filteredTracks = data.tracks.filter((item, index, self) => index === self.findIndex((t) => t.SNG_ID === item.SNG_ID));
                    const duplicateTracks = data.tracks.length - filteredTracks.length;
                    if (duplicateTracks > 0) {
                        data.tracks = filteredTracks
                            .sort((a, b) => a.TRACK_POSITION - b.TRACK_POSITION)
                            .map((t, i) => {
                            t.TRACK_POSITION = i + 1;
                            return t;
                        });
                        console.log(signale_1.default.warn(`Removed ${duplicateTracks} duplicate ${duplicateTracks > 1 ? 'tracks' : 'track'}.`));
                    }
                }
                const coverSizes = conf.get('coverSize');
                const trackNumber = conf.get('trackNumber', true);
                const fallbackTrack = conf.get('fallbackTrack', true);
                const fallbackQuality = conf.get('fallbackQuality', true);
                const resolveFullPath = Boolean(options.resolveFullPath ?? conf.get('playlist.resolveFullPath'));
                const selectedQuality = options.quality || '320';
                const savedFiles = [];
                let m3u8 = [];
                await queue.addAll(data.tracks.map((track, index) => {
                    return async () => {
                        const percentage = ((index + 1) / data.tracks.length) * 100;
                        const formattedPercentage = percentage.toFixed(2);
                        const savedPath = await (0, download_track_1.default)({
                            track,
                            quality: selectedQuality,
                            info: data.linkinfo,
                            coverSizes,
                            path: options.output ? options.output : saveLayout[data.linktype],
                            totalTracks: data.tracks.length,
                            trackNumber,
                            fallbackTrack,
                            fallbackQuality,
                            message: `(${formattedPercentage}%)`,
                        });
                        if (savedPath) {
                            const absolutePath = (0, path_1.resolve)(savedPath);
                            if (!terminal_progress_1.terminalProgress.isEnabled()) {
                                terminal_progress_1.terminalProgress.log(chalk_1.default.green('✔ Path:') + ` ${absolutePath}`);
                            }
                            m3u8.push((0, path_1.resolve)(process.env.SIMULATE ? savedPath : (0, true_case_path_1.trueCasePathSync)(savedPath)));
                            savedFiles.push(savedPath);
                        }
                    };
                }));
                if (savedFiles.length > 0) {
                    const uniqueDirs = new Set(savedFiles.map((filePath) => (0, path_1.dirname)((0, path_1.resolve)(filePath))));
                    terminal_progress_1.terminalProgress.log(signale_1.default.info('Saved in:'));
                    uniqueDirs.forEach((dirPath) => {
                        terminal_progress_1.terminalProgress.log(chalk_1.default.green(dirPath));
                    });
                }
                if ((options.createPlaylist || data.linktype === 'playlist') && !process.env.SIMULATE && m3u8.length > 1) {
                    const playlistDir = (0, util_1.commonPath)([...new Set(savedFiles.map(path_1.dirname))]);
                    const playlistFile = (0, path_1.join)(playlistDir, (0, util_1.sanitizeFilename)(data.linkinfo.TITLE || data.linkinfo.ALB_TITLE));
                    if (!resolveFullPath) {
                        const resolvedPlaylistDir = (0, path_1.resolve)(playlistDir) + path_1.sep;
                        m3u8 = m3u8.map((file) => file.replace(resolvedPlaylistDir, ''));
                    }
                    (0, fs_1.writeFileSync)(playlistFile + '.m3u8', '#EXTM3U' + os_1.EOL + m3u8.join(os_1.EOL), { encoding: 'utf-8' });
                }
            }
            else {
                console.log(signale_1.default.info('No items to download!'));
            }
        }
        catch (err) {
            console.error(signale_1.default.error(err.message));
        }
        if (!options.headless && !skipPrompt) {
            await startDownload(saveLayout, '', skipPrompt);
        }
    };
    const startQobuzDownload = async (saveLayout, url, skipPrompt) => {
        try {
            if (!options.quality) {
                const { musicQuality } = await (0, prompts_1.default)({
                    type: 'select',
                    name: 'musicQuality',
                    message: 'Select maximum music quality:',
                    choices: [
                        { title: 'MP3  - 320 kbps', value: '320kbps' },
                        { title: 'FLAC - CD, 16-bit/44.1 kHz', value: '44khz' },
                        { title: 'FLAC - HiFi, 24-bit/96 kHz', value: '96khz' },
                        { title: 'FLAC - HiFi, 24-bit/192 kHz', value: '192khz' },
                    ],
                    initial: 1,
                }, { onCancel });
                options.quality = musicQuality;
            }
            options.quality = normalizeQuality(options.quality || '320kbps', 'qobuz');
            if (!url) {
                const runQobuzExplorerSession = async () => {
                    const queueItems = await collectSessionQueue('qobuz', 'Search Qobuz or paste a URL:', resolveQobuzQueueItem, true);
                    for (const [index, item] of queueItems.entries()) {
                        const itemsLeft = queueItems.length - index - 1;
                        console.log(signale_1.default.info(`Starting queue item ${index + 1}/${queueItems.length}: ${item.label}${itemsLeft ? ` (${itemsLeft} left)` : ''}`));
                        await startQobuzDownload(saveLayout, item.url, true);
                    }
                    console.log(signale_1.default.success('Qobuz queue complete. Returning to explorer.'));
                    await runQobuzExplorerSession();
                };
                await runQobuzExplorerSession();
                return;
            }
            let data;
            let searchData = null;
            if (!url.match(urlRegex)) {
                if (options.headless) {
                    throw new Error('Please provide a valid URL. Unknown URL: ' + url);
                }
                else if (url.startsWith('spotify:') || url.includes('spotify.com')) {
                    console.log(signale_1.default.info('Converting Spotify content to Qobuz...'));
                    searchData = await (0, to_qobuz_parser_1.parseToQobuz)(url);
                    if (!options.headless && searchData.tracks.length > 1) {
                        searchData.tracks = await promptTrackSubsetSelection(buildQobuzQueuePreview(searchData), searchData.tracks, (t) => ({
                            title: t.title,
                            value: t,
                            description: describeQobuzTrack(t),
                        }));
                    }
                }
                else {
                    const selectedResult = await promptGroupedSearchSelection('qobuz', url);
                    if (selectedResult.type === 'artist') {
                        url = (await promptQobuzArtistAlbumSelection(selectedResult)).url;
                    }
                    else if (selectedResult.type === 'album') {
                        url = `https://play.qobuz.com/album/${selectedResult.id}`;
                    }
                    else if (selectedResult.type === 'playlist') {
                        url = `https://play.qobuz.com/playlist/${selectedResult.id}`;
                    }
                    else {
                        const selectedTrack = selectedResult.rawData;
                        if (selectedTrack.version && !selectedTrack.title.includes(selectedTrack.version)) {
                            selectedTrack.title += ` (${selectedTrack.version})`;
                        }
                        searchData = {
                            info: { type: 'qobuz-track', id: String(selectedTrack.id) },
                            linktype: 'qobuz-track',
                            linkinfo: {},
                            tracks: [selectedTrack],
                        };
                    }
                }
            }
            if (searchData) {
                data = searchData;
            }
            else {
                data = await (0, to_qobuz_parser_1.parseToQobuz)(url);
            }
            if (!options.headless && data.tracks.length > 1 && !searchData) {
                data.tracks = await promptTrackSubsetSelection(buildQobuzQueuePreview(data), data.tracks, (t) => ({
                    title: t.title,
                    value: t,
                    description: describeQobuzTrack(t),
                }));
            }
            if (data && data.tracks.length > 0) {
                console.log(signale_1.default.info(`Proceeding download of ${data.tracks.length} tracks. Be patient.`));
                if (data.linktype === 'qobuz-playlist' || data.linktype === 'spotify-playlist') {
                    const filteredTracks = data.tracks.filter((item, index, self) => index === self.findIndex((t) => t.id === item.id));
                    const duplicateTracks = data.tracks.length - filteredTracks.length;
                    if (duplicateTracks > 0) {
                        data.tracks = filteredTracks
                            .sort((a, b) => a.track_number - b.track_number)
                            .map((t, i) => {
                            t.track_number = i + 1;
                            return t;
                        });
                        console.log(signale_1.default.warn(`Removed ${duplicateTracks} duplicate ${duplicateTracks > 1 ? 'tracks' : 'track'}.`));
                    }
                }
                const resolveFullPath = Boolean(options.resolveFullPath ?? conf.get('playlist.resolveFullPath'));
                const selectedQuality = options.quality || '320kbps';
                const savedFiles = [];
                let m3u8Local = [];
                if (data.tracks && data.tracks.length > 0) {
                    await queue.addAll(data.tracks.map((track, index) => {
                        return async () => {
                            if (!track || !track.title || typeof track.title !== 'string') {
                                console.error(signale_1.default.error(`Error: Invalid track data. Track: ${JSON.stringify(track)}`));
                                return;
                            }
                            try {
                                const savedPath = await (0, download_qobuz_track_1.default)({
                                    track,
                                    quality: selectedQuality,
                                    info: data.info,
                                    coverSizes: conf.get('coverSize'),
                                    path: options.output ? options.output : saveLayout[data.linktype],
                                    totalTracks: data.tracks.length,
                                    message: `(${index + 1}/${data.tracks.length})`,
                                    album: track.album,
                                    qobuzDownloadCover: conf.get('qobuzDownloadCover', false),
                                    listTitle: data.linkinfo.title || data.linkinfo.name || 'Unknown Playlist',
                                });
                                if (savedPath) {
                                    const absolutePath = (0, path_1.resolve)(savedPath);
                                    if (!terminal_progress_1.terminalProgress.isEnabled()) {
                                        terminal_progress_1.terminalProgress.log(chalk_1.default.green('✔ Path:') + ` ${absolutePath}`);
                                    }
                                    m3u8Local.push((0, path_1.resolve)(process.env.SIMULATE ? savedPath : (0, true_case_path_1.trueCasePathSync)(savedPath)));
                                    savedFiles.push(savedPath);
                                }
                            }
                            catch (err) {
                                if (err instanceof Error) {
                                    console.error(`Error during track download: ${err.message}`);
                                }
                                else {
                                    console.error(`Unexpected error: ${JSON.stringify(err)}`);
                                }
                                console.error(`Track data that caused the error: ${JSON.stringify(track, null, 2)}`);
                                throw err;
                            }
                        };
                    }));
                }
                if (savedFiles.length > 0) {
                    const uniqueDirectories = new Set(savedFiles.map((filePath) => (0, path_1.resolve)((0, path_1.dirname)(filePath))));
                    terminal_progress_1.terminalProgress.log(signale_1.default.info('Saved in:'));
                    uniqueDirectories.forEach((dir) => {
                        terminal_progress_1.terminalProgress.log(chalk_1.default.green(dir));
                    });
                    terminal_progress_1.terminalProgress.log('');
                }
                if ((options.createPlaylist || data.linktype === 'qobuz-playlist' || data.linktype === 'spotify-playlist') &&
                    !process.env.SIMULATE &&
                    m3u8Local.length > 1) {
                    const playlistDir = (0, util_1.commonPath)([...new Set(savedFiles.map(path_1.dirname))]);
                    const playlistFile = (0, path_1.join)(playlistDir, (0, util_1.sanitizeFilename)((data.linkinfo.name || data.linkinfo.title || 'Untitled Playlist') + '.m3u8'));
                    if (!resolveFullPath) {
                        const resolvedPlaylistDir = (0, path_1.resolve)(playlistDir) + path_1.sep;
                        m3u8Local = m3u8Local.map((file) => file.replace(resolvedPlaylistDir, ''));
                    }
                    (0, fs_1.writeFileSync)(playlistFile, '#EXTM3U' + os_1.EOL + m3u8Local.join(os_1.EOL), { encoding: 'utf-8' });
                }
            }
            else {
                console.log(signale_1.default.info('No items to download!'));
            }
        }
        catch (err) {
            if (err instanceof Error) {
                console.error(signale_1.default.error(err.message));
            }
            else {
                console.error(`Unexpected error: ${JSON.stringify(err)}`);
            }
        }
        if (!options.headless && !skipPrompt) {
            await startQobuzDownload(saveLayout, '', skipPrompt);
        }
    };
    return { startDownload, startQobuzDownload };
};
exports.createCliDownloads = createCliDownloads;
