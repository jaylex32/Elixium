"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCatalogSearch = void 0;
const util_1 = require("../lib/util");
const toReleaseDate = (value) => {
    if (typeof value !== 'string' || value.length === 0)
        return null;
    const parsed = new Date(value);
    if (Number.isNaN(parsed.getTime()))
        return null;
    return parsed.toISOString().slice(0, 10);
};
const createCatalogSearch = ({ deezer, qobuz, ensureQobuzSearchReady }) => {
    const performDeezerSearch = async (query, type, limit = 50, offset = 0) => {
        const searchTypes = type.toUpperCase();
        const searchResult = await deezer.searchMusicPaged(query, searchTypes, limit, offset);
        const results = [];
        const data = searchResult?.data || [];
        for (const item of data) {
            if (type === 'track') {
                const track = item;
                results.push({
                    id: track.SNG_ID,
                    title: track.SNG_TITLE + (track.VERSION ? ` ${track.VERSION}` : ''),
                    artist: track.ART_NAME,
                    album: track.ALB_TITLE,
                    duration: (0, util_1.formatSecondsReadable)(Number(track.DURATION)),
                    year: track.PHYSICAL_RELEASE_DATE
                        ? new Date(track.PHYSICAL_RELEASE_DATE).getFullYear()
                        : null,
                    releaseDate: toReleaseDate(track.PHYSICAL_RELEASE_DATE),
                    type: 'track',
                    rawData: track,
                });
            }
            else if (type === 'album') {
                const album = item;
                results.push({
                    id: album.ALB_ID,
                    title: album.ALB_TITLE,
                    artist: album.ART_NAME,
                    album: album.ALB_TITLE,
                    duration: `${album.NUMBER_TRACK} tracks`,
                    year: album.PHYSICAL_RELEASE_DATE ? new Date(album.PHYSICAL_RELEASE_DATE).getFullYear() : null,
                    releaseDate: toReleaseDate(album.PHYSICAL_RELEASE_DATE),
                    type: 'album',
                    rawData: album,
                });
            }
            else if (type === 'artist') {
                const artist = item;
                results.push({
                    id: artist.ART_ID,
                    title: artist.ART_NAME,
                    artist: artist.ART_NAME,
                    album: 'Artist',
                    duration: `${artist.NB_FAN} fans`,
                    type: 'artist',
                    rawData: artist,
                });
            }
            else if (type === 'playlist') {
                const playlist = item;
                results.push({
                    id: playlist.PLAYLIST_ID,
                    title: playlist.TITLE,
                    artist: playlist.PARENT_USERNAME,
                    album: 'Playlist',
                    duration: `${playlist.NB_SONG} tracks`,
                    type: 'playlist',
                    rawData: playlist,
                });
            }
        }
        return results;
    };
    const performQobuzSearch = async (query, type, limit = 50, offset = 0) => {
        await ensureQobuzSearchReady();
        const results = [];
        if (type === 'track') {
            const searchResult = await qobuz.searchMusic(query, 'track', limit, offset);
            for (const item of searchResult.tracks.items) {
                results.push({
                    id: String(item.id),
                    title: item.title + (item.version ? ` (${item.version})` : ''),
                    artist: item.performer.name,
                    album: item.album?.title || 'N/A',
                    duration: (0, util_1.formatSecondsReadable)(Number(item.duration)),
                    year: item.album?.release_date_original ? new Date(item.album.release_date_original).getFullYear() : null,
                    releaseDate: toReleaseDate(item.album?.release_date_original),
                    type: 'track',
                    maximum_bit_depth: item.maximum_bit_depth,
                    maximum_sampling_rate: item.maximum_sampling_rate,
                    hires: item.hires,
                    hires_streamable: item.hires_streamable,
                    rawData: item,
                });
            }
        }
        else if (type === 'album') {
            const searchResult = await qobuz.searchMusic(query, 'album', limit, offset);
            for (const item of searchResult.albums.items) {
                results.push({
                    id: String(item.id),
                    title: item.title,
                    artist: item.artist.name,
                    album: item.title,
                    duration: `${item.tracks_count} tracks`,
                    year: item.release_date_original ? new Date(item.release_date_original).getFullYear() : null,
                    releaseDate: toReleaseDate(item.release_date_original),
                    type: 'album',
                    maximum_bit_depth: item.maximum_bit_depth,
                    maximum_sampling_rate: item.maximum_sampling_rate,
                    hires: item.hires,
                    hires_streamable: item.hires_streamable,
                    rawData: item,
                });
            }
        }
        else if (type === 'artist') {
            const searchResult = await qobuz.searchMusic(query, 'artist', limit, offset);
            for (const item of searchResult.artists.items) {
                results.push({
                    id: String(item.id),
                    title: item.name,
                    artist: item.name,
                    album: 'Artist',
                    duration: `${item.albums_count} albums`,
                    type: 'artist',
                    rawData: item,
                });
            }
        }
        else if (type === 'playlist') {
            const searchResult = await qobuz.searchMusic(query, 'playlist', limit, offset);
            for (const item of searchResult.playlists.items) {
                results.push({
                    id: String(item.id),
                    title: item.name,
                    artist: item.owner.name,
                    album: 'Playlist',
                    duration: `${item.tracks_count} tracks`,
                    type: 'playlist',
                    rawData: item,
                });
            }
        }
        return results;
    };
    return { performDeezerSearch, performQobuzSearch };
};
exports.createCatalogSearch = createCatalogSearch;
