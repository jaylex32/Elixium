"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createExplorer = void 0;
const chalk_1 = __importDefault(require("chalk"));
const prompts_1 = __importDefault(require("prompts"));
const signale_1 = __importDefault(require("../lib/signale"));
const util_1 = require("../lib/util");
const catalogTypes = ['artist', 'album', 'track', 'playlist'];
const parseSearchDirective = (input) => {
    const trimmed = input.trim();
    const typedSearch = trimmed.match(/^(artist|album|track|playlist)\s*:\s*(.+)$/i);
    if (typedSearch) {
        return {
            forcedType: typedSearch[1].toLowerCase(),
            query: typedSearch[2].trim(),
        };
    }
    return { query: trimmed };
};
const dedupeSearchResults = (results) => {
    const seen = new Set();
    return results.filter((result) => {
        const key = `${result.type}:${result.id}`;
        if (seen.has(key)) {
            return false;
        }
        seen.add(key);
        return true;
    });
};
const createEmptySearchGroups = () => ({
    artist: [],
    album: [],
    track: [],
    playlist: [],
});
const formatSearchChoiceTitle = (result) => {
    const badges = {
        artist: chalk_1.default.black.bgCyan(' ARTIST '),
        album: chalk_1.default.black.bgYellow(' ALBUM '),
        track: chalk_1.default.black.bgGreen(' TRACK '),
        playlist: chalk_1.default.black.bgMagenta(' PLAYLIST '),
    };
    return `${badges[result.type] || chalk_1.default.inverse(` ${result.type.toUpperCase()} `)} ${result.title}`;
};
const formatSearchChoiceDescription = (result) => {
    const meta = [result.artist, result.album !== 'Artist' ? result.album : null, result.duration, result.year || null]
        .filter(Boolean)
        .join(' • ');
    return meta || 'Open result';
};
const buildGroupedSearchChoices = (groups) => {
    const labels = {
        artist: 'Artists',
        album: 'Albums',
        track: 'Tracks',
        playlist: 'Playlists',
    };
    const choices = [];
    for (const type of catalogTypes) {
        const items = groups[type];
        if (!items.length) {
            continue;
        }
        choices.push({
            title: chalk_1.default.bold(labels[type]),
            value: `section-${type}`,
            disabled: true,
        });
        for (const item of items) {
            choices.push({
                title: formatSearchChoiceTitle(item),
                value: item,
                description: formatSearchChoiceDescription(item),
            });
        }
    }
    return choices;
};
const createExplorer = ({ onCancel, searchCatalog, getDeezerArtistAlbums, getQobuzArtistAlbums, }) => {
    const collectSearchGroups = async (service, query, forcedType, limit = 6) => {
        const groups = createEmptySearchGroups();
        const requestedTypes = forcedType ? [forcedType] : catalogTypes;
        const responses = await Promise.all(requestedTypes.map(async (type) => ({
            type,
            results: dedupeSearchResults(await searchCatalog(service, query, type, limit, 0)),
        })));
        for (const response of responses) {
            groups[response.type] = response.results;
        }
        return groups;
    };
    const promptGroupedSearchSelection = async (service, query) => {
        const directive = parseSearchDirective(query);
        const groups = await collectSearchGroups(service, directive.query, directive.forcedType);
        const choices = buildGroupedSearchChoices(groups);
        if (!choices.length) {
            throw new Error(`No ${service} results found for "${directive.query}"`);
        }
        const totalResults = Object.values(groups).reduce((count, items) => count + items.length, 0);
        const selection = await (0, prompts_1.default)({
            type: 'select',
            name: 'item',
            message: directive.forcedType
                ? `Select a ${directive.forcedType} result from ${totalResults} matches`
                : `Search anything: ${directive.query}`,
            choices,
        }, { onCancel });
        return selection.item;
    };
    const promptDeezerArtistAlbumSelection = async (artist) => {
        console.log(signale_1.default.info(`Browsing albums for ${artist.title}`));
        const albums = Array.from(new Map((await getDeezerArtistAlbums(String(artist.id))).map((item) => [item.ALB_ID, item])).values()).sort((left, right) => String(right.PHYSICAL_RELEASE_DATE || right.DIGITAL_RELEASE_DATE || '').localeCompare(String(left.PHYSICAL_RELEASE_DATE || left.DIGITAL_RELEASE_DATE || '')));
        if (!albums.length) {
            throw new Error(`No albums found for ${artist.title}`);
        }
        const choice = await (0, prompts_1.default)({
            type: 'select',
            name: 'item',
            message: `Select one album from ${artist.title}`,
            choices: albums.slice(0, 60).map((album) => ({
                title: album.ALB_TITLE,
                value: album,
                description: `${album.ART_NAME} • ${album.NUMBER_TRACK} tracks • ${album.PHYSICAL_RELEASE_DATE || album.DIGITAL_RELEASE_DATE || 'Unknown year'}`,
            })),
        }, { onCancel });
        return {
            label: `${artist.title} -> ${choice.item.ALB_TITLE}`,
            url: `https://deezer.com/us/album/${choice.item.ALB_ID}`,
        };
    };
    const promptQobuzArtistAlbumSelection = async (artist) => {
        console.log(signale_1.default.info(`Browsing albums for ${artist.title}`));
        const albums = [...(await getQobuzArtistAlbums(String(artist.id)))].sort((left, right) => String(right.release_date_original || '').localeCompare(String(left.release_date_original || '')));
        if (!albums.length) {
            throw new Error(`No albums found for ${artist.title}`);
        }
        const choice = await (0, prompts_1.default)({
            type: 'select',
            name: 'item',
            message: `Select one album from ${artist.title}`,
            choices: albums.slice(0, 60).map((album) => ({
                title: album.title,
                value: album,
                description: `${album.artist.name} • ${album.tracks_count} tracks • ${album.release_date_original || 'Unknown year'}`,
            })),
        }, { onCancel });
        return {
            label: `${artist.title} -> ${choice.item.title}`,
            url: `https://play.qobuz.com/album/${choice.item.id}`,
        };
    };
    const printExplorerIntro = (service, supportsSpotify = false) => {
        const serviceLabel = service === 'deezer' ? 'Deezer' : 'Qobuz';
        console.log(signale_1.default.info(`${serviceLabel} explorer ready`));
        console.log(signale_1.default.note('Search artists, albums, tracks, playlists, or paste a direct URL.'));
        console.log(signale_1.default.note('Prefix search is optional: artist:, album:, playlist:, track:'));
        if (supportsSpotify) {
            console.log(signale_1.default.note('Spotify links are converted when possible.'));
        }
    };
    const describeQobuzTrack = (track) => {
        const artistName = track.performer?.name || track.album?.artist?.name || 'Unknown Artist';
        const albumTitle = track.album?.title || 'Unknown Album';
        return `Artist: ${artistName}\nAlbum: ${albumTitle}\nDuration: ${(0, util_1.formatSecondsReadable)(Number(track.duration || 0))}`;
    };
    const promptCollectionDownloadMode = async (preview) => {
        const collectionType = preview.contentType.toLowerCase();
        const { action } = await (0, prompts_1.default)({
            type: 'select',
            name: 'action',
            message: `${preview.contentType} ready: ${preview.title} • ${preview.trackCount} tracks`,
            choices: [
                {
                    title: `Download full ${collectionType}`,
                    value: 'all',
                    description: `Run all ${preview.trackCount} tracks now`,
                },
                {
                    title: 'Pick specific tracks',
                    value: 'select',
                    description: 'Open the track picker for manual selection',
                },
            ],
            initial: 0,
        }, { onCancel });
        return action;
    };
    const promptTrackSubsetSelection = async (preview, tracks, buildChoice) => {
        if (tracks.length <= 1) {
            return tracks;
        }
        const action = await promptCollectionDownloadMode(preview);
        if (action === 'all') {
            console.log(signale_1.default.success(`Selected full ${preview.contentType.toLowerCase()}: ${preview.title}`));
            return tracks;
        }
        const choices = await (0, prompts_1.default)({
            type: 'multiselect',
            name: 'items',
            message: `Pick tracks from ${preview.title}`,
            instructions: false,
            choices: tracks.map((track) => buildChoice(track)),
        }, { onCancel });
        console.log(signale_1.default.success(`Selected ${choices.items.length}/${tracks.length} tracks from ${preview.title}`));
        return choices.items;
    };
    return {
        promptGroupedSearchSelection,
        promptDeezerArtistAlbumSelection,
        promptQobuzArtistAlbumSelection,
        printExplorerIntro,
        describeQobuzTrack,
        promptTrackSubsetSelection,
    };
};
exports.createExplorer = createExplorer;
