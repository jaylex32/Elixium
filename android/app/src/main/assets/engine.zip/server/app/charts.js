"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createCharts = void 0;
const util_1 = require("../lib/util");
const QOBUZ_CHART_GENRES = [
    { id: 'best-sellers', name: 'Best Sellers' },
    { id: 'most-streamed', name: 'Most Streamed' },
    { id: 'press-awards', name: 'Press Awards' },
    { id: 'editor-picks', name: 'Editor Picks' },
    { id: 'new-releases', name: 'New Releases' },
];
const QOBUZ_FEATURED_TYPE = {
    'best-sellers': 'best-sellers',
    'most-streamed': 'most-streamed',
    'press-awards': 'press-awards',
    'editor-picks': 'editor-picks',
    'new-releases': 'new-releases',
};
const CHART_OWNER = 'Deezer Charts';
const COUNTRY_CACHE_MS = 6 * 60 * 60 * 1000;
const createCharts = ({ qobuz, makeHttpRequest, ensureQobuzSearchReady }) => {
    let countryCache = null;
    const getChartCountries = async () => {
        if (countryCache && Date.now() - countryCache.at < COUNTRY_CACHE_MS)
            return countryCache.countries;
        const seen = new Map();
        for (const query of ['Top', 'Top 100', 'charts']) {
            for (const index of [0, 25, 50, 75]) {
                const url = `https://api.deezer.com/search/playlist?q=${encodeURIComponent(query)}&limit=25&index=${index}`;
                let response;
                try {
                    response = await makeHttpRequest(url);
                }
                catch {
                    continue;
                }
                for (const playlist of (response && response.data) || []) {
                    if (playlist?.user?.name !== CHART_OWNER)
                        continue;
                    const title = String(playlist.title || '');
                    if (!title.toLowerCase().startsWith('top '))
                        continue;
                    seen.set(String(playlist.id), {
                        id: String(playlist.id),
                        name: title.replace(/^top\s+/i, '').trim() || title,
                        picture: playlist.picture_medium || playlist.picture,
                        trackCount: Number(playlist.nb_tracks || 0),
                    });
                }
            }
        }
        const countries = [...seen.values()].sort((a, b) => {
            if (/worldwide/i.test(a.name))
                return -1;
            if (/worldwide/i.test(b.name))
                return 1;
            return a.name.localeCompare(b.name);
        });
        if (countries.length > 0)
            countryCache = { at: Date.now(), countries };
        return countries;
    };
    const getCountryChart = async (playlistId, limit = 50, offset = 0) => {
        const url = `https://api.deezer.com/playlist/${encodeURIComponent(playlistId)}/tracks?limit=${Number(limit)}&index=${Number(offset)}`;
        const response = await makeHttpRequest(url);
        return mapDeezerChart('tracks', (response && response.data) || []);
    };
    const getChartGenres = async (service) => {
        if (service === 'qobuz')
            return QOBUZ_CHART_GENRES;
        const response = await makeHttpRequest('https://api.deezer.com/genre');
        const genres = ((response && response.data) || [])
            .filter((genre) => String(genre.id) !== '0')
            .map((genre) => ({ id: String(genre.id), name: genre.name, picture: genre.picture_medium }));
        return [{ id: '0', name: 'All genres' }, ...genres];
    };
    const mapDeezerChart = (kind, items) => {
        if (kind === 'tracks') {
            return items.map((track) => ({
                id: String(track.id),
                title: track.title + (track.title_version ? ` ${track.title_version}` : ''),
                artist: track.artist?.name || 'Unknown Artist',
                album: track.album?.title || '',
                type: 'track',
                duration: (0, util_1.formatSecondsReadable)(Number(track.duration || 0)),
                rawData: track,
            }));
        }
        if (kind === 'albums') {
            return items.map((album) => ({
                id: String(album.id),
                title: album.title,
                artist: album.artist?.name || 'Unknown Artist',
                album: album.title,
                type: 'album',
                duration: album.record_type ? String(album.record_type) : '',
                rawData: album,
            }));
        }
        if (kind === 'artists') {
            return items.map((artist) => ({
                id: String(artist.id),
                title: artist.name,
                artist: artist.name,
                album: 'Artist',
                type: 'artist',
                duration: '',
                rawData: artist,
            }));
        }
        return items.map((playlist) => ({
            id: String(playlist.id),
            title: playlist.title,
            artist: playlist.user?.name || 'Deezer',
            album: 'Playlist',
            type: 'playlist',
            duration: `${playlist.nb_tracks || 0} tracks`,
            rawData: playlist,
        }));
    };
    const qobuzAlbumResult = (album) => ({
        id: String(album.id),
        title: album.title,
        artist: album.artist?.name || 'Unknown Artist',
        album: album.title,
        type: 'album',
        duration: album.tracks_count ? `${album.tracks_count} tracks` : '',
        year: album.release_date_original ? Number(String(album.release_date_original).slice(0, 4)) : null,
        maximum_bit_depth: album.maximum_bit_depth,
        maximum_sampling_rate: album.maximum_sampling_rate,
        hires: album.hires,
        rawData: album,
    });
    const qobuzTrackResult = (track) => ({
        id: String(track.id),
        title: String(track.title || '') + (track.version ? ` (${track.version})` : ''),
        artist: track.performer?.name || track.album?.artist?.name || 'Unknown Artist',
        album: track.album?.title || '',
        type: 'track',
        duration: (0, util_1.formatSecondsReadable)(Number(track.duration || 0)),
        maximum_bit_depth: track.maximum_bit_depth,
        maximum_sampling_rate: track.maximum_sampling_rate,
        hires: track.hires,
        rawData: track,
    });
    const qobuzChart = async (type, kind, limit, offset) => {
        const request = (endpoint, params) => qobuz.qobuzRequest?.(endpoint, params).catch(() => null);
        if (kind === 'albums' || kind === 'artists') {
            const response = await request('album/getFeatured', { type, offset, limit: kind === 'artists' ? 100 : limit });
            const albums = response?.albums?.items || [];
            if (kind === 'albums')
                return albums.map(qobuzAlbumResult);
            const seen = new Set();
            const artists = [];
            for (const album of albums) {
                const artist = album?.artist;
                if (!artist?.id || seen.has(String(artist.id)))
                    continue;
                seen.add(String(artist.id));
                artists.push({
                    id: String(artist.id),
                    title: String(artist.name || ''),
                    artist: String(artist.name || ''),
                    album: '',
                    type: 'artist',
                    duration: '',
                    rawData: artist,
                });
            }
            return artists.slice(offset, offset + limit);
        }
        const featured = await request('playlist/getFeatured', { type: 'editor-picks', offset: 0, limit: 50 });
        const playlists = featured?.playlists?.items || [];
        if (kind === 'playlists') {
            return playlists.slice(offset, offset + limit).map((playlist) => ({
                id: String(playlist.id),
                title: String(playlist.name || ''),
                artist: playlist.owner?.name || 'Qobuz',
                album: '',
                type: 'playlist',
                duration: playlist.tracks_count ? `${playlist.tracks_count} tracks` : '',
                rawData: playlist,
            }));
        }
        const sources = playlists.slice(0, 4);
        const batches = await Promise.all(sources.map((playlist) => request('playlist/get', { playlist_id: playlist.id, extra: 'tracks', limit: 100, offset: 0 })));
        const tracks = [];
        const seenTracks = new Set();
        for (const batch of batches) {
            for (const track of batch?.tracks?.items || []) {
                const id = String(track?.id ?? '');
                if (!id || seenTracks.has(id))
                    continue;
                seenTracks.add(id);
                tracks.push(qobuzTrackResult(track));
            }
        }
        return tracks.slice(offset, offset + limit);
    };
    const getCharts = async (service, genreId, kind, limit = 50, offset = 0) => {
        if (service === 'deezer') {
            const url = `https://api.deezer.com/chart/${encodeURIComponent(genreId || '0')}/${kind}?limit=${Number(limit)}&index=${Number(offset)}`;
            const response = await makeHttpRequest(url);
            return mapDeezerChart(kind, (response && response.data) || []);
        }
        if (service === 'qobuz') {
            await ensureQobuzSearchReady();
            const type = QOBUZ_FEATURED_TYPE[genreId] || 'best-sellers';
            return qobuzChart(type, kind, Number(limit), Number(offset));
        }
        return [];
    };
    return { getChartGenres, getCharts, getChartCountries, getCountryChart };
};
exports.createCharts = createCharts;
