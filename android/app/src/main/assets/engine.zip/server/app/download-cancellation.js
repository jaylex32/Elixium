"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.discardPartials = exports.resumableRequest = exports.pauseJob = exports.cancelJob = exports.getJob = exports.endJob = exports.beginJob = void 0;
const fs_1 = require("fs");
const jobs = new Map();
const beginJob = (id, request) => {
    const previous = jobs.get(id);
    const job = {
        cancelled: false,
        paused: false,
        partials: new Set(),
        request: request ?? previous?.request,
    };
    jobs.set(id, job);
    return job;
};
exports.beginJob = beginJob;
const endJob = (id) => {
    jobs.delete(id);
};
exports.endJob = endJob;
const getJob = (id) => jobs.get(id);
exports.getJob = getJob;
const cancelJob = (id) => {
    const job = jobs.get(id);
    if (!job)
        return false;
    job.cancelled = true;
    try {
        job.abort?.();
    }
    catch {
    }
    return true;
};
exports.cancelJob = cancelJob;
const pauseJob = (id) => {
    const job = jobs.get(id);
    if (!job || job.cancelled)
        return false;
    job.paused = true;
    try {
        job.abort?.();
    }
    catch {
    }
    return true;
};
exports.pauseJob = pauseJob;
const resumableRequest = (id) => {
    const job = jobs.get(id);
    return job && job.paused && job.request ? job.request : null;
};
exports.resumableRequest = resumableRequest;
const discardPartials = (job) => {
    let removed = 0;
    for (const file of job.partials) {
        try {
            if ((0, fs_1.existsSync)(file)) {
                (0, fs_1.unlinkSync)(file);
                removed += 1;
            }
        }
        catch {
        }
    }
    job.partials.clear();
    return removed;
};
exports.discardPartials = discardPartials;
