"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerCatalogSocketHandlers = void 0;
const describeParseError = (error) => {
    const message = String(error?.message ?? '');
    if (message && message !== '[object Object]')
        return message;
    const status = Number(error?.statusCode ?? error?.status ?? 0);
    const retryAfter = Number(error?.headers?.['retry-after'] ?? 0);
    if (status === 429 || retryAfter > 0) {
        return retryAfter
            ? `Spotify is rate limiting requests — try again in about ${retryAfter} seconds`
            : 'Spotify is rate limiting requests — try again shortly';
    }
    if (status === 401 || status === 403)
        return 'Spotify rejected the request — check the sp_dc cookie in Settings';
    if (status === 404)
        return 'That link could not be found';
    return status ? `The link could not be read (HTTP ${status})` : 'The link could not be read';
};
const registerCatalogSocketHandlers = ({ socket, artistContent, performDeezerSearch, performQobuzSearch, ensureQobuzSearchReady, parseToQobuz, parseDeezerUrl, resolveYtMusicUrl, }) => {
    socket.on('search', async (data) => {
        try {
            let results = [];
            if (data.service === 'deezer') {
                results = await performDeezerSearch(data.query, data.type, Number(data.limit || 50), Number(data.offset || 0));
            }
            else if (data.service === 'qobuz') {
                results = await performQobuzSearch(data.query, data.type, Number(data.limit || 50), Number(data.offset || 0));
            }
            socket.emit('searchResults', results);
        }
        catch (error) {
            socket.emit('searchError', { message: error.message });
        }
    });
    socket.on('getArtistAlbums', async (data) => {
        try {
            const { service, artistId, artistName, limit = 30, offset = 0 } = data || {};
            const items = await artistContent.getArtistAlbums(service, artistId, Number(limit), Number(offset), artistName);
            socket.emit('artistAlbums', { artistId, items });
        }
        catch (error) {
            socket.emit('artistAlbumsError', { artistId: data?.artistId, message: error.message });
        }
    });
    socket.on('getArtistTracks', async (data) => {
        try {
            const { service, artistId, artistName, limit = 50, offset = 0 } = data || {};
            const items = await artistContent.getArtistTracks(service, artistId, Number(limit), Number(offset), artistName);
            socket.emit('artistTracks', { artistId, items });
        }
        catch (error) {
            socket.emit('artistTracksError', { artistId: data?.artistId, message: error.message });
        }
    });
    socket.on('getArtistPlaylists', async (data) => {
        try {
            const { service, artistId, artistName, limit = 30, offset = 0 } = data || {};
            const items = await artistContent.getArtistPlaylists(service, artistId, artistName, Number(limit), Number(offset));
            socket.emit('artistPlaylists', { artistId, items });
        }
        catch (error) {
            socket.emit('artistPlaylistsError', { artistId: data?.artistId, message: error.message });
        }
    });
    socket.on('parseUrl', async (data) => {
        try {
            let parsedData;
            const link = String(data?.url || '');
            const isYouTubeLink = link.includes('youtube.com') || link.includes('youtu.be');
            if (isYouTubeLink && resolveYtMusicUrl) {
                const resolved = await resolveYtMusicUrl(link).catch((error) => {
                    throw new Error(`YouTube Music could not read that link: ${error?.message ?? error}`);
                });
                if (!resolved || resolved.tracks.length === 0) {
                    throw new Error('YouTube Music found nothing at that link');
                }
                if (resolved && resolved.tracks.length > 0) {
                    const target = data?.service === 'deezer' || data?.service === 'qobuz' ? data.service : 'ytmusic';
                    socket.emit('urlParseResults', {
                        tracks: resolved.tracks,
                        linktype: `${target}-${resolved.kind}`,
                        linkinfo: { title: resolved.title, artist: { name: resolved.tracks[0]?.artist ?? '' } },
                        service: target,
                        metadata: {
                            originalUrl: String(data.url),
                            service: target,
                            contentType: `${target}-${resolved.kind}`,
                            trackCount: resolved.tracks.length,
                            title: resolved.title || resolved.tracks[0]?.title || 'Unknown Content',
                        },
                    });
                    return;
                }
            }
            const hasExplicitService = typeof data?.service === 'string' && data.service.length > 0;
            const convertingToYtMusic = data?.service === 'ytmusic' && !isYouTubeLink;
            const isQobuzTarget = data?.service === 'qobuz' ||
                (!hasExplicitService &&
                    (data.url.includes('qobuz.com') ||
                        data.url.includes('play.qobuz.com') ||
                        data.url.includes('spotify.com') ||
                        data.url.includes('open.spotify.com') ||
                        data.url.startsWith('spotify:') ||
                        data.url.includes('tidal.com') ||
                        data.url.includes('youtube.com') ||
                        data.url.includes('youtu.be')));
            if (data.url.includes('spotify.com') ||
                data.url.includes('open.spotify.com') ||
                data.url.startsWith('spotify:')) {
                if (isQobuzTarget)
                    await ensureQobuzSearchReady();
                parsedData = isQobuzTarget ? await parseToQobuz(data.url) : await parseDeezerUrl(data.url);
                if (data.url.includes('/playlist/')) {
                    parsedData.linktype = 'spotify-playlist';
                }
                else if (data.url.includes('/album/')) {
                    parsedData.linktype = 'spotify-album';
                }
                else if (data.url.includes('/track/')) {
                    parsedData.linktype = 'spotify-track';
                }
                else if (data.url.includes('/artist/')) {
                    parsedData.linktype = 'spotify-artist';
                }
            }
            else if (data.url.includes('deezer.com')) {
                parsedData = isQobuzTarget ? await parseToQobuz(data.url) : await parseDeezerUrl(data.url);
                if (data.url.includes('/playlist/')) {
                    parsedData.linktype = isQobuzTarget ? 'qobuz-playlist' : 'playlist';
                }
                else if (data.url.includes('/album/')) {
                    parsedData.linktype = isQobuzTarget ? 'qobuz-album' : 'album';
                }
                else if (data.url.includes('/track/')) {
                    parsedData.linktype = isQobuzTarget ? 'qobuz-track' : 'track';
                }
                else if (data.url.includes('/artist/')) {
                    parsedData.linktype = isQobuzTarget ? 'qobuz-artist' : 'artist';
                }
            }
            else if (data.url.includes('tidal.com') || data.url.includes('youtube.com') || data.url.includes('youtu.be')) {
                await ensureQobuzSearchReady();
                parsedData = await parseToQobuz(data.url);
                if (data.url.includes('/playlist/')) {
                    parsedData.linktype = 'qobuz-playlist';
                }
                else if (data.url.includes('/album/')) {
                    parsedData.linktype = 'qobuz-album';
                }
                else if (data.url.includes('/track/') || data.url.includes('youtube.com') || data.url.includes('youtu.be')) {
                    parsedData.linktype = 'qobuz-track';
                }
                else if (data.url.includes('/artist/')) {
                    parsedData.linktype = 'qobuz-artist';
                }
            }
            else if (data.url.includes('qobuz.com') || data.url.includes('play.qobuz.com')) {
                await ensureQobuzSearchReady();
                parsedData = await parseToQobuz(data.url);
                if (data.url.includes('/playlist/')) {
                    parsedData.linktype = 'qobuz-playlist';
                }
                else if (data.url.includes('/album/')) {
                    parsedData.linktype = 'qobuz-album';
                }
                else if (data.url.includes('/track/')) {
                    parsedData.linktype = 'qobuz-track';
                }
                else if (data.url.includes('/artist/')) {
                    parsedData.linktype = 'qobuz-artist';
                }
            }
            else {
                throw new Error('Unsupported URL format');
            }
            if (!parsedData.tracks || parsedData.tracks.length === 0) {
                throw new Error('No tracks found in the provided URL');
            }
            parsedData.metadata = {
                originalUrl: data.url,
                service: data.url.includes('deezer.com')
                    ? 'deezer'
                    : data.url.includes('qobuz.com') || data.url.includes('play.qobuz.com')
                        ? 'qobuz'
                        : data.url.includes('tidal.com')
                            ? 'tidal'
                            : data.url.includes('youtube.com') || data.url.includes('youtu.be')
                                ? 'youtube'
                                : 'spotify',
                contentType: parsedData.linktype,
                trackCount: parsedData.tracks.length,
                title: parsedData.linkinfo?.title ||
                    parsedData.linkinfo?.name ||
                    parsedData.linkinfo?.TITLE ||
                    parsedData.linkinfo?.ALB_TITLE ||
                    parsedData.linkinfo?.SNG_TITLE ||
                    parsedData.tracks?.[0]?.SNG_TITLE ||
                    parsedData.tracks?.[0]?.title ||
                    'Unknown Content',
            };
            if (convertingToYtMusic) {
                parsedData.metadata.service = 'ytmusic';
                parsedData.metadata.contentType = `ytmusic-${String(parsedData.linktype || 'track')
                    .split('-')
                    .pop()}`;
            }
            socket.emit('urlParseResults', parsedData);
        }
        catch (error) {
            console.error('URL parsing error:', error);
            socket.emit('urlParseError', { message: describeParseError(error) });
        }
    });
};
exports.registerCatalogSocketHandlers = registerCatalogSocketHandlers;
