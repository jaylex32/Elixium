"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatCliError = exports.terminalNotes = exports.terminalExamples = exports.formatBanner = exports.terminalRule = exports.terminalWidth = void 0;
const cliui_1 = __importDefault(require("cliui"));
const picocolors_1 = __importDefault(require("picocolors"));
const brand_1 = require("./brand");
const ansiPattern = new RegExp(`${String.fromCharCode(27)}\\[[0-9;]*m`, 'g');
const stripAnsi = (value) => value.replace(ansiPattern, '');
const clamp = (value, min, max) => Math.min(Math.max(value, min), max);
const noPadding = [0, 0, 0, 0];
const terminalWidth = () => clamp(process.stdout.columns || 88, 72, 100);
exports.terminalWidth = terminalWidth;
const terminalRule = (width = (0, exports.terminalWidth)()) => picocolors_1.default.dim('─'.repeat(width));
exports.terminalRule = terminalRule;
const visibleLength = (value) => stripAnsi(value).length;
const frameTop = (width = (0, exports.terminalWidth)()) => `${picocolors_1.default.dim('┌')}${picocolors_1.default.dim('─'.repeat(width - 2))}${picocolors_1.default.dim('┐')}`;
const frameMiddle = (width = (0, exports.terminalWidth)()) => `${picocolors_1.default.dim('├')}${picocolors_1.default.dim('─'.repeat(width - 2))}${picocolors_1.default.dim('┤')}`;
const frameBottom = (width = (0, exports.terminalWidth)()) => `${picocolors_1.default.dim('└')}${picocolors_1.default.dim('─'.repeat(width - 2))}${picocolors_1.default.dim('┘')}`;
const createUi = (width = (0, exports.terminalWidth)(), wrap = false) => (0, cliui_1.default)({ width, wrap });
const framedLine = (content = '', width = (0, exports.terminalWidth)(), align = 'left') => {
    const innerWidth = width - 2;
    const visible = visibleLength(content);
    const safeVisible = Math.min(visible, innerWidth);
    const remaining = Math.max(innerWidth - safeVisible, 0);
    if (align === 'center') {
        const leftPad = Math.floor(remaining / 2);
        const rightPad = remaining - leftPad;
        return `${picocolors_1.default.dim('│')}${' '.repeat(leftPad)}${content}${' '.repeat(rightPad)}${picocolors_1.default.dim('│')}`;
    }
    return `${picocolors_1.default.dim('│')} ${content}${' '.repeat(Math.max(innerWidth - safeVisible - 1, 0))}${picocolors_1.default.dim('│')}`;
};
const keyValueGrid = (entries, width = (0, exports.terminalWidth)()) => {
    const ui = createUi(width, false);
    const labelWidth = 12;
    for (const entry of entries) {
        ui.div({
            text: picocolors_1.default.bold(picocolors_1.default.white(entry.label.toUpperCase().padEnd(labelWidth))),
            width: labelWidth + 2,
            padding: [0, 0, 0, 2],
        }, { text: entry.value, width: width - labelWidth - 2, padding: noPadding });
    }
    return ui.toString().trimEnd();
};
const commandGrid = (rows, width = (0, exports.terminalWidth)()) => {
    const ui = createUi(width, false);
    for (const row of rows) {
        ui.div({ text: picocolors_1.default.cyan(`  ${brand_1.APP_COMMAND}`), width: 12, padding: noPadding }, { text: picocolors_1.default.dim(row.flags), width: 40, padding: noPadding }, { text: row.value, width: width - 52, padding: [0, 0, 0, 1] });
    }
    return ui.toString().trimEnd();
};
const bulletGrid = (title, lines, width = (0, exports.terminalWidth)()) => {
    const ui = createUi(width, true);
    ui.div(picocolors_1.default.bold(picocolors_1.default.white(title)));
    for (const line of lines) {
        ui.div({ text: picocolors_1.default.cyan('  ●'), width: 4, padding: noPadding }, { text: line, width: width - 4, padding: [0, 0, 0, 1] });
    }
    return ui.toString().trimEnd();
};
const formatBanner = (version) => {
    const width = (0, exports.terminalWidth)();
    const laneStrip = [
        picocolors_1.default.black(picocolors_1.default.bgCyan(' SEARCH ')),
        picocolors_1.default.black(picocolors_1.default.bgYellow(' EXPLORE ')),
        picocolors_1.default.black(picocolors_1.default.bgGreen(' DOWNLOAD ')),
        picocolors_1.default.black(picocolors_1.default.bgMagenta(' WEB ')),
    ].join('  ');
    const title = `${picocolors_1.default.bold(picocolors_1.default.cyan(brand_1.APP_BRAND))} ${picocolors_1.default.dim('// COMMAND DECK')}`;
    const versionChip = picocolors_1.default.black(picocolors_1.default.bgWhite(` VERSION ${version} `));
    const infoLines = [
        { label: 'COMMAND', value: picocolors_1.default.bold(picocolors_1.default.white(brand_1.APP_COMMAND)) },
        { label: 'CONFIG', value: picocolors_1.default.cyan(brand_1.DEFAULT_CONFIG_FILE) },
        { label: 'FLOW', value: picocolors_1.default.white('query -> result type -> album or playlist -> tracks') },
        { label: 'MODES', value: picocolors_1.default.white('interactive | headless | web') },
        { label: 'FOCUS', value: picocolors_1.default.dim('stronger explorer, cleaner routing, stability-first runtime') },
    ].map(({ label, value }) => `${picocolors_1.default.bold(picocolors_1.default.white(label.padEnd(8)))} ${picocolors_1.default.dim('::')} ${value}`);
    return [
        frameTop(width),
        framedLine('', width),
        framedLine(title, width, 'center'),
        framedLine(versionChip, width, 'center'),
        framedLine('', width),
        frameMiddle(width),
        framedLine('', width),
        framedLine(picocolors_1.default.white('Search anything, explore artists and albums, then route straight into downloads.'), width),
        framedLine('', width),
        framedLine(laneStrip, width, 'center'),
        framedLine('', width),
        frameMiddle(width),
        ...infoLines.map((line) => framedLine(line, width)),
        frameBottom(width),
    ].join('\n');
};
exports.formatBanner = formatBanner;
const terminalExamples = () => [
    picocolors_1.default.bold(picocolors_1.default.white('Launch Patterns')),
    commandGrid([
        { flags: '--url', value: 'https://www.deezer.com/track/3135556' },
        { flags: '--web --port', value: '3000' },
        { flags: '--qobuz --headless --quality 96khz', value: '--url https://play.qobuz.com/album/...' },
    ]),
].join('\n');
exports.terminalExamples = terminalExamples;
const terminalNotes = () => [
    bulletGrid('Operating Notes', [
        `Skip ${picocolors_1.default.cyan('--url')} to enter the interactive flow.`,
        `Use ${picocolors_1.default.cyan('--web')} for the browser interface and ${picocolors_1.default.cyan('--headless')} for automation.`,
        `Settings are stored in ${picocolors_1.default.cyan(brand_1.DEFAULT_CONFIG_FILE)} and loaded on startup.`,
    ]),
].join('\n');
exports.terminalNotes = terminalNotes;
const formatCliError = (value) => {
    const trimmed = value.trimEnd();
    const lines = trimmed.split('\n');
    const formatted = lines.map((line, index) => {
        if (!line.trim()) {
            return line;
        }
        if (index === 0) {
            return `${picocolors_1.default.black(picocolors_1.default.bgRed(' FAIL '))} ${picocolors_1.default.redBright(line)}`;
        }
        return `       ${picocolors_1.default.dim(stripAnsi(line))}`;
    });
    return formatted.join('\n') + '\n';
};
exports.formatCliError = formatCliError;
