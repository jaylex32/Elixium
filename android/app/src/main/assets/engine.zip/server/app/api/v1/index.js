"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerApiV1 = exports.API_V1_BASE = void 0;
const respond_1 = require("../respond");
const quality_1 = require("../quality");
const settings_1 = require("../settings");
const catalog_1 = require("./catalog");
const media_1 = require("./media");
const library_1 = require("./library");
exports.API_V1_BASE = '/api/v1';
const registerApiV1 = (deps) => {
    const { app, appVersion, appBrand, conf } = deps;
    const basePath = exports.API_V1_BASE;
    app.get(`${basePath}/health`, (0, respond_1.route)(async (_req, res) => {
        let configured = { deezer: false, qobuz: false, spotify: false };
        try {
            configured = (0, settings_1.readRedactedSettings)(conf).configured;
        }
        catch {
        }
        const readiness = deps.readiness?.();
        return (0, respond_1.sendData)(res, {
            status: 'ok',
            app: appBrand,
            version: appVersion,
            api: { version: 1, base: basePath },
            lifecycle: readiness?.lifecycle ?? 'core_ready',
            providers: readiness?.providers ?? [],
            services: {
                deezer: { configured: configured.deezer, qualities: quality_1.DEEZER_QUALITIES.map((q) => q.id) },
                qobuz: { configured: configured.qobuz, qualities: quality_1.QOBUZ_QUALITIES.map((q) => q.id) },
            },
            capabilities: {
                search: true,
                discovery: true,
                streaming: true,
                rangeRequests: true,
                directDownload: true,
                archiveDownload: true,
                serverSideDownload: true,
                watchlist: Boolean(deps.watchlist),
                realtime: { transport: 'socket.io', path: '/socket.io' },
            },
            serverTime: new Date().toISOString(),
        });
    }));
    app.post(`${basePath}/providers/:name/retry`, (0, respond_1.route)(async (req, res) => {
        if (!deps.retryProvider)
            throw new respond_1.ApiError('service_unavailable', 'Provider retry is not available on this server');
        const name = String(req.params.name || '');
        try {
            const status = await deps.retryProvider(name);
            return (0, respond_1.sendData)(res, status);
        }
        catch (error) {
            throw new respond_1.ApiError('not_found', error?.message || `Unknown provider: ${name}`);
        }
    }));
    app.get(basePath, (0, respond_1.route)(async (_req, res) => (0, respond_1.sendData)(res, {
        name: `${appBrand} API`,
        version: 1,
        endpoints: {
            health: `GET ${basePath}/health`,
            retryProvider: `POST ${basePath}/providers/:name/retry`,
            search: `GET ${basePath}/search?service=&q=&type=&limit=&offset=`,
            discovery: `GET ${basePath}/discovery?service=&type=&limit=`,
            albumTracks: `GET ${basePath}/albums/:id/tracks?service=`,
            artistTopTracks: `GET ${basePath}/artists/:id/top-tracks?service=`,
            playlistTracks: `GET ${basePath}/playlists/:id/tracks?service=`,
            item: `GET ${basePath}/items/:itemType/:id?service=`,
            parseUrl: `POST ${basePath}/parse-url`,
            qualities: `GET ${basePath}/qualities?service=`,
            genres: `GET ${basePath}/genres`,
            stream: `GET|HEAD ${basePath}/tracks/:id/stream?service=&quality=`,
            trackFile: `GET ${basePath}/tracks/:id/file?service=&quality=`,
            lyrics: `GET ${basePath}/tracks/:id/lyrics?service=`,
            archive: `POST ${basePath}/downloads/archive`,
            downloads: `GET ${basePath}/downloads`,
            startDownload: `POST ${basePath}/downloads`,
            settings: `GET|PATCH ${basePath}/settings`,
            verifyService: `POST ${basePath}/services/:service/verify`,
            watchlist: `GET ${basePath}/watchlist`,
            watchlistScan: `POST ${basePath}/watchlist/scan`,
        },
    })));
    (0, catalog_1.registerCatalogRoutes)({ ...deps, basePath });
    (0, media_1.registerMediaRoutes)({ ...deps, basePath });
    (0, library_1.registerLibraryRoutes)({ ...deps, basePath });
    app.use(`${basePath}/`, (req, res) => {
        (0, respond_1.sendError)(res, respond_1.ApiError.notFound(`No such endpoint: ${req.method} ${req.baseUrl}${req.path}`));
    });
};
exports.registerApiV1 = registerApiV1;
