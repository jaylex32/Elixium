"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createWebDownloads = void 0;
const p_queue_1 = __importDefault(require("p-queue"));
const download_cancellation_1 = require("./download-cancellation");
const metadata_options_1 = require("../lib/metadata-options");
const os_1 = require("os");
const fs_1 = require("fs");
const path_1 = require("path");
const layoutKeyFor = (linktype, service) => {
    const kind = String(linktype || '')
        .replace(/^(qobuz|spotify|tidal|youtube)-/, '')
        .toLowerCase();
    const key = ['album', 'artist', 'playlist'].includes(kind) ? kind : 'track';
    return service === 'qobuz' ? `qobuz-${key}` : key;
};
const createWebDownloads = ({ conf, qobuzDownloadTrack, deezerDownloadTrack, commonPath, sanitizeFilename, trueCasePathSync, }) => {
    const createPlaylistFile = async (savedFiles, m3u8, parsedData, data, socket) => {
        if (m3u8.length > 1 && !process.env.SIMULATE) {
            try {
                const linktype = String(parsedData.linktype ?? '');
                const shouldCreatePlaylist = /(^|-)(playlist|artist)$/.test(linktype) || conf.get('playlist.createPlaylist');
                if (shouldCreatePlaylist) {
                    const playlistDir = commonPath([...new Set(savedFiles.map(path_1.dirname))]);
                    const playlistName = sanitizeFilename(parsedData.linkinfo?.TITLE ||
                        parsedData.linkinfo?.title ||
                        parsedData.linkinfo?.name ||
                        'Downloaded Content');
                    const playlistFile = (0, path_1.join)(playlistDir, playlistName + '.m3u8');
                    (0, fs_1.mkdirSync)(playlistDir, { recursive: true });
                    const resolveFullPath = data.settings.resolveFullPath ?? conf.get('playlist.resolveFullPath');
                    let finalM3u8 = [...m3u8];
                    if (!resolveFullPath) {
                        const resolvedPlaylistDir = (0, path_1.resolve)(playlistDir) + path_1.sep;
                        finalM3u8 = m3u8.map((file) => file.replace(resolvedPlaylistDir, ''));
                    }
                    const m3u8Content = '#EXTM3U' + os_1.EOL + finalM3u8.join(os_1.EOL);
                    (0, fs_1.writeFileSync)(playlistFile, m3u8Content, { encoding: 'utf-8' });
                    console.log(`🎵 Created playlist file: ${playlistFile}`);
                    socket.emit('playlistCreated', {
                        path: playlistFile,
                        trackCount: finalM3u8.length,
                    });
                }
                else {
                    console.log(`📁 Skipped playlist creation for ${parsedData.linktype} (not a playlist or artist)`);
                }
            }
            catch (error) {
                console.error('❌ Error creating playlist file:', error.message);
            }
        }
    };
    const substituteQobuzPlaylistVariables = (layoutPath, track, parsedData) => {
        let result = layoutPath;
        const wantsNoNumbers = layoutPath.includes('{no_track_number}');
        const trackNumber = track.track_number || track.media_number || null;
        const formattedTrackNumber = trackNumber ? String(trackNumber).padStart(2, '0') : null;
        const originalTitle = track.title || 'Unknown Title';
        let cleanTitle = originalTitle;
        if (wantsNoNumbers) {
            cleanTitle = cleanTitle.replace(/^\d{1,2}[\s]*[-\.]\s*/, '');
            cleanTitle = cleanTitle.replace(/^\d{1,2}\s*/, '');
        }
        const artistName = track.album?.artist?.name || track.performer?.name || 'Unknown Artist';
        const albumTitle = track.album?.title || 'Unknown Album';
        const playlistTitle = parsedData.linkinfo?.title || parsedData.linkinfo?.name || 'Downloaded Playlist';
        result = result.replace(/{title}/g, sanitizeFilename(wantsNoNumbers ? cleanTitle : originalTitle));
        result = result.replace(/{clean_title}/g, sanitizeFilename(cleanTitle));
        result = result.replace(/{alb_artist}/g, sanitizeFilename(artistName));
        result = result.replace(/{alb_title}/g, sanitizeFilename(albumTitle));
        result = result.replace(/{list_title}/g, sanitizeFilename(playlistTitle));
        if (formattedTrackNumber && !wantsNoNumbers) {
            result = result.replace(/{track_number}/g, formattedTrackNumber);
            result = result.replace(/{track_with_dash}/g, formattedTrackNumber + ' - ');
            result = result.replace(/{track_with_dot}/g, formattedTrackNumber + '. ');
        }
        else {
            result = result.replace(/{track_number}/g, '');
            result = result.replace(/{track_with_dash}/g, '');
            result = result.replace(/{track_with_dot}/g, '');
        }
        result = result.replace(/{no_track_number}/g, '');
        result = result.replace(/{performer\.name}/g, sanitizeFilename(artistName));
        result = result.replace(/{album\.title}/g, sanitizeFilename(albumTitle));
        result = result.replace(/\s+/g, ' ');
        result = result.replace(/\s*-\s*-\s*/g, ' - ');
        result = result.replace(/\/\s+/g, '/');
        result = result.replace(/\s+\//g, '/');
        result = result.replace(/^\s+|\s+$/g, '');
        return result;
    };
    const requestedQuality = (data) => data?.settings?.quality ?? data?.quality;
    const MAX_CONCURRENT_DOWNLOADS = 4;
    const downloadConcurrency = (data) => {
        const asked = Number(data?.settings?.concurrency ?? conf.get('concurrency', 1));
        if (!Number.isFinite(asked) || asked < 1)
            return 1;
        return Math.min(Math.round(asked), MAX_CONCURRENT_DOWNLOADS);
    };
    const downloadQobuzTracks = async (parsedData, data, socket) => {
        socket.emit('directUrlDownloadStart', {
            tracks: parsedData.tracks,
            contentType: parsedData.linktype || 'track',
            trackCount: parsedData.tracks.length,
        });
        console.log(`🎵 Starting Qobuz download of ${parsedData.tracks.length} tracks...`);
        const savedFiles = [];
        const m3u8 = [];
        const coverSizes = conf.get('coverSize');
        const qobuzDownloadCover = conf.get('qobuzDownloadCover', false);
        const qobuzJobId = String(data.itemId ?? 'url-download');
        const qobuzJob = (0, download_cancellation_1.beginJob)(qobuzJobId);
        for (let i = 0; i < parsedData.tracks.length; i++) {
            if (qobuzJob.cancelled)
                break;
            const track = parsedData.tracks[i];
            socket.emit('downloadProgress', {
                percentage: ((i + 1) / parsedData.tracks.length) * 100,
                currentTrack: track.title,
                current: i + 1,
                total: parsedData.tracks.length,
                itemId: data.itemId ?? 'url-download',
                itemStatus: 'downloading',
                itemProgress: Math.round(((i + 1) / parsedData.tracks.length) * 100),
            });
            try {
                const basePath = data.settings.qobuzPath || conf.get('paths.qobuz') || './Music/Qobuz';
                let layoutPath;
                const qobuzKey = layoutKeyFor(parsedData.linktype, 'qobuz');
                if (parsedData.linktype === 'qobuz-playlist' || parsedData.linktype === 'spotify-playlist') {
                    layoutPath = conf.get('saveLayout')['qobuz-playlist'] || 'Playlist/{list_title}/{title}';
                }
                else {
                    layoutPath = conf.get('saveLayout')[qobuzKey] || '{album.title}/{title}';
                }
                const wantsNoNumbers = layoutPath.includes('{no_track_number}');
                if (parsedData.linktype === 'qobuz-playlist' || parsedData.linktype === 'spotify-playlist') {
                    layoutPath = substituteQobuzPlaylistVariables(layoutPath, track, parsedData);
                }
                const fullPath = (0, path_1.join)(basePath, layoutPath);
                const savedPath = await qobuzDownloadTrack({
                    track,
                    quality: requestedQuality(data),
                    metadata: conf.get('metadataCustom') === true
                        ? (0, metadata_options_1.metadataSettingsFrom)(conf.get('metadata')).qobuz
                        : metadata_options_1.DEFAULT_METADATA_OPTIONS,
                    info: parsedData.info,
                    coverSizes,
                    path: fullPath,
                    totalTracks: parsedData.tracks.length,
                    message: `(${i + 1}/${parsedData.tracks.length})`,
                    album: track.album,
                    qobuzDownloadCover,
                    listTitle: parsedData.linkinfo?.title || parsedData.linkinfo?.name || 'Downloaded Content',
                    trackNumber: !wantsNoNumbers,
                });
                if (savedPath) {
                    savedFiles.push(savedPath);
                    m3u8.push((0, path_1.resolve)(process.env.SIMULATE ? savedPath : trueCasePathSync(savedPath)));
                    console.log(`✅ Downloaded: ${track.title}`);
                }
            }
            catch (trackError) {
                console.error(`❌ Error downloading ${track.title}: ${trackError.message}`);
            }
        }
        (0, download_cancellation_1.endJob)(qobuzJobId);
        if (qobuzJob.cancelled) {
            console.log(`🚫 Cancelled: kept ${savedFiles.length} finished track(s)`);
            socket.emit('downloadProgress', {
                itemId: qobuzJobId,
                itemStatus: 'cancelled',
                current: savedFiles.length,
                total: parsedData.tracks.length,
                savedCount: savedFiles.length,
            });
            return;
        }
        await createPlaylistFile(savedFiles, m3u8, parsedData, data, socket);
        socket.emit('downloadProgress', {
            itemId: data.itemId ?? 'url-download',
            itemStatus: 'completed',
            itemProgress: 100,
            current: savedFiles.length,
            total: parsedData.tracks.length,
            folder: savedFiles.length > 0 ? (0, path_1.dirname)(savedFiles[0]) : undefined,
            savedCount: savedFiles.length,
        });
        socket.emit('downloadComplete', {
            itemId: data.itemId ?? 'url-download',
            count: savedFiles.length,
            files: savedFiles,
            playlistCreated: m3u8.length > 1,
        });
        console.log(`🎉 Qobuz download complete! ${savedFiles.length} files saved.`);
    };
    const downloadDeezerTracks = async (parsedData, data, socket) => {
        socket.emit('directUrlDownloadStart', {
            tracks: parsedData.tracks,
            contentType: parsedData.linktype || 'track',
            trackCount: parsedData.tracks.length,
        });
        console.log(`🎵 Starting Deezer download of ${parsedData.tracks.length} tracks...`);
        const savedFiles = [];
        const m3u8 = [];
        const coverSizes = conf.get('coverSize');
        const total = parsedData.tracks.length;
        const landed = new Array(total).fill(null);
        let finished = 0;
        const jobId = String(data.itemId ?? 'url-download');
        const job = (0, download_cancellation_1.beginJob)(jobId, data);
        const stopper = new AbortController();
        job.abort = () => stopper.abort();
        const queue = new p_queue_1.default({ concurrency: downloadConcurrency(data) });
        await queue.addAll(parsedData.tracks.map((track, i) => async () => {
            if (job.cancelled || job.paused)
                return;
            socket.emit('downloadProgress', {
                percentage: (finished / total) * 100,
                currentTrack: track.SNG_TITLE,
                current: Math.min(finished + 1, total),
                total,
                itemId: data.itemId ?? 'url-download',
                itemStatus: 'downloading',
                itemProgress: Math.round((finished / total) * 100),
            });
            try {
                const basePath = data.settings.deezerPath || conf.get('paths.deezer') || './Music/Deezer';
                const deezerKey = layoutKeyFor(parsedData.linktype, 'deezer');
                const layoutPath = deezerKey === 'playlist'
                    ? conf.get('saveLayout')['playlist'] || 'Playlist/{TITLE}/{SNG_TITLE}'
                    : conf.get('saveLayout')[deezerKey] || '{ALB_TITLE}/{SNG_TITLE}';
                const fullPath = (0, path_1.join)(basePath, layoutPath);
                const savedPath = await deezerDownloadTrack({
                    track,
                    quality: requestedQuality(data),
                    info: parsedData.linkinfo || {},
                    coverSizes,
                    path: fullPath,
                    totalTracks: parsedData.tracks.length,
                    trackNumber: conf.get('trackNumber', true),
                    fallbackTrack: conf.get('fallbackTrack', true),
                    fallbackQuality: conf.get('fallbackQuality', true),
                    message: `(${i + 1}/${total})`,
                    metadata: conf.get('metadataCustom') === true
                        ? (0, metadata_options_1.metadataSettingsFrom)(conf.get('metadata')).deezer
                        : metadata_options_1.DEFAULT_METADATA_OPTIONS,
                    abortSignal: stopper.signal,
                    onPartialFile: (file) => job.partials.add(file),
                });
                if (savedPath) {
                    landed[i] = {
                        savedPath,
                        listed: (0, path_1.resolve)(process.env.SIMULATE ? savedPath : trueCasePathSync(savedPath)),
                    };
                    console.log(`✅ Downloaded: ${track.SNG_TITLE}`);
                }
            }
            catch (trackError) {
                console.error(`❌ Error downloading ${track.SNG_TITLE}: ${trackError.message}`);
            }
            finally {
                finished += 1;
                socket.emit('downloadProgress', {
                    percentage: (finished / total) * 100,
                    currentTrack: track.SNG_TITLE,
                    current: finished,
                    total,
                    itemId: data.itemId ?? 'url-download',
                    itemStatus: 'downloading',
                    itemProgress: Math.round((finished / total) * 100),
                });
            }
        }));
        if (job.paused) {
            const done = landed.filter(Boolean).length;
            console.log(`⏸ Paused: ${done} of ${total} track(s) finished, ${job.partials.size} part-file(s) kept`);
            socket.emit('downloadProgress', {
                itemId: jobId,
                itemStatus: 'paused',
                current: done,
                total,
                savedCount: done,
            });
            return;
        }
        (0, download_cancellation_1.endJob)(jobId);
        if (job.cancelled) {
            const removed = (0, download_cancellation_1.discardPartials)(job);
            const kept = landed.filter(Boolean).length;
            console.log(`🚫 Cancelled: kept ${kept} finished track(s), removed ${removed} partial file(s)`);
            socket.emit('downloadProgress', {
                itemId: jobId,
                itemStatus: 'cancelled',
                current: kept,
                total,
                savedCount: kept,
            });
            return;
        }
        for (const entry of landed) {
            if (!entry)
                continue;
            savedFiles.push(entry.savedPath);
            m3u8.push(entry.listed);
        }
        await createPlaylistFile(savedFiles, m3u8, parsedData, data, socket);
        socket.emit('downloadProgress', {
            itemId: data.itemId ?? 'url-download',
            itemStatus: 'completed',
            itemProgress: 100,
            current: savedFiles.length,
            total: parsedData.tracks.length,
            folder: savedFiles.length > 0 ? (0, path_1.dirname)(savedFiles[0]) : undefined,
            savedCount: savedFiles.length,
        });
        socket.emit('downloadComplete', {
            itemId: data.itemId ?? 'url-download',
            count: savedFiles.length,
            files: savedFiles,
            playlistCreated: m3u8.length > 1,
        });
        console.log(`🎉 Deezer download complete! ${savedFiles.length} files saved.`);
    };
    return { downloadQobuzTracks, downloadDeezerTracks, createPlaylistFile };
};
exports.createWebDownloads = createWebDownloads;
