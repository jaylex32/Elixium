"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerDirectDownloadSocketHandler = void 0;
const path_1 = require("path");
const download_cancellation_1 = require("./download-cancellation");
const registerDirectDownloadSocketHandler = ({ socket, parseToQobuz, parseDeezerUrl, ensureQobuzSearchReady, ensureQobuzDownloadReady, ensureDeezerDownloadReady, shouldUseVariousArtists, downloadQobuzTracks, downloadDeezerTracks, resolveYtMusicUrl, downloadYtMusicTrack, matchYtMusicTracks, matchIntoYtMusic, createPlaylistFile, }) => {
    const runDirectDownload = async (data) => {
        try {
            let parsedData;
            const emitConversionProgress = (progress) => {
                const total = progress.total && progress.total > 0 ? progress.total : 100;
                const percentage = progress.percentage !== undefined
                    ? Math.max(0, Math.min(100, progress.percentage))
                    : progress.current !== undefined
                        ? Math.max(0, Math.min(100, Math.round((progress.current / total) * 100)))
                        : 0;
                const current = progress.current !== undefined
                    ? progress.current
                    : progress.percentage !== undefined
                        ? Math.round((percentage / 100) * total)
                        : 0;
                socket.emit('directUrlConversionProgress', {
                    itemId: data.itemId,
                    phase: progress.phase,
                    message: progress.message,
                    current,
                    total,
                    percentage,
                });
                socket.emit('downloadProgress', {
                    percentage,
                    current,
                    total,
                    currentTrack: progress.message,
                    itemId: data.itemId ?? 'url-conversion',
                    itemStatus: 'downloading',
                    itemProgress: percentage,
                });
            };
            const reportUnmatched = (parsed) => {
                const unmatched = Array.isArray(parsed?.unmatched) ? parsed.unmatched : [];
                if (unmatched.length === 0)
                    return;
                socket.emit('conversionReport', {
                    itemId: data.itemId,
                    matched: parsed?.tracks?.length ?? 0,
                    unmatched,
                });
            };
            console.log('🚀 Direct URL download started');
            console.log('📄 URL:', data.url);
            console.log('🎵 Selected service:', data.service);
            const foreignLink = !data.url.includes('youtube.com') && !data.url.includes('youtu.be');
            if (data.service === 'ytmusic' && foreignLink && matchIntoYtMusic && downloadYtMusicTrack) {
                emitConversionProgress({ phase: 'auth', message: 'Reading the link...' });
                let source;
                if (data.url.includes('qobuz.com') || data.url.includes('tidal.com')) {
                    await ensureQobuzSearchReady();
                    source = await parseToQobuz(data.url, emitConversionProgress);
                }
                else {
                    source = await parseDeezerUrl(data.url);
                }
                const sources = (source?.tracks ?? []).map((track) => ({
                    title: String(track?.SNG_TITLE ?? track?.title ?? ''),
                    artist: String(track?.ART_NAME ?? track?.performer?.name ?? track?.artist?.name ?? ''),
                    durationSeconds: Number(track?.DURATION ?? track?.duration ?? 0) || null,
                }));
                if (sources.length === 0)
                    throw new Error('Nothing to convert at that link');
                emitConversionProgress({
                    phase: 'matching',
                    message: `Finding ${sources.length} track(s) on YouTube Music...`,
                });
                const matched = await matchIntoYtMusic(sources);
                const found = matched.filter((entry) => entry.match);
                if (found.length === 0) {
                    throw new Error(`None of the ${sources.length} track(s) could be found on YouTube Music`);
                }
                reportUnmatched({
                    tracks: found,
                    unmatched: matched
                        .filter((entry) => !entry.match)
                        .map((entry) => ({ title: entry.source.title, artist: entry.source.artist, reason: entry.reason })),
                });
                socket.emit('directUrlDownloadStart', {
                    tracks: found.map((entry) => entry.match),
                    contentType: 'ytmusic-playlist',
                    trackCount: found.length,
                });
                const saved = [];
                for (let i = 0; i < found.length; i += 1) {
                    const track = found[i].match;
                    socket.emit('downloadProgress', {
                        percentage: ((i + 1) / found.length) * 100,
                        currentTrack: track.title,
                        current: i + 1,
                        total: found.length,
                        itemId: data.itemId ?? 'url-download',
                        itemStatus: 'downloading',
                        itemProgress: Math.round(((i + 1) / found.length) * 100),
                    });
                    try {
                        const result = await downloadYtMusicTrack(track.rawData?.videoId ?? track.id, {
                            title: track.title,
                            artist: track.artist,
                            album: track.album,
                            albumArtist: track.artist,
                            year: track.year ?? null,
                            trackNumber: i + 1,
                            trackTotal: found.length,
                            coverUrl: track.rawData?.cover,
                            musicVideoType: track.rawData?.musicVideoType,
                            comment: `Converted from ${data.url}`,
                        });
                        saved.push(result.path);
                    }
                    catch (error) {
                        console.log(`ytmusic: ${track.title} failed — ${error?.message ?? error}`);
                    }
                }
                const kind = String(source?.linktype ?? '')
                    .split('-')
                    .pop() || 'playlist';
                await createPlaylistFile?.(saved, saved.map((file) => (0, path_1.resolve)(file)), { linktype: `ytmusic-${kind}`, linkinfo: source?.linkinfo ?? {} }, data, socket);
                socket.emit('downloadComplete', {
                    itemId: data.itemId ?? 'url-download',
                    count: saved.length,
                    files: saved,
                    playlistCreated: saved.length > 1,
                });
                console.log(`🎉 Converted to YouTube Music: ${saved.length} files saved.`);
                return;
            }
            if (data.url.includes('spotify.com') ||
                data.url.includes('open.spotify.com') ||
                data.url.startsWith('spotify:')) {
                console.log(`🎵 Converting Spotify to ${data.service.toUpperCase()}...`);
                emitConversionProgress({
                    phase: 'auth',
                    message: `Starting Spotify to ${data.service.toUpperCase()} conversion...`,
                    percentage: 2,
                    current: 2,
                    total: 100,
                });
                if (data.service === 'qobuz') {
                    await ensureQobuzSearchReady();
                    parsedData = await parseToQobuz(data.url, emitConversionProgress);
                    emitConversionProgress({
                        phase: 'matching',
                        message: `Conversion ready. ${parsedData?.tracks?.length || 0} tracks will be downloaded.`,
                        percentage: 100,
                        current: 100,
                        total: 100,
                    });
                    await ensureQobuzDownloadReady();
                    reportUnmatched(parsedData);
                    await downloadQobuzTracks(parsedData, data, socket);
                }
                else if (data.service === 'deezer') {
                    await ensureDeezerDownloadReady();
                    parsedData = await parseDeezerUrl(data.url);
                    if (!parsedData?.tracks || parsedData.tracks.length === 0) {
                        throw new Error('No matching tracks found for the provided Spotify playlist');
                    }
                    const useVariousArtists = shouldUseVariousArtists(data.settings);
                    if (!useVariousArtists && parsedData.linkinfo?.ART_NAME === 'Various Artists') {
                        delete parsedData.linkinfo.ART_NAME;
                    }
                    reportUnmatched(parsedData);
                    await downloadDeezerTracks(parsedData, data, socket);
                }
            }
            else if (data.url.includes('deezer.com')) {
                console.log('🎵 Processing Deezer URL...');
                if (data.service === 'qobuz') {
                    await ensureQobuzSearchReady();
                    parsedData = await parseToQobuz(data.url, emitConversionProgress);
                    await ensureQobuzDownloadReady();
                    reportUnmatched(parsedData);
                    await downloadQobuzTracks(parsedData, data, socket);
                }
                else {
                    parsedData = await parseDeezerUrl(data.url);
                    await ensureDeezerDownloadReady();
                    reportUnmatched(parsedData);
                    await downloadDeezerTracks(parsedData, data, socket);
                }
            }
            else if (data.url.includes('tidal.com')) {
                if (data.service !== 'qobuz') {
                    throw new Error('TIDAL URL conversion is currently supported only for Qobuz downloads.');
                }
                console.log('🎵 Converting TIDAL to QOBUZ...');
                await ensureQobuzSearchReady();
                parsedData = await parseToQobuz(data.url, emitConversionProgress);
                await ensureQobuzDownloadReady();
                reportUnmatched(parsedData);
                await downloadQobuzTracks(parsedData, data, socket);
            }
            else if (data.url.includes('youtube.com') || data.url.includes('youtu.be')) {
                if ((data.service === 'deezer' || data.service === 'qobuz') && resolveYtMusicUrl && matchYtMusicTracks) {
                    const resolved = await resolveYtMusicUrl(data.url);
                    if (!resolved || resolved.tracks.length === 0) {
                        throw new Error('YouTube Music found nothing at that link');
                    }
                    emitConversionProgress({
                        phase: 'matching',
                        message: `Finding ${resolved.tracks.length} track(s) on ${data.service.toUpperCase()}...`,
                    });
                    const matched = await matchYtMusicTracks(resolved.tracks, data.service);
                    const found = matched.filter((entry) => entry.match);
                    const missing = matched.filter((entry) => !entry.match);
                    if (found.length === 0) {
                        throw new Error(`None of the ${resolved.tracks.length} track(s) could be found on ${data.service.toUpperCase()}`);
                    }
                    const converted = {
                        tracks: found.map((entry) => entry.match.rawData),
                        linktype: `${data.service}-${resolved.kind}`,
                        linkinfo: { title: resolved.title, artist: { name: resolved.tracks[0]?.artist ?? '' } },
                        unmatched: missing.map((entry) => ({
                            title: entry.source?.title ?? '',
                            artist: entry.source?.artist ?? '',
                            reason: entry.reason,
                        })),
                    };
                    reportUnmatched(converted);
                    if (data.service === 'qobuz') {
                        await ensureQobuzDownloadReady();
                        await downloadQobuzTracks(converted, data, socket);
                    }
                    else {
                        await ensureDeezerDownloadReady();
                        await downloadDeezerTracks(converted, data, socket);
                    }
                    return;
                }
                if (resolveYtMusicUrl && downloadYtMusicTrack) {
                    const resolved = await resolveYtMusicUrl(data.url);
                    if (!resolved || resolved.tracks.length === 0) {
                        throw new Error('YouTube Music found nothing at that link');
                    }
                    socket.emit('directUrlDownloadStart', {
                        tracks: resolved.tracks,
                        contentType: `ytmusic-${resolved.kind}`,
                        trackCount: resolved.tracks.length,
                    });
                    const saved = [];
                    for (let i = 0; i < resolved.tracks.length; i += 1) {
                        const track = resolved.tracks[i];
                        socket.emit('downloadProgress', {
                            percentage: ((i + 1) / resolved.tracks.length) * 100,
                            currentTrack: track.title,
                            current: i + 1,
                            total: resolved.tracks.length,
                            itemId: data.itemId ?? 'url-download',
                            itemStatus: 'downloading',
                            itemProgress: Math.round(((i + 1) / resolved.tracks.length) * 100),
                        });
                        try {
                            const result = await downloadYtMusicTrack(track.rawData?.videoId ?? track.id, {
                                title: track.title,
                                artist: track.artist,
                                album: track.album || resolved.title,
                                albumArtist: track.artist,
                                year: track.year ?? null,
                                trackNumber: i + 1,
                                trackTotal: resolved.tracks.length,
                                coverUrl: track.rawData?.cover,
                                musicVideoType: track.rawData?.musicVideoType,
                                comment: `YouTube Music · ${data.url}`,
                            });
                            saved.push(result.path);
                        }
                        catch (error) {
                            console.log(`ytmusic: ${track.title} failed — ${error?.message ?? error}`);
                        }
                    }
                    await createPlaylistFile?.(saved, saved.map((file) => (0, path_1.resolve)(file)), { linktype: `ytmusic-${resolved.kind}`, linkinfo: { title: resolved.title } }, data, socket);
                    socket.emit('downloadComplete', {
                        itemId: data.itemId ?? 'url-download',
                        count: saved.length,
                        files: saved,
                        playlistCreated: saved.length > 1,
                    });
                    console.log(`🎉 YouTube Music download complete! ${saved.length} files saved.`);
                    return;
                }
                if (data.service !== 'qobuz') {
                    throw new Error('YouTube URL conversion is currently supported only for Qobuz downloads.');
                }
                console.log('🎵 Converting YouTube to QOBUZ...');
                await ensureQobuzSearchReady();
                parsedData = await parseToQobuz(data.url, emitConversionProgress);
                await ensureQobuzDownloadReady();
                reportUnmatched(parsedData);
                await downloadQobuzTracks(parsedData, data, socket);
            }
            else if (data.url.includes('qobuz.com') || data.url.includes('play.qobuz.com')) {
                console.log('🎵 Processing Qobuz URL...');
                await ensureQobuzSearchReady();
                parsedData = await parseToQobuz(data.url, emitConversionProgress);
                await ensureQobuzDownloadReady();
                reportUnmatched(parsedData);
                await downloadQobuzTracks(parsedData, data, socket);
            }
            else {
                throw new Error('Unsupported URL format');
            }
        }
        catch (error) {
            console.error('❌ Direct URL download error:', error);
            socket.emit('directUrlDownloadError', { message: error.message });
        }
    };
    socket.on('directUrlDownload', runDirectDownload);
    socket.on('pauseDownload', (data) => {
        const id = String(data?.id ?? '');
        if ((0, download_cancellation_1.pauseJob)(id))
            return;
        socket.emit('directUrlDownloadError', { itemId: id, message: 'That download is not running' });
    });
    socket.on('resumeDownload', (data) => {
        const id = String(data?.id ?? '');
        const request = (0, download_cancellation_1.resumableRequest)(id);
        if (!request) {
            socket.emit('directUrlDownloadError', { itemId: id, message: 'That download cannot be resumed' });
            return;
        }
        void runDirectDownload(request);
    });
};
exports.registerDirectDownloadSocketHandler = registerDirectDownloadSocketHandler;
