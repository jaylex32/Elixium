"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.applySettings = exports.SECRET_SETTING_PATHS = exports.readRedactedSettings = exports.readSettings = void 0;
const cover_art_1 = require("../../lib/cover-art");
const quality_profile_1 = require("../quality-profile");
const SECRET_PATHS = ['cookies.arl', 'cookies.sp_dc', 'qobuz.token', 'qobuz.secrets'];
const readSettings = (conf) => ({
    concurrency: conf.get('concurrency'),
    trackNumber: conf.get('trackNumber'),
    fallbackTrack: conf.get('fallbackTrack'),
    fallbackQuality: conf.get('fallbackQuality'),
    deezerDownloadCover: conf.get('deezerDownloadCover'),
    qobuzDownloadCover: conf.get('qobuzDownloadCover'),
    embedLyrics: conf.get('embedLyrics') !== false,
    saveLrcFile: Boolean(conf.get('saveLrcFile')),
    createPlaylist: conf.get('playlist.createPlaylist'),
    cookies: {
        arl: conf.get('cookies.arl'),
        sp_dc: conf.get('cookies.sp_dc'),
    },
    qobuz: {
        app_id: conf.get('qobuz.app_id'),
        secrets: conf.get('qobuz.secrets'),
        token: conf.get('qobuz.token'),
    },
    saveLayout: conf.get('saveLayout'),
    coverSize: (0, cover_art_1.resolveCoverSize)(conf.get('coverSize')),
    playlist: conf.get('playlist'),
    paths: {
        deezer: conf.get('paths.deezer') || './Music/Deezer',
        qobuz: conf.get('paths.qobuz') || './Music/Qobuz',
        ytmusic: conf.get('paths.ytmusic') || './Music/YouTube Music',
    },
    quality: {
        deezer: conf.get('quality.deezer') || '320',
        qobuz: conf.get('quality.qobuz') || '44khz',
        ytmusic: conf.get('quality.ytmusic') || 'aac',
    },
    auth: {
        enabled: conf.get('auth.enabled') !== false,
        allowedOrigins: Array.isArray(conf.get('auth.allowedOrigins')) ? conf.get('auth.allowedOrigins') : [],
    },
    qualityProfile: (0, quality_profile_1.readQualityProfile)(conf),
});
exports.readSettings = readSettings;
const readRedactedSettings = (conf) => {
    const settings = (0, exports.readSettings)(conf);
    const present = (value) => Boolean(value && String(value).trim());
    return {
        ...settings,
        cookies: { arl: present(settings.cookies.arl), sp_dc: present(settings.cookies.sp_dc) },
        qobuz: {
            app_id: settings.qobuz.app_id,
            secrets: present(settings.qobuz.secrets),
            token: present(settings.qobuz.token),
        },
        configured: {
            deezer: present(settings.cookies.arl),
            qobuz: present(settings.qobuz.token) && present(settings.qobuz.app_id),
            spotify: present(settings.cookies.sp_dc),
        },
    };
};
exports.readRedactedSettings = readRedactedSettings;
exports.SECRET_SETTING_PATHS = SECRET_PATHS;
const isCredentialUpdate = (value) => value !== undefined && value !== null && typeof value !== 'boolean';
const applySettings = (conf, data, hooks) => {
    const changed = [];
    if (!data || typeof data !== 'object')
        return changed;
    const setIfPresent = (key, value, path = key) => {
        if (value === undefined)
            return;
        conf.set(path, value);
        changed.push(path);
    };
    if (data.concurrency !== undefined && data.concurrency !== null) {
        const concurrency = Number(data.concurrency);
        if (Number.isFinite(concurrency) && concurrency > 0) {
            conf.set('concurrency', concurrency);
            hooks.setConcurrency?.(concurrency);
            changed.push('concurrency');
        }
    }
    setIfPresent('trackNumber', data.trackNumber);
    setIfPresent('fallbackTrack', data.fallbackTrack);
    setIfPresent('fallbackQuality', data.fallbackQuality);
    setIfPresent('deezerDownloadCover', data.deezerDownloadCover);
    setIfPresent('qobuzDownloadCover', data.qobuzDownloadCover);
    setIfPresent('embedLyrics', data.embedLyrics);
    setIfPresent('saveLrcFile', data.saveLrcFile);
    setIfPresent('saveLayout', data.saveLayout);
    if (data.coverSize !== undefined && data.coverSize !== null) {
        const scalar = Number(data.coverSize);
        if (Number.isFinite(scalar) && scalar > 0) {
            conf.set('coverSize', { '128': scalar, '320': scalar, flac: scalar });
            changed.push('coverSize');
        }
        else if (typeof data.coverSize === 'object') {
            conf.set('coverSize', data.coverSize);
            changed.push('coverSize');
        }
    }
    setIfPresent('createPlaylist', data.createPlaylist, 'playlist.createPlaylist');
    if (data.cookies) {
        if (isCredentialUpdate(data.cookies.arl)) {
            conf.set('cookies.arl', String(data.cookies.arl).trim());
            hooks.setIsDeezerDownloadReady(false);
            changed.push('cookies.arl');
        }
        if (isCredentialUpdate(data.cookies.sp_dc)) {
            conf.set('cookies.sp_dc', String(data.cookies.sp_dc).trim());
            changed.push('cookies.sp_dc');
        }
    }
    if (data.qobuz) {
        if (isCredentialUpdate(data.qobuz.token)) {
            conf.set('qobuz.token', String(data.qobuz.token).trim());
            hooks.setIsQobuzDownloadReady(false);
            changed.push('qobuz.token');
        }
        if (data.qobuz.app_id !== undefined && data.qobuz.app_id !== null && String(data.qobuz.app_id).trim() !== '') {
            const appId = Number(data.qobuz.app_id);
            conf.set('qobuz.app_id', Number.isNaN(appId) ? data.qobuz.app_id : appId);
            hooks.setIsQobuzInitialized(false);
            hooks.setIsQobuzDownloadReady(false);
            changed.push('qobuz.app_id');
        }
        if (data.qobuz.secrets !== undefined) {
            conf.set('qobuz.secrets', String(data.qobuz.secrets || '').trim());
            hooks.setIsQobuzInitialized(false);
            hooks.setIsQobuzDownloadReady(false);
            changed.push('qobuz.secrets');
        }
    }
    if (data.auth && typeof data.auth === 'object') {
        if (typeof data.auth.enabled === 'boolean') {
            conf.set('auth.enabled', data.auth.enabled);
            changed.push('auth.enabled');
        }
        if (Array.isArray(data.auth.allowedOrigins)) {
            const origins = data.auth.allowedOrigins
                .filter((entry) => typeof entry === 'string')
                .map((entry) => entry.trim().replace(/\/+$/, ''))
                .filter((entry) => entry.length > 0);
            conf.set('auth.allowedOrigins', origins);
            changed.push('auth.allowedOrigins');
        }
    }
    if (data.qualityProfile && typeof data.qualityProfile === 'object') {
        (0, quality_profile_1.writeQualityProfile)(conf, data.qualityProfile);
        changed.push('qualityProfile');
    }
    if (data.paths) {
        conf.set('paths', data.paths);
        changed.push('paths');
    }
    if (data.quality) {
        if (data.quality.ytmusic) {
            conf.set('quality.ytmusic', data.quality.ytmusic);
            changed.push('quality.ytmusic');
        }
        if (data.quality.deezer) {
            conf.set('quality.deezer', data.quality.deezer);
            changed.push('quality.deezer');
        }
        if (data.quality.qobuz) {
            conf.set('quality.qobuz', data.quality.qobuz);
            changed.push('quality.qobuz');
        }
    }
    return changed;
};
exports.applySettings = applySettings;
