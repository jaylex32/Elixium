"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerOperationsSocketHandlers = void 0;
const download_cancellation_1 = require("./download-cancellation");
const metadata_options_1 = require("../lib/metadata-options");
const registerOperationsSocketHandlers = ({ socket, conf, queue, signale, normalizeQuality, startDownloadProcess, getCurrentDownloadQueue, activeDownloads, getIsDownloading, setIsDeezerDownloadReady, setIsQobuzInitialized, setIsQobuzDownloadReady, }) => {
    socket.on('getSettings', () => {
        try {
            const configAny = conf;
            const settings = {
                concurrency: conf.get('concurrency'),
                trackNumber: conf.get('trackNumber'),
                fallbackTrack: conf.get('fallbackTrack'),
                fallbackQuality: conf.get('fallbackQuality'),
                deezerDownloadCover: conf.get('deezerDownloadCover'),
                qobuzDownloadCover: conf.get('qobuzDownloadCover'),
                embedLyrics: conf.get('embedLyrics') !== false,
                saveLrcFile: Boolean(conf.get('saveLrcFile')),
                createPlaylist: configAny.get('playlist.createPlaylist'),
                cookies: {
                    arl: conf.get('cookies.arl'),
                    sp_dc: configAny.get('cookies.sp_dc'),
                    spotifyClientId: configAny.get('cookies.spotifyClientId'),
                    spotifyClientSecret: configAny.get('cookies.spotifyClientSecret'),
                },
                qobuz: {
                    app_id: conf.get('qobuz.app_id'),
                    secrets: conf.get('qobuz.secrets'),
                    token: conf.get('qobuz.token'),
                },
                metadata: (0, metadata_options_1.metadataSettingsFrom)(configAny.get('metadata')),
                metadataCustom: configAny.get('metadataCustom') === true,
                ytmusic: {
                    cookie: configAny.get('ytmusic.cookie'),
                    preferAlbumAudio: configAny.get('ytmusic.preferAlbumAudio') !== false,
                    strictAlbumAudio: configAny.get('ytmusic.strictAlbumAudio') === true,
                },
                saveLayout: conf.get('saveLayout'),
                coverSize: conf.get('coverSize'),
                playlist: configAny.get('playlist'),
                paths: {
                    deezer: configAny.get('paths.deezer') || './Music/Deezer',
                    qobuz: configAny.get('paths.qobuz') || './Music/Qobuz',
                    ytmusic: configAny.get('paths.ytmusic') || './Music/YouTube Music',
                },
                quality: {
                    deezer: configAny.get('quality.deezer') || '320',
                    qobuz: configAny.get('quality.qobuz') || '44khz',
                    ytmusic: configAny.get('quality.ytmusic') || 'aac',
                },
                services: {
                    deezer: configAny.get('services.deezer') !== false,
                    qobuz: configAny.get('services.qobuz') !== false,
                    ytmusic: configAny.get('services.ytmusic') !== false,
                },
            };
            socket.emit('settings', settings);
        }
        catch (error) {
            socket.emit('settingsError', { message: error.message });
        }
    });
    socket.on('saveSettings', (data) => {
        try {
            const configAny = conf;
            if (data.concurrency) {
                conf.set('concurrency', data.concurrency);
                queue.concurrency = data.concurrency;
            }
            if (data.trackNumber !== undefined) {
                conf.set('trackNumber', data.trackNumber);
            }
            if (data.fallbackTrack !== undefined) {
                conf.set('fallbackTrack', data.fallbackTrack);
            }
            if (data.fallbackQuality !== undefined) {
                conf.set('fallbackQuality', data.fallbackQuality);
            }
            if (data.deezerDownloadCover !== undefined) {
                conf.set('deezerDownloadCover', data.deezerDownloadCover);
            }
            if (data.qobuzDownloadCover !== undefined) {
                conf.set('qobuzDownloadCover', data.qobuzDownloadCover);
            }
            if (data.embedLyrics !== undefined) {
                conf.set('embedLyrics', data.embedLyrics);
            }
            if (data.saveLrcFile !== undefined) {
                conf.set('saveLrcFile', data.saveLrcFile);
            }
            if (data.createPlaylist !== undefined) {
                configAny.set('playlist.createPlaylist', data.createPlaylist);
            }
            if (data.cookies) {
                if (data.cookies.arl) {
                    conf.set('cookies.arl', data.cookies.arl);
                    setIsDeezerDownloadReady(false);
                }
                if (data.cookies.spotifyClientId !== undefined) {
                    configAny.set('cookies.spotifyClientId', data.cookies.spotifyClientId);
                }
                if (data.cookies.spotifyClientSecret !== undefined) {
                    configAny.set('cookies.spotifyClientSecret', data.cookies.spotifyClientSecret);
                }
                if (data.cookies.sp_dc) {
                    configAny.set('cookies.sp_dc', data.cookies.sp_dc);
                }
            }
            if (data.qobuz) {
                if (data.qobuz.token) {
                    conf.set('qobuz.token', data.qobuz.token);
                    setIsQobuzDownloadReady(false);
                }
                if (data.qobuz.app_id !== undefined && data.qobuz.app_id !== null && String(data.qobuz.app_id).trim() !== '') {
                    const appId = Number(data.qobuz.app_id);
                    conf.set('qobuz.app_id', isNaN(appId) ? data.qobuz.app_id : appId);
                    setIsQobuzInitialized(false);
                    setIsQobuzDownloadReady(false);
                }
                if (data.qobuz.secrets !== undefined) {
                    const s = String(data.qobuz.secrets || '').trim();
                    conf.set('qobuz.secrets', s);
                    setIsQobuzInitialized(false);
                    setIsQobuzDownloadReady(false);
                }
            }
            if (data.ytmusic && data.ytmusic.cookie !== undefined) {
                configAny.set('ytmusic.cookie', String(data.ytmusic.cookie || '').trim());
            }
            if (data.ytmusic && data.ytmusic.preferAlbumAudio !== undefined) {
                configAny.set('ytmusic.preferAlbumAudio', data.ytmusic.preferAlbumAudio === true);
            }
            if (data.ytmusic && data.ytmusic.strictAlbumAudio !== undefined) {
                configAny.set('ytmusic.strictAlbumAudio', data.ytmusic.strictAlbumAudio === true);
            }
            if (typeof data.metadataCustom === 'boolean') {
                configAny.set('metadataCustom', data.metadataCustom);
            }
            if (data.metadata && typeof data.metadata === 'object') {
                configAny.set('metadata', (0, metadata_options_1.metadataSettingsFrom)(data.metadata));
            }
            if (data.saveLayout) {
                conf.set('saveLayout', data.saveLayout);
            }
            if (data.coverSize) {
                conf.set('coverSize', data.coverSize);
            }
            if (data.paths) {
                configAny.set('paths', data.paths);
            }
            if (data.quality) {
                if (data.quality.deezer) {
                    configAny.set('quality.deezer', data.quality.deezer);
                }
                if (data.quality.qobuz) {
                    configAny.set('quality.qobuz', data.quality.qobuz);
                }
                if (data.quality.ytmusic) {
                    configAny.set('quality.ytmusic', data.quality.ytmusic);
                }
            }
            if (data.services && typeof data.services === 'object') {
                const wanted = {
                    deezer: data.services.deezer !== false,
                    qobuz: data.services.qobuz !== false,
                    ytmusic: data.services.ytmusic !== false,
                };
                if (wanted.deezer || wanted.qobuz || wanted.ytmusic) {
                    configAny.set('services', wanted);
                }
            }
            console.log(signale.success('Settings updated from web interface'));
            socket.emit('settingsSaved', { success: true });
        }
        catch (error) {
            socket.emit('settingsError', { message: error.message });
        }
    });
    socket.on('getQualitySettings', () => {
        try {
            const configAny = conf;
            const qualitySettings = {
                deezer: configAny.get('quality.deezer') || '320',
                qobuz: configAny.get('quality.qobuz') || '44khz',
            };
            socket.emit('qualitySettings', qualitySettings);
        }
        catch (error) {
            socket.emit('qualitySettingsError', { message: error.message });
        }
    });
    socket.on('saveQualitySettings', (data) => {
        try {
            const configAny = conf;
            if (data.deezer) {
                configAny.set('quality.deezer', data.deezer);
            }
            if (data.qobuz) {
                configAny.set('quality.qobuz', data.qobuz);
            }
            console.log(signale.success('Quality settings saved'));
            socket.emit('qualitySettingsSaved', { success: true });
        }
        catch (error) {
            socket.emit('qualitySettingsError', { message: error.message });
        }
    });
    socket.on('startDownload', async (data) => {
        try {
            const normalizedQuality = normalizeQuality(data.quality, data.service);
            await startDownloadProcess(data.queue, normalizedQuality, data.service, data.settings, socket);
        }
        catch (error) {
            socket.emit('downloadError', { message: error.message });
        }
    });
    socket.on('cancelDownload', (data) => {
        try {
            const id = String(data?.id ?? '');
            const item = activeDownloads.get(id);
            if (item) {
                item.status = 'cancelled';
                activeDownloads.delete(id);
            }
            const stopped = (0, download_cancellation_1.cancelJob)(id);
            if (item || stopped) {
                socket.emit('downloadProgress', { itemId: id, itemStatus: 'cancelled' });
            }
            else {
                socket.emit('downloadError', {
                    itemId: id,
                    message: 'That download had already finished',
                });
            }
        }
        catch (error) {
            socket.emit('downloadError', { message: error.message });
        }
    });
    socket.on('getDownloadStatus', (data) => {
        const currentDownloadQueue = getCurrentDownloadQueue();
        const isDownloading = getIsDownloading();
        socket.emit('downloadStatus', {
            isDownloading,
            activeDownloads: Array.from(activeDownloads.values()),
            queueLength: currentDownloadQueue.length,
        });
        if (data && data.queueItems && Array.isArray(data.queueItems)) {
            try {
                const currentDownloads = data.queueItems;
                const statusUpdates = [];
                currentDownloads.forEach((item) => {
                    let actualStatus = item.status || 'queued';
                    if (activeDownloads && activeDownloads.has(item.id)) {
                        actualStatus = 'downloading';
                    }
                    else if (currentDownloadQueue.some((queueItem) => queueItem.id === item.id)) {
                        actualStatus = 'queued';
                    }
                    else if (item.status === 'downloading' || item.status === 'queued') {
                        actualStatus = 'queued';
                    }
                    statusUpdates.push({
                        id: item.id,
                        status: actualStatus,
                        title: item.title,
                    });
                });
                socket.emit('downloadStatusUpdate', {
                    downloads: statusUpdates,
                    isDownloading,
                });
                console.log(`📊 Sent download status update for ${statusUpdates.length} items`);
            }
            catch (error) {
                console.error('Error processing queue items:', error);
            }
        }
    });
    socket.on('getActiveDownloads', () => {
        socket.emit('activeDownloads', getCurrentDownloadQueue());
    });
    socket.on('serviceChange', (data) => {
        console.log(`Client switched to ${data.service}`);
    });
    socket.on('disconnect', () => {
        console.log('Client disconnected:', socket.id);
    });
};
exports.registerOperationsSocketHandlers = registerOperationsSocketHandlers;
