"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerCatalogRoutes = void 0;
const respond_1 = require("../respond");
const url_parse_1 = require("../url-parse");
const quality_1 = require("../quality");
const SEARCH_TYPES = ['track', 'album', 'artist', 'playlist'];
const registerCatalogRoutes = ({ app, basePath, performDeezerSearch, performQobuzSearch, getDiscoveryContentRest, getItemTracksRest, getAvailableGenres, parseToQobuz, parseDeezerUrl, ensureQobuzSearchReady, }) => {
    app.get(`${basePath}/search`, (0, respond_1.route)(async (req, res) => {
        const service = (0, respond_1.parseService)(req.query.service);
        const query = (0, respond_1.requireString)(req.query.q ?? req.query.query, 'q');
        const type = String(req.query.type ?? 'track').toLowerCase();
        const { limit, offset } = (0, respond_1.parsePaging)(req.query, 50, 200);
        if (!SEARCH_TYPES.includes(type)) {
            throw respond_1.ApiError.badRequest(`Unsupported search type: ${type}`, { supported: SEARCH_TYPES });
        }
        const search = service === 'deezer' ? performDeezerSearch : performQobuzSearch;
        const results = await search(query, type, limit, offset);
        return (0, respond_1.sendData)(res, results, {
            service,
            type,
            query,
            limit,
            offset,
            count: results.length,
            hasMore: results.length === limit,
        });
    }));
    app.get(`${basePath}/discovery`, (0, respond_1.route)(async (req, res) => {
        const service = (0, respond_1.parseService)(req.query.service);
        const type = (0, respond_1.requireString)(req.query.type, 'type').toLowerCase();
        const { limit } = (0, respond_1.parsePaging)(req.query, 18, 100);
        const items = await getDiscoveryContentRest(service, type, limit);
        return (0, respond_1.sendData)(res, items, { service, type, limit, count: items.length });
    }));
    const expandItem = (itemType, defaultLimit) => (0, respond_1.route)(async (req, res) => {
        const service = (0, respond_1.parseService)(req.query.service);
        const id = (0, respond_1.requireString)(req.params.id, 'id');
        const { limit, offset } = (0, respond_1.parsePaging)(req.query, defaultLimit, 500);
        const { tracks, metadata } = await getItemTracksRest(service, itemType, id, limit, offset);
        return (0, respond_1.sendData)(res, { tracks, metadata }, { service, itemType, id, limit, offset, count: tracks?.length ?? 0 });
    });
    app.get(`${basePath}/albums/:id/tracks`, expandItem('album', 100));
    app.get(`${basePath}/playlists/:id/tracks`, expandItem('playlist', 200));
    app.get(`${basePath}/artists/:id/top-tracks`, expandItem('artist', 50));
    app.get(`${basePath}/items/:itemType/:id`, (0, respond_1.route)(async (req, res) => {
        const service = (0, respond_1.parseService)(req.query.service);
        const itemType = String(req.params.itemType || '').toLowerCase();
        const id = (0, respond_1.requireString)(req.params.id, 'id');
        const { limit, offset } = (0, respond_1.parsePaging)(req.query, 100, 500);
        if (!['album', 'artist', 'playlist'].includes(itemType)) {
            throw respond_1.ApiError.badRequest(`Unsupported item type: ${itemType}`, {
                supported: ['album', 'artist', 'playlist'],
            });
        }
        const { tracks, metadata } = await getItemTracksRest(service, itemType, id, limit, offset);
        return (0, respond_1.sendData)(res, { tracks, metadata }, { service, itemType, id, limit, offset, count: tracks?.length ?? 0 });
    }));
    app.post(`${basePath}/parse-url`, (0, respond_1.route)(async (req, res) => {
        const url = (0, respond_1.requireString)(req.body?.url, 'url');
        const preferred = typeof req.body?.service === 'string' ? req.body.service : undefined;
        const parsed = await (0, url_parse_1.parseMediaUrl)(url, preferred, { parseToQobuz, parseDeezerUrl, ensureQobuzSearchReady });
        return (0, respond_1.sendData)(res, parsed, parsed.metadata);
    }));
    app.get(`${basePath}/qualities`, (0, respond_1.route)(async (req, res) => {
        const service = (0, respond_1.parseService)(req.query.service);
        return (0, respond_1.sendData)(res, (0, quality_1.qualitiesFor)(service), { service });
    }));
    app.get(`${basePath}/genres`, (0, respond_1.route)(async (req, res) => {
        if (!getAvailableGenres) {
            throw new respond_1.ApiError('service_unavailable', 'Genre listing is not available on this server');
        }
        const genres = await getAvailableGenres();
        return (0, respond_1.sendData)(res, genres, { count: Array.isArray(genres) ? genres.length : 0 });
    }));
};
exports.registerCatalogRoutes = registerCatalogRoutes;
