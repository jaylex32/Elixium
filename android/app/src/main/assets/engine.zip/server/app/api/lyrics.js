"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.fetchLrclib = exports.parseLrc = void 0;
var lyrics_provider_1 = require("../../lib/lyrics-provider");
Object.defineProperty(exports, "parseLrc", { enumerable: true, get: function () { return lyrics_provider_1.parseLrc; } });
Object.defineProperty(exports, "fetchLrclib", { enumerable: true, get: function () { return lyrics_provider_1.fetchLrclib; } });
