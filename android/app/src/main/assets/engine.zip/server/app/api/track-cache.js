"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseRange = exports.trackBufferCache = exports.TrackBufferCache = void 0;
class TrackBufferCache {
    constructor({ maxBytes = 512 * 1024 * 1024, ttlMs = 10 * 60 * 1000 } = {}) {
        this.entries = new Map();
        this.totalBytes = 0;
        this.maxBytes = maxBytes;
        this.ttlMs = ttlMs;
    }
    isExpired(entry, now) {
        return this.ttlMs > 0 && now - entry.lastUsed > this.ttlMs;
    }
    get(key) {
        const entry = this.entries.get(key);
        if (!entry)
            return undefined;
        const now = Date.now();
        if (this.isExpired(entry, now)) {
            this.delete(key);
            return undefined;
        }
        entry.lastUsed = now;
        return { buffer: entry.buffer, contentType: entry.contentType };
    }
    set(key, buffer, contentType) {
        if (buffer.length > this.maxBytes)
            return;
        this.delete(key);
        this.entries.set(key, { key, buffer, contentType, lastUsed: Date.now() });
        this.totalBytes += buffer.length;
        this.evictUntilWithinBudget();
    }
    delete(key) {
        const entry = this.entries.get(key);
        if (!entry)
            return;
        this.totalBytes -= entry.buffer.length;
        this.entries.delete(key);
    }
    evictUntilWithinBudget() {
        if (this.totalBytes <= this.maxBytes)
            return;
        const now = Date.now();
        for (const entry of [...this.entries.values()]) {
            if (this.totalBytes <= this.maxBytes)
                break;
            if (this.isExpired(entry, now))
                this.delete(entry.key);
        }
        const byAge = [...this.entries.values()].sort((a, b) => a.lastUsed - b.lastUsed);
        for (const entry of byAge) {
            if (this.totalBytes <= this.maxBytes)
                break;
            this.delete(entry.key);
        }
    }
    stats() {
        return { entries: this.entries.size, bytes: this.totalBytes, maxBytes: this.maxBytes };
    }
}
exports.TrackBufferCache = TrackBufferCache;
exports.trackBufferCache = new TrackBufferCache();
const parseRange = (header, total) => {
    if (!header)
        return undefined;
    const match = /^bytes=(\d*)-(\d*)$/.exec(header.trim());
    if (!match)
        return undefined;
    const [, rawStart, rawEnd] = match;
    if (rawStart === '') {
        if (rawEnd === '')
            return undefined;
        const suffix = Number(rawEnd);
        if (!Number.isFinite(suffix) || suffix <= 0)
            return null;
        return { start: Math.max(0, total - suffix), end: total - 1 };
    }
    const start = Number(rawStart);
    if (!Number.isFinite(start) || start >= total)
        return null;
    const end = rawEnd === '' ? total - 1 : Math.min(total - 1, Number(rawEnd));
    if (!Number.isFinite(end) || end < start)
        return null;
    return { start, end };
};
exports.parseRange = parseRange;
