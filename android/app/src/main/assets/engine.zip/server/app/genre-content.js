"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createGenreContent = void 0;
const util_1 = require("../lib/util");
const API = 'https://api.deezer.com';
const CACHE_TTL_MS = 30 * 60 * 1000;
const THIN_TTL_MS = 60 * 1000;
const THIN_RESULT = 12;
const cache = new Map();
const RADIOS_PER_GENRE = 3;
const TRACKS_PER_RADIO = 100;
const PLAYLISTS_PER_GENRE = 4;
const TRACKS_PER_PLAYLIST = 100;
const coverOf = (item) => item?.cover_medium || item?.cover_big || item?.cover || item?.picture_medium || item?.picture_big || item?.picture;
const toYear = (value) => {
    if (typeof value !== 'string' || !value)
        return null;
    const parsed = new Date(value);
    return Number.isNaN(parsed.getTime()) ? null : parsed.getFullYear();
};
const trackResult = (track) => ({
    id: String(track.id),
    title: String(track.title || '') + (track.title_version ? ` ${track.title_version}` : ''),
    artist: track.artist?.name || 'Unknown Artist',
    album: track.album?.title || '',
    type: 'track',
    duration: (0, util_1.formatSecondsReadable)(Number(track.duration || 0)),
    rawData: track,
});
const albumResult = (album, artistName) => ({
    id: String(album.id),
    title: String(album.title || ''),
    artist: album.artist?.name || artistName || 'Unknown Artist',
    album: String(album.title || ''),
    type: 'album',
    duration: '',
    year: toYear(album.release_date),
    rawData: album,
});
const artistResult = (artist) => ({
    id: String(artist.id),
    title: String(artist.name || ''),
    artist: String(artist.name || ''),
    album: '',
    type: 'artist',
    duration: '',
    rawData: artist,
});
const playlistResult = (playlist) => ({
    id: String(playlist.id),
    title: String(playlist.title || ''),
    artist: playlist.user?.name || 'Deezer',
    album: '',
    type: 'playlist',
    duration: playlist.nb_tracks ? `${playlist.nb_tracks} tracks` : '',
    rawData: playlist,
});
const dedupe = (items) => {
    const seen = new Set();
    const out = [];
    for (const item of items) {
        if (seen.has(item.id))
            continue;
        seen.add(item.id);
        out.push(item);
    }
    return out;
};
const createGenreContent = ({ makeHttpRequest, qobuz, ensureQobuzSearchReady }) => {
    const radioTracks = async (genreId, attempt = 0) => {
        const radios = await makeHttpRequest(`${API}/genre/${encodeURIComponent(genreId)}/radios`).catch(() => null);
        const ids = (radios?.data || []).slice(0, RADIOS_PER_GENRE).map((radio) => radio.id);
        if (ids.length === 0)
            return [];
        const batches = await Promise.all(ids.map((id) => makeHttpRequest(`${API}/radio/${encodeURIComponent(String(id))}/tracks?limit=${TRACKS_PER_RADIO}`).catch(() => null)));
        const tracks = batches.flatMap((batch) => batch?.data || []);
        if (tracks.length === 0 && attempt === 0) {
            await new Promise((resolve) => setTimeout(resolve, 600));
            return radioTracks(genreId, 1);
        }
        return tracks;
    };
    const playlistTracks = async (genreId) => {
        const playlists = await makeHttpRequest(`${API}/chart/${encodeURIComponent(genreId)}/playlists?limit=${PLAYLISTS_PER_GENRE}`).catch(() => null);
        const ids = (playlists?.data || []).slice(0, PLAYLISTS_PER_GENRE).map((playlist) => playlist.id);
        if (ids.length === 0)
            return [];
        const batches = await Promise.all(ids.map((id) => makeHttpRequest(`${API}/playlist/${encodeURIComponent(String(id))}/tracks?limit=${TRACKS_PER_PLAYLIST}`).catch(() => null)));
        return batches.flatMap((batch) => batch?.data || []);
    };
    const depthTracks = async (genreId) => {
        const fromRadios = await radioTracks(genreId);
        if (fromRadios.length > 0)
            return fromRadios;
        return playlistTracks(genreId);
    };
    const buildDeezer = async (genreId, kind) => {
        if (kind === 'playlists') {
            const chart = await makeHttpRequest(`${API}/chart/${encodeURIComponent(genreId)}/playlists?limit=100`).catch(() => null);
            return dedupe((chart?.data || []).map(playlistResult));
        }
        if (kind === 'tracks') {
            const [chart, radio] = await Promise.all([
                makeHttpRequest(`${API}/chart/${encodeURIComponent(genreId)}/tracks?limit=100`).catch(() => null),
                depthTracks(genreId),
            ]);
            return dedupe([...(chart?.data || []).map(trackResult), ...radio.map(trackResult)]);
        }
        const [chartAlbums, selection, radio] = await Promise.all([
            makeHttpRequest(`${API}/chart/${encodeURIComponent(genreId)}/albums?limit=100`).catch(() => null),
            makeHttpRequest(`${API}/editorial/${encodeURIComponent(genreId)}/selection?limit=100`).catch(() => null),
            depthTracks(genreId),
        ]);
        const chartList = chartAlbums?.data || [];
        const selectionList = selection?.data || [];
        if (kind === 'albums') {
            const fromRadio = radio
                .filter((track) => track?.album?.id)
                .map((track) => albumResult(track.album, track.artist?.name));
            return dedupe([
                ...chartList.map((a) => albumResult(a)),
                ...selectionList.map((a) => albumResult(a)),
                ...fromRadio,
            ]);
        }
        const artists = [
            ...chartList.map((album) => album.artist).filter(Boolean),
            ...selectionList.map((album) => album.artist).filter(Boolean),
            ...radio.map((track) => track.artist).filter(Boolean),
        ];
        return dedupe(artists.filter((artist) => artist?.id).map(artistResult));
    };
    const QOBUZ_ALBUM_FEEDS = ['best-sellers', 'new-releases', 'editor-picks', 'press-awards'];
    const QOBUZ_PLAYLISTS_FOR_TRACKS = 4;
    const qobuzRequest = (endpoint, params) => qobuz.qobuzRequest?.(endpoint, params).catch(() => null);
    const qobuzGenreAlbums = async (genreId) => {
        const responses = await Promise.all(QOBUZ_ALBUM_FEEDS.map((type) => qobuzRequest('album/getFeatured', { type, genre_id: genreId, limit: 50, offset: 0 })));
        return responses.flatMap((response) => response?.albums?.items || []);
    };
    const qobuzGenrePlaylists = async (genreId) => {
        const response = await qobuzRequest('playlist/getFeatured', {
            type: 'editor-picks',
            genre_ids: genreId,
            limit: 50,
            offset: 0,
        });
        return response?.playlists?.items || [];
    };
    const buildQobuz = async (genreId, kind) => {
        await ensureQobuzSearchReady();
        if (kind === 'albums') {
            return dedupe((await qobuzGenreAlbums(genreId)).map((album) => ({
                id: String(album.id),
                title: String(album.title || ''),
                artist: album.artist?.name || 'Unknown Artist',
                album: String(album.title || ''),
                type: 'album',
                duration: album.tracks_count ? `${album.tracks_count} tracks` : '',
                year: toYear(album.release_date_original),
                maximum_bit_depth: album.maximum_bit_depth,
                maximum_sampling_rate: album.maximum_sampling_rate,
                hires: album.hires,
                rawData: album,
            })));
        }
        if (kind === 'artists') {
            return dedupe((await qobuzGenreAlbums(genreId))
                .map((album) => album?.artist)
                .filter((artist) => artist?.id)
                .map((artist) => ({
                id: String(artist.id),
                title: String(artist.name || ''),
                artist: String(artist.name || ''),
                album: '',
                type: 'artist',
                duration: '',
                rawData: artist,
            })));
        }
        const playlists = await qobuzGenrePlaylists(genreId);
        if (kind === 'playlists') {
            return dedupe(playlists.map((playlist) => ({
                id: String(playlist.id),
                title: String(playlist.name || ''),
                artist: playlist.owner?.name || 'Qobuz',
                album: '',
                type: 'playlist',
                duration: playlist.tracks_count ? `${playlist.tracks_count} tracks` : '',
                rawData: playlist,
            })));
        }
        const batches = await Promise.all(playlists
            .slice(0, QOBUZ_PLAYLISTS_FOR_TRACKS)
            .map((playlist) => qobuzRequest('playlist/get', { playlist_id: playlist.id, extra: 'tracks', limit: 100, offset: 0 })));
        return dedupe(batches
            .flatMap((batch) => batch?.tracks?.items || [])
            .map((track) => ({
            id: String(track.id),
            title: String(track.title || '') + (track.version ? ` (${track.version})` : ''),
            artist: track.performer?.name || track.album?.artist?.name || 'Unknown Artist',
            album: track.album?.title || '',
            type: 'track',
            duration: (0, util_1.formatSecondsReadable)(Number(track.duration || 0)),
            maximum_bit_depth: track.maximum_bit_depth,
            maximum_sampling_rate: track.maximum_sampling_rate,
            hires: track.hires,
            rawData: track,
        })));
    };
    const getGenreContent = async (service, genreId, kind, limit = 50, offset = 0) => {
        const key = `${service}:${genreId}:${kind}`;
        const cached = cache.get(key);
        const ttl = cached && cached.items.length <= THIN_RESULT ? THIN_TTL_MS : CACHE_TTL_MS;
        let items;
        if (cached && Date.now() - cached.at < ttl) {
            items = cached.items;
        }
        else {
            items = service === 'qobuz' ? await buildQobuz(genreId, kind) : await buildDeezer(genreId, kind);
            if (cache.size > 60)
                cache.clear();
            cache.set(key, { at: Date.now(), items });
        }
        return items.slice(offset, offset + limit);
    };
    const getGenres = async (service) => {
        if (service === 'qobuz') {
            await ensureQobuzSearchReady();
            const response = await qobuz.qobuzRequest?.('genre/list', { limit: 200, offset: 0 }).catch(() => null);
            const items = response?.genres?.items || response?.items || [];
            return items
                .filter((genre) => genre?.id != null && genre?.name)
                .map((genre) => ({ id: String(genre.id), name: String(genre.name) }));
        }
        const response = await makeHttpRequest(`${API}/genre`).catch(() => null);
        return (response?.data || [])
            .filter((genre) => String(genre.id) !== '0')
            .map((genre) => ({ id: String(genre.id), name: String(genre.name), picture: genre.picture_medium }));
    };
    return { getGenreContent, getGenres, coverOf };
};
exports.createGenreContent = createGenreContent;
