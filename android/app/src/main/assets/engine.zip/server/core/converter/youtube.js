"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.track2deezer = void 0;
const axios_1 = __importDefault(require("axios"));
const node_html_parser_1 = require("node-html-parser");
const api_1 = require("../deezer/api");
const getTrack = async (id) => {
    const response = await axios_1.default.get(`https://www.youtube.com/watch?v=${id}&hl=en`);
    const script = (0, node_html_parser_1.parse)(response.data)
        .querySelectorAll('script')
        .find((script) => script.childNodes.find((node) => node.rawText.includes('responseText')));
    if (script) {
        const info = script.text.split('= ');
        info.shift();
        if (info) {
            let jsonData = info.join('= ').trim();
            if (jsonData.endsWith(';')) {
                jsonData = jsonData.slice(0, -1);
            }
            const json = JSON.parse(jsonData);
            try {
                const data = json.contents.twoColumnWatchNextResults.results.results.contents[1].videoSecondaryInfoRenderer
                    .metadataRowContainer.metadataRowContainerRenderer;
                if (data.rows && data.rows.length > 0) {
                    const song = data.rows.find((row) => row.metadataRowRenderer && row.metadataRowRenderer.title.simpleText === 'Song');
                    const artist = data.rows.find((row) => row.metadataRowRenderer && row.metadataRowRenderer.title.simpleText === 'Artist');
                    if (song && artist) {
                        const { TRACK } = await (0, api_1.searchAlternative)(artist.metadataRowRenderer.contents[0].runs[0].text, song.metadataRowRenderer.contents[0].simpleText, 1);
                        if (TRACK.data[0]) {
                            return TRACK.data[0];
                        }
                    }
                }
            }
            catch (err) {
                const title = json.videoDetails.title
                    .toLowerCase()
                    .replace(/\(Off.*\)/i, '')
                    .replace(/ft.*/i, '')
                    .replace(/[,-\.]/g, '')
                    .replace(/  +/g, ' ')
                    .trim();
                const { TRACK } = await (0, api_1.searchMusic)(title, ['TRACK'], 20);
                const data = TRACK.data.filter((track) => title.includes(track.ART_NAME.toLowerCase()));
                if (data[0]) {
                    return TRACK.data[0];
                }
            }
        }
    }
};
const track2deezer = async (id) => {
    const track = await getTrack(id);
    if (track) {
        return track;
    }
    throw new Error('No track found for youtube video ' + id);
};
exports.track2deezer = track2deezer;
