"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mergeSetCookie = exports.renderCookieHeader = exports.parseCookieHeader = exports.ROTATING_COOKIES = void 0;
exports.ROTATING_COOKIES = [
    '__Secure-1PSIDTS',
    '__Secure-3PSIDTS',
    'SIDCC',
    '__Secure-1PSIDCC',
    '__Secure-3PSIDCC',
];
const parseCookieHeader = (header) => {
    const jar = new Map();
    for (const part of (header || '').split(';')) {
        const trimmed = part.trim();
        if (!trimmed)
            continue;
        const eq = trimmed.indexOf('=');
        if (eq <= 0)
            continue;
        jar.set(trimmed.slice(0, eq), trimmed.slice(eq + 1));
    }
    return jar;
};
exports.parseCookieHeader = parseCookieHeader;
const renderCookieHeader = (jar) => [...jar.entries()].map(([name, value]) => `${name}=${value}`).join('; ');
exports.renderCookieHeader = renderCookieHeader;
const parseSetCookie = (line) => {
    const first = (line || '').split(';')[0]?.trim();
    if (!first)
        return null;
    const eq = first.indexOf('=');
    if (eq <= 0)
        return null;
    return { name: first.slice(0, eq), value: first.slice(eq + 1) };
};
const mergeSetCookie = (cookieHeader, setCookie) => {
    if (!setCookie || setCookie.length === 0)
        return null;
    const jar = (0, exports.parseCookieHeader)(cookieHeader);
    let changed = false;
    for (const line of setCookie) {
        const parsed = parseSetCookie(line);
        if (!parsed)
            continue;
        if (!exports.ROTATING_COOKIES.includes(parsed.name))
            continue;
        if (!parsed.value || parsed.value === 'EXPIRED')
            continue;
        if (jar.get(parsed.name) === parsed.value)
            continue;
        jar.set(parsed.name, parsed.value);
        changed = true;
    }
    return changed ? (0, exports.renderCookieHeader)(jar) : null;
};
exports.mergeSetCookie = mergeSetCookie;
