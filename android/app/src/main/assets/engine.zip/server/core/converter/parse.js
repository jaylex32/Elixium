"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseQobuzUrl = exports.parseInfo = exports.getUrlParts = void 0;
const deezer_1 = require("../deezer");
const __1 = require("../");
const spotify_uri_1 = __importDefault(require("spotify-uri"));
const axios_1 = __importDefault(require("axios"));
const spotify = __importStar(require("./spotify"));
const tidal = __importStar(require("./tidal"));
const youtube = __importStar(require("./youtube"));
const p_queue_1 = __importDefault(require("p-queue"));
const queue = new p_queue_1.default({ concurrency: 10 });
const getUrlParts = async (url, setToken = false) => {
    if (url.startsWith('spotify:')) {
        const spotify = url.split(':');
        url = 'https://open.spotify.com/' + spotify[1] + '/' + spotify[2];
    }
    const site = url.match(/deezer|qobuz|spotify|tidal|youtu\.?be/);
    if (!site) {
        throw new Error('Unknown URL: ' + url);
    }
    switch (site[0]) {
        case 'deezer':
            if (url.includes('page.link') || url.includes('link.deezer.com')) {
                const { request } = await axios_1.default.head(url);
                url = request.res.responseUrl;
            }
            const deezerUrlParts = url.split(/\/(\w+)\/(\d+)/);
            return { type: deezerUrlParts[1], id: deezerUrlParts[2] };
        case 'qobuz':
            const qobuzUrlParts = url.split(/\/(\w+)\/(\w+)/);
            return { type: ('qobuz-' + qobuzUrlParts[1]), id: qobuzUrlParts[2] };
        case 'spotify':
            const spotifyUrlParts = spotify_uri_1.default.parse(url);
            if (setToken) {
                await spotify.setSpotifyAnonymousToken();
            }
            return { type: ('spotify-' + spotifyUrlParts.type), id: spotifyUrlParts.id };
        case 'tidal':
            const tidalUrlParts = url.split(/\/(\w+)\/([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}|\d+)/);
            return { type: ('tidal-' + tidalUrlParts[1]), id: tidalUrlParts[2] };
        case 'youtube':
            let yotubeId = url.split('v=')[1];
            if (yotubeId.includes('&')) {
                yotubeId = yotubeId.split('&')[0];
            }
            return { type: 'youtube-track', id: yotubeId };
        case 'youtu.be':
            return { type: 'youtube-track', id: url.split('/').pop() };
        default:
            throw new Error('Unable to parse URL: ' + url);
    }
};
exports.getUrlParts = getUrlParts;
const parseInfo = async (url) => {
    const info = await (0, exports.getUrlParts)(url, true);
    if (!info.id) {
        throw new Error('Unable to parse id');
    }
    let linktype = 'track';
    let linkinfo = {};
    let tracks = [];
    switch (info.type) {
        case 'track': {
            tracks.push(await (0, deezer_1.getTrackInfo)(info.id));
            break;
        }
        case 'album':
        case 'audiobook':
            linkinfo = await (0, deezer_1.getAlbumInfo)(info.id);
            linktype = 'album';
            const albumTracks = await (0, deezer_1.getAlbumTracks)(info.id);
            tracks = albumTracks.data;
            break;
        case 'playlist':
            linkinfo = await (0, deezer_1.getPlaylistInfo)(info.id);
            linktype = 'playlist';
            const playlistTracks = await (0, deezer_1.getPlaylistTracks)(info.id);
            tracks = playlistTracks.data;
            break;
        case 'artist':
            linkinfo = await (0, deezer_1.getArtistInfo)(info.id);
            linktype = 'artist';
            const artistAlbums = await (0, deezer_1.getDiscography)(info.id);
            await queue.addAll(artistAlbums.data.map((album) => {
                return async () => {
                    if (album.ARTISTS.find((a) => a.ART_ID === info.id)) {
                        const albumTracks = await (0, deezer_1.getAlbumTracks)(album.ALB_ID);
                        tracks = [...tracks, ...albumTracks.data.filter((t) => t.ART_ID === info.id)];
                    }
                };
            }));
            break;
        case 'spotify-track':
            tracks.push(await spotify.track2deezer(info.id));
            break;
        case 'spotify-album':
            const [spotifyAlbumInfo, spotifyTracks] = await spotify.album2deezer(info.id);
            tracks = spotifyTracks;
            linkinfo = spotifyAlbumInfo;
            linktype = 'album';
            break;
        case 'spotify-playlist':
            const [spotifyPlaylistInfo, spotifyPlaylistTracks] = await spotify.playlist2Deezer(info.id);
            tracks = spotifyPlaylistTracks;
            linkinfo = spotifyPlaylistInfo;
            linktype = 'playlist';
            break;
        case 'spotify-artist':
            tracks = await spotify.artist2Deezer(info.id);
            linktype = 'artist';
            break;
        case 'tidal-track':
            tracks.push(await tidal.track2deezer(info.id));
            break;
        case 'tidal-album':
            const [tidalAlbumInfo, tidalAlbumTracks] = await tidal.album2deezer(info.id);
            tracks = tidalAlbumTracks;
            linkinfo = tidalAlbumInfo;
            linktype = 'album';
            break;
        case 'tidal-playlist':
            const [tidalPlaylistInfo, tidalPlaylistTracks] = await tidal.playlist2Deezer(info.id);
            tracks = tidalPlaylistTracks;
            linkinfo = tidalPlaylistInfo;
            linktype = 'playlist';
            break;
        case 'tidal-artist':
            tracks = await tidal.artist2Deezer(info.id);
            linktype = 'artist';
            break;
        case 'youtube-track':
            tracks.push(await youtube.track2deezer(info.id));
            break;
        default:
            throw new Error('Unknown type: ' + info.type);
    }
    return {
        info,
        linktype,
        linkinfo,
        tracks: tracks.map((t) => {
            if (t.VERSION && !t.SNG_TITLE.includes(t.VERSION)) {
                t.SNG_TITLE += ' ' + t.VERSION;
            }
            return t;
        }),
    };
};
exports.parseInfo = parseInfo;
const parseQobuzUrl = async (url) => {
    const info = await (0, exports.getUrlParts)(url, true);
    let linktype = 'track';
    let linkinfo;
    let tracks = [];
    switch (info.type) {
        case 'qobuz-track': {
            const trackData = await __1.qobuz.getTrackInfo(+info.id);
            linkinfo = trackData.album;
            linktype = 'qobuz-track';
            tracks.push(trackData);
            break;
        }
        case 'qobuz-album': {
            const albumData = await __1.qobuz.getAlbumInfo(info.id);
            const albumWithoutTracks = { ...albumData };
            linktype = 'qobuz-album';
            tracks = albumData.tracks?.items || [];
            albumWithoutTracks.tracks = null;
            linkinfo = albumWithoutTracks;
            tracks = tracks.map((t) => {
                t.album = albumWithoutTracks;
                return t;
            });
            break;
        }
        case 'qobuz-playlist': {
            let offset = 0;
            const limit = 150;
            let moreTracks = true;
            while (moreTracks) {
                const playlistData = await __1.qobuz.getPlaylistTracks(info.id, { offset, limit });
                if (!playlistData || !playlistData.tracks || !playlistData.tracks.items) {
                    throw new Error('Playlist data is malformed or tracks are missing.');
                }
                linkinfo = {
                    ...playlistData,
                    title: playlistData.name || playlistData.title || 'Unknown Playlist',
                };
                linktype = 'qobuz-playlist';
                tracks = tracks.concat(playlistData.tracks.items.map((t) => {
                    if (!t.title) {
                        console.warn(`Warning: Track with ID ${t.id} is missing a title.`);
                        t.title = 'Unknown Title';
                    }
                    if (t.version && !t.title.includes(t.version)) {
                        t.title += ` (${t.version})`;
                    }
                    if (!t.title || typeof t.title !== 'string') {
                        console.error(`Error: Track with ID ${t.id} has an invalid title.`);
                    }
                    return t;
                }));
                if (playlistData.tracks.items.length < limit) {
                    moreTracks = false;
                }
                else {
                    offset += limit;
                }
            }
            break;
        }
        case 'qobuz-artist': {
            const artistData = await __1.qobuz.getArtistInfo(info.id);
            linkinfo = artistData;
            linktype = 'qobuz-artist';
            const albumsData = await __1.qobuz.getArtistAlbums(info.id);
            const allAlbums = albumsData.albums.items;
            for (const album of allAlbums) {
                const albumData = await __1.qobuz.getAlbumInfo(album.id);
                tracks = tracks.concat(albumData.tracks.items);
            }
            break;
        }
        default:
            throw new Error('Unsupported URL type: ' + info.type);
    }
    return {
        info,
        linktype,
        linkinfo,
        tracks: tracks.map((t) => {
            if (t.version && !t.title.includes(t.version)) {
                t.title += ` (${t.version})`;
            }
            return t;
        }),
    };
};
exports.parseQobuzUrl = parseQobuzUrl;
