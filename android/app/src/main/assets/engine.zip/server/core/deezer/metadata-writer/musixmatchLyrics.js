"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getLyricsMusixmatch = void 0;
const axios_1 = __importDefault(require("axios"));
const node_html_parser_1 = require("node-html-parser");
const useragents_1 = require("./useragents");
const baseUrl = 'https://musixmatch.com';
const getUrlMusixmatch = async (query) => {
    const { data } = await axios_1.default.get(`${baseUrl}/search/${encodeURI(query)}/tracks`, {
        headers: {
            'User-Agent': (0, useragents_1.randomUseragent)(),
            referer: 'https://l.facebook.com/',
        },
    });
    const childNode = (0, node_html_parser_1.parse)(data).querySelector('h2')?.childNodes.at(0);
    const url = childNode?.attributes.href.replace('/add', '');
    if (url && url.includes('/lyrics/')) {
        return url.startsWith('/lyrics/') ? baseUrl + url : url;
    }
    throw new Error('No song found!');
};
const getLyricsMusixmatch = async (query) => {
    const url = await getUrlMusixmatch(query);
    const { data } = await axios_1.default.get(url, {
        headers: {
            'User-Agent': (0, useragents_1.randomUseragent)(),
            referer: baseUrl + '/',
        },
    });
    let lyrics = data.match(/("body":".*","language")/)[0];
    lyrics = lyrics.replace('"body":"', '').replace('","language"', '');
    return lyrics.split('\\n').join('\n');
};
exports.getLyricsMusixmatch = getLyricsMusixmatch;
