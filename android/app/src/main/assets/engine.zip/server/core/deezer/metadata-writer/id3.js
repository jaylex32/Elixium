"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeMetadataMp3 = void 0;
const browser_id3_writer_1 = __importDefault(require("browser-id3-writer"));
const metadata_extra_1 = require("../../../lib/metadata-extra");
const metadata_options_1 = require("../../../lib/metadata-options");
const writeMetadataMp3 = (buffer, track, album, cover, options = metadata_options_1.DEFAULT_METADATA_OPTIONS) => {
    const writer = new browser_id3_writer_1.default(buffer);
    const RELEASE_DATE = (0, metadata_extra_1.bestReleaseDate)(track, album);
    const RELEASE_DATES = RELEASE_DATE ? RELEASE_DATE.split('-') : null;
    writer
        .setFrame('TIT2', track.SNG_TITLE)
        .setFrame('TALB', track.ALB_TITLE)
        .setFrame('TPE1', track.ARTISTS.map((a) => a.ART_NAME))
        .setFrame('TLEN', Number(track.DURATION) * 1000);
    if (options.isrc && track.ISRC)
        writer.setFrame('TSRC', track.ISRC);
    if (album) {
        if (album.genres.data.length > 0) {
            writer.setFrame('TCON', album.genres.data.map((g) => g.name));
        }
        if (RELEASE_DATES) {
            writer.setFrame('TYER', RELEASE_DATES[0]).setFrame('TDAT', RELEASE_DATES[2] + RELEASE_DATES[1]);
        }
        writer.setFrame('TPE2', album.artist.name);
        if (options.releaseType && album.record_type) {
            writer.setFrame('TXXX', { description: 'RELEASETYPE', value: album.record_type });
        }
        if (options.barcode && album.upc) {
            writer.setFrame('TXXX', { description: 'BARCODE', value: album.upc });
        }
        if (options.label && album.label) {
            writer.setFrame('TXXX', { description: 'LABEL', value: album.label });
        }
        if (options.compilation) {
            writer.setFrame('TXXX', {
                description: 'COMPILATION',
                value: (0, metadata_extra_1.isCompilation)(album.artist.name) ? '1' : '0',
            });
        }
    }
    if (options.media)
        writer.setFrame('TMED', 'Digital Media');
    if (options.provenance) {
        writer
            .setFrame('TXXX', { description: 'SOURCE', value: 'Deezer' })
            .setFrame('TXXX', { description: 'SOURCEID', value: track.SNG_ID });
    }
    if (track.DISK_NUMBER) {
        const TRACK_NUMBER = track.TRACK_NUMBER.toLocaleString('en-US', { minimumIntegerDigits: 2 });
        writer.setFrame('TPOS', track.DISK_NUMBER).setFrame('TRCK', album
            ? `${TRACK_NUMBER}/${album.nb_tracks.toLocaleString('en-US', {
                minimumIntegerDigits: 2,
            })}`
            : TRACK_NUMBER);
    }
    if (track.SNG_CONTRIBUTORS && !Array.isArray(track.SNG_CONTRIBUTORS)) {
        if (options.copyright && track.SNG_CONTRIBUTORS.main_artist) {
            writer.setFrame('TCOP', `${RELEASE_DATES ? RELEASE_DATES[0] + ' ' : ''}${track.SNG_CONTRIBUTORS.main_artist[0]}`);
        }
        if (options.credits && track.SNG_CONTRIBUTORS.publisher) {
            writer.setFrame('TPUB', track.SNG_CONTRIBUTORS.publisher.join(', '));
        }
        if (options.credits && track.SNG_CONTRIBUTORS.composer) {
            writer.setFrame('TCOM', track.SNG_CONTRIBUTORS.composer);
        }
        if (options.credits && track.SNG_CONTRIBUTORS.writer) {
            writer.setFrame('TXXX', {
                description: 'LYRICIST',
                value: track.SNG_CONTRIBUTORS.writer.join(', '),
            });
        }
        if (options.credits && track.SNG_CONTRIBUTORS.author) {
            writer.setFrame('TXXX', {
                description: 'AUTHOR',
                value: track.SNG_CONTRIBUTORS.author.join(', '),
            });
        }
        if (options.credits && track.SNG_CONTRIBUTORS.mixer) {
            writer.setFrame('TXXX', {
                description: 'MIXARTIST',
                value: track.SNG_CONTRIBUTORS.mixer.join(', '),
            });
        }
        if (options.credits && track.SNG_CONTRIBUTORS.producer && track.SNG_CONTRIBUTORS.engineer) {
            writer.setFrame('TXXX', {
                description: 'INVOLVEDPEOPLE',
                value: track.SNG_CONTRIBUTORS.producer.concat(track.SNG_CONTRIBUTORS.engineer).join(', '),
            });
        }
        if (options.extraCredits) {
            const alreadyWritten = [
                'main_artist',
                'publisher',
                'composer',
                'writer',
                'author',
                'mixer',
                'producer',
                'engineer',
            ];
            for (const [role, people] of Object.entries(track.SNG_CONTRIBUTORS)) {
                if (alreadyWritten.includes(role) || !Array.isArray(people) || people.length === 0)
                    continue;
                writer.setFrame('TXXX', {
                    description: role.toUpperCase(),
                    value: people.join(', '),
                });
            }
        }
    }
    if (track.LYRICS) {
        writer.setFrame('USLT', {
            description: '',
            lyrics: track.LYRICS.LYRICS_TEXT,
        });
    }
    if (options.explicit && track.EXPLICIT_LYRICS) {
        writer.setFrame('TXXX', {
            description: 'EXPLICIT',
            value: track.EXPLICIT_LYRICS,
        });
    }
    const gain = options.replayGain ? (0, metadata_extra_1.formatGain)(track.GAIN) : null;
    if (gain) {
        writer.setFrame('TXXX', { description: 'replaygain_track_gain', value: gain });
    }
    const bpm = Number(track.BPM ?? 0);
    if (options.bpm && Number.isFinite(bpm) && bpm > 0) {
        writer.setFrame('TBPM', Math.round(bpm));
    }
    const version = (0, metadata_extra_1.cleanVersion)(track.VERSION);
    if (version) {
        writer.setFrame('TIT3', version);
    }
    if (options.media)
        writer.setFrame('TMED', 'Digital Media');
    if (options.provenance)
        writer.setFrame('TXXX', { description: 'ENCODEDBY', value: metadata_extra_1.ENCODED_BY });
    if (cover) {
        writer.setFrame('APIC', {
            type: 3,
            data: cover,
            description: '',
        });
    }
    writer.addTag();
    return Buffer.from(writer.arrayBuffer);
};
exports.writeMetadataMp3 = writeMetadataMp3;
