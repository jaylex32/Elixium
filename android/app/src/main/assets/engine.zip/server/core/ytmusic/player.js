"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getAudioStream = exports.servesWholeFile = exports.fetchPlayerSession = exports.fetchPlayerApiKey = exports.bestAudioFormat = exports.sapisidHashHeader = exports.cookieValue = exports.clearStreamCache = exports.PlayerError = exports.PLAYER_TIMEOUT_MS = void 0;
const crypto_1 = __importDefault(require("crypto"));
const axios_1 = __importDefault(require("axios"));
const signature_1 = require("./signature");
exports.PLAYER_TIMEOUT_MS = 20000;
class PlayerError extends Error {
    constructor(kind, message, attempts = []) {
        super(message);
        this.name = 'PlayerError';
        this.kind = kind;
        this.attempts = attempts;
    }
}
exports.PlayerError = PlayerError;
const CLIENTS = [
    {
        name: 'VISIONOS',
        userAgent: 'Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15',
        directUrls: true,
        clientNumber: 101,
        supportsCookies: false,
        context: {
            clientName: 'VISIONOS',
            clientVersion: '1.02',
            deviceMake: 'Apple',
            deviceModel: 'RealityDevice17,1',
            osName: 'visionOS',
            osVersion: '26.5.23O471',
            hl: 'en',
            gl: 'US',
        },
    },
    {
        name: 'TV_DOWNGRADED',
        userAgent: 'Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version',
        directUrls: true,
        clientNumber: 7,
        supportsCookies: true,
        context: { clientName: 'TVHTML5', clientVersion: '5.20260707', hl: 'en', gl: 'US' },
    },
    {
        name: 'ANDROID_VR',
        userAgent: 'com.google.android.apps.youtube.vr.oculus/1.60.19 (Linux; U; Android 12; GB) gzip',
        directUrls: true,
        clientNumber: 28,
        supportsCookies: false,
        context: {
            clientName: 'ANDROID_VR',
            clientVersion: '1.60.19',
            deviceMake: 'Oculus',
            deviceModel: 'Quest 3',
            androidSdkVersion: 32,
            osName: 'Android',
            osVersion: '12',
            hl: 'en',
            gl: 'US',
        },
    },
    {
        name: 'ANDROID_VR_CURRENT',
        userAgent: 'com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; GB) gzip',
        directUrls: true,
        clientNumber: 28,
        supportsCookies: false,
        context: {
            clientName: 'ANDROID_VR',
            clientVersion: '1.65.10',
            deviceMake: 'Oculus',
            deviceModel: 'Quest 3',
            androidSdkVersion: 32,
            osName: 'Android',
            osVersion: '12L',
            hl: 'en',
            gl: 'US',
        },
    },
    {
        name: 'IOS',
        userAgent: 'com.google.ios.youtube/21.26.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X)',
        directUrls: true,
        clientNumber: 5,
        supportsCookies: false,
        context: {
            clientName: 'IOS',
            clientVersion: '21.26.4',
            deviceMake: 'Apple',
            deviceModel: 'iPhone16,2',
            osName: 'iPhone',
            osVersion: '18.3.2.22D82',
            hl: 'en',
            gl: 'US',
        },
    },
    {
        name: 'TVHTML5',
        userAgent: 'Mozilla/5.0 (ChromiumStylePlatform) Cobalt/Version',
        directUrls: false,
        clientNumber: 7,
        supportsCookies: true,
        context: { clientName: 'TVHTML5', clientVersion: '7.20260707.07.00', hl: 'en', gl: 'US' },
    },
    {
        name: 'MWEB',
        userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 18_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Mobile/15E148 Safari/604.1',
        directUrls: false,
        clientNumber: 2,
        supportsCookies: true,
        context: { clientName: 'MWEB', clientVersion: '2.20260708.05.00', hl: 'en', gl: 'US' },
    },
    {
        name: 'WEB',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        directUrls: false,
        clientNumber: 1,
        supportsCookies: true,
        context: { clientName: 'WEB', clientVersion: '2.20260708.00.00', hl: 'en', gl: 'US' },
    },
    {
        name: 'MWEB_2024',
        userAgent: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1',
        directUrls: false,
        clientNumber: 2,
        supportsCookies: true,
        context: { clientName: 'MWEB', clientVersion: '2.20240726.00.00', hl: 'en', gl: 'US' },
    },
    {
        name: 'WEB_2024',
        userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        directUrls: false,
        clientNumber: 1,
        supportsCookies: true,
        context: { clientName: 'WEB', clientVersion: '2.20240726.00.00', hl: 'en', gl: 'US' },
    },
];
const newClient = () => axios_1.default.create({ timeout: exports.PLAYER_TIMEOUT_MS, validateStatus: () => true });
const MINIMUM_REQUEST_GAP_MS = 150;
let lastRequestAt = 0;
let pending = Promise.resolve();
let preferredClient = null;
const RESOLVED_TTL_MS = 20 * 60 * 1000;
const resolved = new Map();
const clearStreamCache = () => {
    resolved.clear();
    preferredClient = null;
};
exports.clearStreamCache = clearStreamCache;
const paced = (work) => {
    const turn = pending.then(async () => {
        const wait = MINIMUM_REQUEST_GAP_MS - (Date.now() - lastRequestAt);
        if (wait > 0)
            await new Promise((resolve) => setTimeout(resolve, wait));
        lastRequestAt = Date.now();
        return work();
    });
    pending = turn.then(() => undefined, () => undefined);
    return turn;
};
const YOUTUBE_ORIGIN = 'https://www.youtube.com';
const cookieValue = (cookie, name) => {
    if (!cookie)
        return null;
    const match = new RegExp(`(?:^|;\\s*)${name}=([^;]*)`).exec(cookie);
    return match ? match[1] : null;
};
exports.cookieValue = cookieValue;
const sapisidHashHeader = (cookie, now = Date.now) => {
    const sapisid = (0, exports.cookieValue)(cookie, 'SAPISID') ?? (0, exports.cookieValue)(cookie, '__Secure-3PAPISID');
    if (!sapisid)
        return null;
    const timestamp = Math.floor(now() / 1000);
    const digest = crypto_1.default.createHash('sha1').update(`${timestamp} ${sapisid} ${YOUTUBE_ORIGIN}`).digest('hex');
    return `SAPISIDHASH ${timestamp}_${digest}`;
};
exports.sapisidHashHeader = sapisidHashHeader;
const codecOf = (mimeType) => {
    if (/opus/i.test(mimeType))
        return 'opus';
    if (/mp4a/i.test(mimeType))
        return 'aac';
    return 'other';
};
const bestAudioFormat = (formats, client, preferOpus = false, userAgent = '') => {
    const audio = (Array.isArray(formats) ? formats : []).filter((format) => String(format?.mimeType ?? '').startsWith('audio'));
    if (audio.length === 0)
        return null;
    const taggable = (format) => codecOf(String(format?.mimeType ?? '')) === 'aac';
    const ranked = [...audio].sort((a, b) => {
        if (!preferOpus) {
            const byContainer = Number(taggable(b)) - Number(taggable(a));
            if (byContainer !== 0)
                return byContainer;
        }
        const byBitrate = (b?.bitrate ?? 0) - (a?.bitrate ?? 0);
        if (byBitrate !== 0)
            return byBitrate;
        return codecOf(String(b?.mimeType ?? '')) === 'opus' ? 1 : -1;
    });
    const best = ranked[0];
    const mimeType = String(best?.mimeType ?? '');
    const url = String(best?.url ?? '');
    const cipher = String(best?.signatureCipher ?? best?.cipher ?? '');
    return {
        url,
        ...(url ? {} : { cipher }),
        itag: Number(best?.itag ?? 0),
        mimeType,
        bitrate: Number(best?.bitrate ?? 0),
        contentLength: best?.contentLength ? Number(best.contentLength) : null,
        codec: codecOf(mimeType),
        client,
        userAgent,
    };
};
exports.bestAudioFormat = bestAudioFormat;
const fetchPlayerApiKey = async (http) => {
    return (await (0, exports.fetchPlayerSession)(http)).apiKey;
};
exports.fetchPlayerApiKey = fetchPlayerApiKey;
const fetchPlayerSession = async (http) => {
    const { data } = await http.get('https://www.youtube.com/', {
        headers: { 'User-Agent': CLIENTS[CLIENTS.length - 1].userAgent },
    });
    const page = typeof data === 'string' ? data : '';
    const apiKey = /"INNERTUBE_API_KEY":"([^"]+)"/.exec(page)?.[1];
    if (!apiKey)
        throw new PlayerError('unknown', 'Could not read YouTube’s API key from their page');
    return { apiKey, visitorData: /"visitorData":"([^"]+)"/.exec(page)?.[1] };
};
exports.fetchPlayerSession = fetchPlayerSession;
const askClient = async (http, apiKey, profile, videoId, cookie, visitorData) => {
    const authorization = (0, exports.sapisidHashHeader)(cookie);
    const response = await paced(() => http.post(`https://www.youtube.com/youtubei/v1/player?key=${encodeURIComponent(apiKey)}`, {
        context: { client: { ...profile.context, ...(visitorData ? { visitorData } : {}) } },
        videoId,
        contentCheckOk: true,
        racyCheckOk: true,
    }, {
        headers: {
            'Content-Type': 'application/json',
            'User-Agent': profile.userAgent,
            Origin: YOUTUBE_ORIGIN,
            Referer: YOUTUBE_ORIGIN + '/',
            'X-YouTube-Client-Name': String(profile.clientNumber),
            'X-YouTube-Client-Version': String(profile.context.clientVersion ?? ''),
            ...(visitorData ? { 'X-Goog-Visitor-Id': visitorData } : {}),
            ...(cookie ? { Cookie: cookie } : {}),
            ...(authorization ? { Authorization: authorization, 'X-Origin': YOUTUBE_ORIGIN } : {}),
        },
    }));
    return response.data;
};
const servesWholeFile = async (stream, http) => {
    const total = stream.contentLength ?? 0;
    if (total <= FIRST_CHUNK_BYTES)
        return true;
    try {
        const response = await http.get(stream.url, {
            responseType: 'arraybuffer',
            timeout: 15000,
            validateStatus: () => true,
            headers: {
                Range: `bytes=${total - 16}-${total - 1}`,
                ...(stream.userAgent ? { 'User-Agent': stream.userAgent } : {}),
            },
        });
        return response.status === 206 || response.status === 200;
    }
    catch {
        return true;
    }
};
exports.servesWholeFile = servesWholeFile;
const FIRST_CHUNK_BYTES = 1024 * 1024;
const getAudioStream = async (videoId, options = {}) => {
    if (!/^[\w-]{11}$/.test(videoId))
        throw new PlayerError('unknown', `Not a YouTube video id: ${videoId}`);
    const cacheKey = `${videoId}:${options.preferOpus ? 'opus' : 'aac'}:${options.cookie ? 'auth' : 'anon'}`;
    const cached = resolved.get(cacheKey);
    if (cached && Date.now() - cached.at < RESOLVED_TTL_MS)
        return cached.stream;
    const alreadyResolving = inFlight.get(cacheKey);
    if (alreadyResolving)
        return alreadyResolving;
    const attempt = resolveAudioStream(videoId, options, cacheKey);
    inFlight.set(cacheKey, attempt);
    try {
        return await attempt;
    }
    finally {
        inFlight.delete(cacheKey);
    }
};
exports.getAudioStream = getAudioStream;
const inFlight = new Map();
const resolveAudioStream = async (videoId, options, cacheKey) => {
    const http = options.http ?? newClient();
    const session = options.apiKey ? { apiKey: options.apiKey, visitorData: undefined } : await (0, exports.fetchPlayerSession)(http);
    const apiKey = session.apiKey;
    const attempts = [];
    let solverOnce;
    const solver = () => {
        solverOnce ?? (solverOnce = (async () => {
            const watch = await http.get(`https://www.youtube.com/watch?v=${videoId}`, {
                headers: { 'User-Agent': CLIENTS[3].userAgent, ...(options.cookie ? { Cookie: options.cookie } : {}) },
            });
            return (0, signature_1.solverFor)(http, typeof watch.data === 'string' ? watch.data : '');
        })());
        return solverOnce;
    };
    const order = preferredClient
        ? [...CLIENTS].sort((a, b) => Number(b.name === preferredClient) - Number(a.name === preferredClient))
        : CLIENTS;
    for (const profile of order) {
        let data;
        try {
            const visitor = profile.supportsCookies ? undefined : session.visitorData;
            const withCookie = profile.supportsCookies ? options.cookie : undefined;
            data = await askClient(http, apiKey, profile, videoId, withCookie, visitor);
        }
        catch (error) {
            attempts.push({ client: profile.name, status: `network: ${error?.message ?? 'failed'}` });
            continue;
        }
        const status = String(data?.playabilityStatus?.status ?? 'UNKNOWN');
        const reason = String(data?.playabilityStatus?.reason ?? '');
        const stream = (0, exports.bestAudioFormat)(data?.streamingData?.adaptiveFormats, profile.name, options.preferOpus, profile.userAgent);
        if (stream?.url) {
            const ready = { ...stream, url: (0, signature_1.resolveThrottle)(stream.url, await solver()) };
            if (await (0, exports.servesWholeFile)(ready, http)) {
                preferredClient = profile.name;
                resolved.set(cacheKey, { stream: ready, at: Date.now() });
                return ready;
            }
            attempts.push({ client: profile.name, status: 'served only the first megabyte' });
            continue;
        }
        if (stream?.cipher) {
            const cipher = (0, signature_1.parseCipher)(stream.cipher);
            if (cipher) {
                const descrambled = (0, signature_1.resolveCipher)(cipher, await solver());
                if (descrambled) {
                    const ready = { ...stream, url: descrambled, cipher: undefined };
                    if (await (0, exports.servesWholeFile)(ready, http)) {
                        preferredClient = profile.name;
                        resolved.set(cacheKey, { stream: ready, at: Date.now() });
                        return ready;
                    }
                    attempts.push({ client: profile.name, status: 'served only the first megabyte' });
                    continue;
                }
            }
            attempts.push({ client: profile.name, status: 'signature could not be descrambled' });
            continue;
        }
        attempts.push({ client: profile.name, status: status + (reason ? ': ' + reason : '') });
    }
    const throttled = attempts.some((attempt) => /too many|try again later|rate/i.test(attempt.status));
    if (throttled) {
        throw new PlayerError('rate-limited', 'YouTube is temporarily refusing requests from this connection. Wait a few minutes and try a smaller batch.', attempts);
    }
    const sawLoginWall = attempts.some((attempt) => /LOGIN_REQUIRED|AGE|BOT/i.test(attempt.status));
    if (sawLoginWall) {
        throw new PlayerError('login-required', 'YouTube refused this download without a signed-in session. Add your YouTube cookie in Settings.', attempts);
    }
    const sawPartial = attempts.some((attempt) => /first megabyte/i.test(attempt.status));
    if (sawPartial) {
        throw new PlayerError('partial', 'YouTube would only serve the first part of this track. A signed-in session usually lifts that.', attempts);
    }
    const sawCipher = attempts.some((attempt) => /descrambled/i.test(attempt.status));
    if (sawCipher) {
        throw new PlayerError('cipher', 'YouTube scrambled this stream in a way Elixium cannot yet undo. This needs a code update, not a setting change.', attempts);
    }
    const sawUnavailable = attempts.some((attempt) => /UNPLAYABLE|ERROR|NOT_FOUND/i.test(attempt.status));
    throw new PlayerError(sawUnavailable ? 'unavailable' : 'no-audio', sawUnavailable ? 'YouTube says this track is not available' : 'YouTube returned no audio for this track', attempts);
};
