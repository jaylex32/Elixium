"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.artist2Deezer = exports.playlist2Deezer = exports.album2deezer = exports.track2deezer = exports.setSpotifyAnonymousToken = exports.getSpotifyPlaylistBundle = exports.spotifyApi = void 0;
const axios_1 = __importDefault(require("axios"));
const spotify_web_api_node_1 = __importDefault(require("spotify-web-api-node"));
const p_queue_1 = __importDefault(require("p-queue"));
const otpauth_1 = require("otpauth");
const base_1 = require("@scure/base");
const deezer_1 = require("./deezer");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const url_1 = require("url");
let cachedToken = null;
let tokenExpiresAt = 0;
let cachedUserAgent = '';
let cachedPublicToken = null;
let cachedOAuthAppToken = null;
let lastSpotifyApiRequestTime = 0;
const SPOTIFY_SCRAPE_USER_AGENT = 'Mozilla/5.0';
const SPOTIFY_REQUEST_MIN_INTERVAL_MS = 500;
const DEFAULT_SP_APP_CLIENT_ID = '880ca2262b0447bd82e4ea0b17febc16';
const DEFAULT_SP_APP_CLIENT_SECRET = 'c91c4b70b6e0482ebec5b91bf869c420';
const queue = new p_queue_1.default({ concurrency: 25 });
exports.spotifyApi = new spotify_web_api_node_1.default();
const SECRET_CIPHER_DICT = {
    '61': [44, 55, 47, 42, 70, 40, 34, 114, 76, 74, 50, 111, 120, 97, 75, 76, 94, 102, 43, 69, 49, 120, 118, 80, 64, 78],
};
const DEFAULT_SECRET_DICT_URL = 'https://raw.githubusercontent.com/xyloflake/spot-secrets-go/main/secrets/secretDict.json';
const SECRET_DICT_SOURCE = (process.env.SPOTIFY_SECRET_DICT_URL || DEFAULT_SECRET_DICT_URL).trim();
const TOKEN_MAX_RETRIES = 3;
const TOKEN_RETRY_DELAY_MS = 500;
const SECRET_FETCH_TIMEOUT_MS = 15000;
const SERVER_TIME_TIMEOUT_MS = 15000;
const TOTP_VER = 0;
const DEFAULT_CONFIG_FILE = 'elixium.config.json';
const getSpDcFromConfig = () => {
    try {
        const configPath = path.join(process.cwd(), DEFAULT_CONFIG_FILE);
        if (fs.existsSync(configPath)) {
            const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            return config.cookies?.sp_dc || null;
        }
    }
    catch (error) {
        console.warn('Failed to read config file:', error.message);
    }
    return null;
};
const getSpotifyOAuthAppCredentials = () => {
    let configClientId = '';
    let configClientSecret = '';
    try {
        const configPath = path.join(process.cwd(), DEFAULT_CONFIG_FILE);
        if (fs.existsSync(configPath)) {
            const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
            configClientId = String(config.sp_app_client_id || '').trim();
            configClientSecret = String(config.sp_app_client_secret || '').trim();
        }
    }
    catch (error) {
        console.warn('Failed to read Spotify OAuth app credentials from config:', error.message);
    }
    const clientId = (process.env.SP_APP_CLIENT_ID || configClientId || DEFAULT_SP_APP_CLIENT_ID).trim();
    const clientSecret = (process.env.SP_APP_CLIENT_SECRET || configClientSecret || DEFAULT_SP_APP_CLIENT_SECRET).trim();
    return { clientId, clientSecret };
};
const showCookieInstructions = () => {
    console.log(`\n❌ Spotify sp_dc cookie not found in ${DEFAULT_CONFIG_FILE}`);
    console.log('\n🔧 How to get your Spotify sp_dc cookie:');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('1. Open https://open.spotify.com in your browser');
    console.log('2. Login to your Spotify account');
    console.log('3. Press F12 to open Developer Tools');
    console.log('4. Go to Application tab → Cookies → https://open.spotify.com');
    console.log('5. Find the "sp_dc" cookie and copy its value');
    console.log(`6. Add it to your ${DEFAULT_CONFIG_FILE} file:`);
    console.log('');
    console.log('   {');
    console.log('     "cookies": {');
    console.log('       "arl": "your_deezer_arl_cookie",');
    console.log('       "sp_dc": "paste_your_sp_dc_cookie_here"');
    console.log('     }');
    console.log('   }');
    console.log('');
    console.log('💡 The sp_dc cookie is required for reliable Spotify authentication.');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
};
const generateRandomHex = (length = 8) => {
    const chars = '0123456789abcdef';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars[Math.floor(Math.random() * chars.length)];
    }
    return result;
};
const randomInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
const pickRandom = (items) => items[Math.floor(Math.random() * items.length)];
const generateUserAgent = () => {
    const choice = pickRandom(['chrome', 'edge', 'safari']);
    if (choice === 'chrome') {
        const major = randomInt(124, 128);
        const build = `${major}.0.${randomInt(0, 5000)}.${randomInt(0, 200)}`;
        return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${build} Safari/537.36`;
    }
    if (choice === 'edge') {
        const major = randomInt(122, 127);
        const build = `${major}.0.${randomInt(1000, 6000)}.${randomInt(0, 200)}`;
        return `Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/${build} Safari/537.36 Edg/${build}`;
    }
    const safariVersion = randomInt(15, 17);
    const macMajor = randomInt(11, 15);
    const macMinor = randomInt(0, 7);
    return `Mozilla/5.0 (Macintosh; Intel Mac OS X 10_${macMajor}_${macMinor}) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/${safariVersion}.0 Safari/605.1.15`;
};
const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const withTimeout = async (promise, timeoutMs, message) => {
    let timeoutHandle;
    try {
        return await Promise.race([
            promise,
            new Promise((_, reject) => {
                timeoutHandle = setTimeout(() => reject(new Error(message)), timeoutMs);
            }),
        ]);
    }
    finally {
        if (timeoutHandle) {
            clearTimeout(timeoutHandle);
        }
    }
};
const emitSpotifyProgress = (onProgress, payload) => {
    if (!onProgress) {
        return;
    }
    onProgress(payload);
};
const decodeHtmlEntities = (value) => value
    .replace(/&quot;/g, '"')
    .replace(/&#x27;/g, "'")
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>');
const parseMetaContent = (html, attribute, key) => {
    const escapedKey = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const patterns = [
        new RegExp(`<meta\\b[^>]*\\b${attribute}=["']${escapedKey}["'][^>]*\\bcontent=["']([^"']*)["'][^>]*>`, 'i'),
        new RegExp(`<meta\\b[^>]*\\bcontent=["']([^"']*)["'][^>]*\\b${attribute}=["']${escapedKey}["'][^>]*>`, 'i'),
    ];
    for (const pattern of patterns) {
        const match = html.match(pattern);
        if (match?.[1]) {
            return decodeHtmlEntities(match[1]);
        }
    }
    return null;
};
const parseSpotifyJsonLd = (html) => {
    const match = html.match(/<script type="application\/ld\+json">([\s\S]*?)<\/script>/i);
    if (!match?.[1]) {
        return { title: null, description: null, datePublished: null };
    }
    try {
        const parsed = JSON.parse(match[1]);
        const data = Array.isArray(parsed)
            ? parsed.find((entry) => entry && typeof entry === 'object') || {}
            : parsed || {};
        return {
            title: typeof data.name === 'string' ? decodeHtmlEntities(data.name) : null,
            description: typeof data.description === 'string' ? decodeHtmlEntities(data.description) : null,
            datePublished: typeof data.datePublished === 'string' ? data.datePublished : null,
        };
    }
    catch {
        return { title: null, description: null, datePublished: null };
    }
};
const normalizeSpotifyImageUrl = (value) => {
    const normalized = String(value || '').trim();
    if (!normalized)
        return '';
    if (/^https?:\/\//i.test(normalized))
        return normalized;
    if (normalized.startsWith('spotify:image:')) {
        return `https://i.scdn.co/image/${normalized.slice('spotify:image:'.length)}`;
    }
    if (/^[a-z0-9]{20,}$/i.test(normalized)) {
        return `https://i.scdn.co/image/${normalized}`;
    }
    return normalized;
};
const scrapeSpotifyPlaylistPageMetadata = async (id, userAgent = SPOTIFY_SCRAPE_USER_AGENT) => {
    try {
        const response = await withTimeout(axios_1.default.get(`https://open.spotify.com/playlist/${id}`, {
            headers: {
                'User-Agent': userAgent,
                Accept: 'text/html,application/xhtml+xml',
            },
            timeout: 20000,
        }), 25000, `Spotify playlist page request timed out for ${id}`);
        const html = String(response.data || '');
        const jsonLd = parseSpotifyJsonLd(html);
        return {
            title: parseMetaContent(html, 'property', 'og:title') || jsonLd.title,
            description: parseMetaContent(html, 'property', 'og:description') ||
                parseMetaContent(html, 'name', 'description') ||
                jsonLd.description,
            imageUrl: normalizeSpotifyImageUrl(parseMetaContent(html, 'property', 'og:image')),
        };
    }
    catch {
        return { title: null, description: null, imageUrl: null };
    }
};
const scrapeSpotifyTrackPageMetadata = async (id, userAgent = SPOTIFY_SCRAPE_USER_AGENT) => {
    try {
        const response = await withTimeout(axios_1.default.get(`https://open.spotify.com/track/${id}`, {
            headers: {
                'User-Agent': userAgent,
                Accept: 'text/html,application/xhtml+xml',
            },
            timeout: 20000,
        }), 25000, `Spotify track page request timed out for ${id}`);
        const html = String(response.data || '');
        const jsonLd = parseSpotifyJsonLd(html);
        const title = parseMetaContent(html, 'property', 'og:title') || jsonLd.title;
        const description = parseMetaContent(html, 'property', 'og:description') ||
            parseMetaContent(html, 'name', 'description') ||
            jsonLd.description;
        const durationRaw = parseMetaContent(html, 'name', 'music:duration');
        const releaseDate = parseMetaContent(html, 'name', 'music:release_date') || jsonLd.datePublished;
        const musiciansRaw = parseMetaContent(html, 'name', 'music:musician_description');
        if (!title || !description) {
            return null;
        }
        const parts = description
            .split('·')
            .map((part) => part.trim())
            .filter(Boolean);
        const artistText = musiciansRaw || (description.startsWith('Listen to ') ? parts[1] : parts[0]) || 'Unknown Artist';
        const artistNames = artistText
            .split(',')
            .map((part) => part.trim())
            .filter(Boolean);
        const primaryArtist = artistNames[0] || 'Unknown Artist';
        const albumName = !description.startsWith('Listen to ') && parts[1] ? parts[1] : 'Unknown Album';
        const durationSeconds = Number(durationRaw || 0);
        return {
            id,
            name: title,
            duration_ms: Number.isFinite(durationSeconds) && durationSeconds > 0 ? durationSeconds * 1000 : 0,
            artists: artistNames.length
                ? artistNames.map((name) => ({ name }))
                : [{ name: primaryArtist }],
            album: { name: albumName, release_date: releaseDate || undefined },
            external_ids: {},
        };
    }
    catch (error) {
        console.warn(`⚠️ Spotify track page fallback could not fetch ${id}: ${error.message}`);
        return null;
    }
};
const fetchSpotifyTracksFromPages = async (ids, onProgress) => {
    const pageQueue = new p_queue_1.default({ concurrency: 6 });
    const total = ids.length;
    let processed = 0;
    const tracksById = new Map();
    await Promise.all(ids.map((id) => pageQueue.add(async () => {
        const track = await scrapeSpotifyTrackPageMetadata(id);
        processed++;
        emitSpotifyProgress(onProgress, {
            phase: 'metadata',
            message: `Loading Spotify track pages... ${processed}/${total}`,
            current: processed,
            total,
            percentage: total > 0 ? Math.round((processed / total) * 100) : 100,
        });
        if (track) {
            tracksById.set(id, track);
        }
        else {
            console.warn(`⚠️ Spotify track page metadata could not be parsed for ${id}`);
        }
    })));
    const orderedTracks = ids
        .map((id) => tracksById.get(id))
        .filter((track) => Boolean(track));
    if (orderedTracks.length === 0 && ids.length > 0) {
        throw new Error('Spotify track page metadata extraction returned no playable tracks.');
    }
    return orderedTracks;
};
const getSpotifyErrorStatus = (error) => error?.statusCode ?? error?.status ?? error?.body?.error?.status ?? error?.response?.status;
const getRetryAfterMs = (headers, fallbackMs, maxMs = 15000) => {
    const retryAfterHeader = headers?.['retry-after'] ?? headers?.['Retry-After'];
    if (typeof retryAfterHeader === 'string') {
        const parsed = Number(retryAfterHeader);
        if (Number.isFinite(parsed) && parsed > 0) {
            return Math.min(parsed * 1000, maxMs);
        }
    }
    if (typeof retryAfterHeader === 'number' && Number.isFinite(retryAfterHeader) && retryAfterHeader > 0) {
        return Math.min(retryAfterHeader * 1000, maxMs);
    }
    return Math.min(fallbackMs, maxMs);
};
const SPOTIFY_BASE62_ALPHABET = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
const SPOTIFY_METADATA_APP_VERSION = '1.2.88.405.gd43644ed';
const extractTrackIdFromUri = (uri) => {
    if (!uri || !uri.startsWith('spotify:track:')) {
        return null;
    }
    const parts = uri.split(':');
    const id = parts[parts.length - 1];
    return id || null;
};
const convertSpotifyTrackIdToGid = (id) => {
    let num = 0n;
    for (const ch of id) {
        const idx = SPOTIFY_BASE62_ALPHABET.indexOf(ch);
        if (idx < 0) {
            throw new Error(`Invalid Spotify track id character: ${ch}`);
        }
        num = num * 62n + BigInt(idx);
    }
    return num.toString(16).padStart(32, '0');
};
const buildSpotifyImageUrl = (fileId) => {
    const normalized = String(fileId || '').trim();
    if (!normalized) {
        return undefined;
    }
    return `https://i.scdn.co/image/${normalized}`;
};
const formatSpotifyReleaseDate = (date) => {
    const year = Number(date?.year || 0);
    const month = Number(date?.month || 0);
    const day = Number(date?.day || 0);
    if (!year) {
        return undefined;
    }
    if (month > 0 && day > 0) {
        return `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    }
    if (month > 0) {
        return `${year}-${String(month).padStart(2, '0')}`;
    }
    return String(year);
};
const mapSpotifyMetadataTrackToTrackObject = (originalTrackId, payload) => {
    const title = String(payload.name || payload.original_title || '').trim();
    if (!title) {
        return null;
    }
    const canonicalId = extractTrackIdFromUri(payload.canonical_uri) || originalTrackId;
    const artists = (payload.artist || []).map((artist) => String(artist?.name || '').trim()).filter(Boolean);
    const albumArtists = (payload.album?.artist || []).map((artist) => String(artist?.name || '').trim()).filter(Boolean);
    const releaseDate = formatSpotifyReleaseDate(payload.album?.date);
    const images = (payload.album?.cover_group?.image || [])
        .map((image) => {
        const url = buildSpotifyImageUrl(image.file_id);
        if (!url) {
            return null;
        }
        return {
            url,
            width: Number(image.width || 0) || undefined,
            height: Number(image.height || 0) || undefined,
        };
    })
        .filter((image) => Boolean(image));
    const isrc = (payload.external_id || []).find((entry) => String(entry?.type || '').toLowerCase() === 'isrc')?.id;
    return {
        id: canonicalId,
        uri: `spotify:track:${canonicalId}`,
        name: title,
        duration_ms: Number(payload.duration || 0) || 0,
        artists: (artists.length ? artists : albumArtists.length ? albumArtists : ['Unknown Artist']).map((name) => ({ name })),
        album: {
            name: String(payload.album?.name || 'Unknown Album'),
            release_date: releaseDate,
            images,
            artists: albumArtists.map((name) => ({ name })),
        },
        external_ids: isrc ? { isrc: String(isrc) } : {},
    };
};
const fetchSpotifyTrackMetadataFromEndpoint = async (id, accessToken, userAgent, clientId) => {
    const gid = convertSpotifyTrackIdToGid(id);
    const response = await withTimeout(axios_1.default.get(`https://spclient.wg.spotify.com/metadata/4/track/${gid}`, {
        params: { market: 'from_token' },
        headers: {
            Authorization: `Bearer ${accessToken}`,
            'User-Agent': userAgent,
            Accept: 'application/json',
            'Accept-Language': 'en',
            Referer: 'https://open.spotify.com/',
            'app-platform': 'WebPlayer',
            'spotify-app-version': SPOTIFY_METADATA_APP_VERSION,
            Origin: 'https://open.spotify.com',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-site',
            ...(clientId ? { 'Client-Id': clientId } : {}),
        },
        timeout: 25000,
    }), 30000, `Spotify metadata endpoint request timed out for ${id}`);
    return mapSpotifyMetadataTrackToTrackObject(id, response.data || {});
};
const fetchSpotifyTracksFromMetadataEndpoint = async (ids, onProgress) => {
    const tokenData = await ensureValidToken();
    const total = ids.length;
    const userAgent = cachedUserAgent || generateUserAgent();
    const metadataQueue = new p_queue_1.default({ concurrency: 6 });
    let processed = 0;
    const tracksById = new Map();
    await Promise.all(ids.map((id) => metadataQueue.add(async () => {
        let track = null;
        let lastError = null;
        for (let attempt = 1; attempt <= 3; attempt++) {
            try {
                track = await fetchSpotifyTrackMetadataFromEndpoint(id, tokenData.accessToken, userAgent, tokenData.clientId);
                break;
            }
            catch (error) {
                lastError = error;
                const status = getSpotifyErrorStatus(error);
                if (status === 401 && attempt === 1) {
                    const refreshedToken = await forceRefreshSpotifyToken();
                    tokenData.accessToken = refreshedToken.accessToken;
                    tokenData.clientId = refreshedToken.clientId;
                    continue;
                }
                if (status === 429) {
                    const waitMs = getRetryAfterMs((error?.response?.headers || error?.headers), 1000 * attempt, 10000);
                    await sleep(waitMs);
                    continue;
                }
                if (attempt < 3 && (!status || status >= 500)) {
                    await sleep(500 * attempt);
                    continue;
                }
                break;
            }
        }
        if (!track) {
            track = await scrapeSpotifyTrackPageMetadata(id, SPOTIFY_SCRAPE_USER_AGENT);
            if (track) {
                console.log(`🔁 Using Spotify track page fallback for ${id}`);
            }
            else if (lastError) {
                console.warn(`⚠️ Spotify metadata endpoint could not resolve ${id}: ${lastError.message}`);
            }
            else {
                console.warn(`⚠️ Spotify metadata endpoint could not resolve ${id}`);
            }
        }
        processed++;
        emitSpotifyProgress(onProgress, {
            phase: 'metadata',
            message: `Loading Spotify track metadata... ${processed}/${total}`,
            current: processed,
            total,
            percentage: total > 0 ? Math.round((processed / total) * 100) : 100,
        });
        if (track) {
            tracksById.set(id, track);
        }
        else {
            console.warn(`⚠️ Spotify track metadata could not be resolved for ${id}`);
        }
    })));
    const orderedTracks = ids
        .map((id) => tracksById.get(id))
        .filter((track) => Boolean(track));
    if (orderedTracks.length === 0 && ids.length > 0) {
        throw new Error('Spotify metadata endpoint returned no playable tracks.');
    }
    return orderedTracks;
};
const getPublicSpotifyToken = async () => {
    const now = Date.now();
    if (cachedPublicToken && cachedPublicToken.expiresAt > now) {
        return cachedPublicToken.token;
    }
    try {
        const response = await axios_1.default.get('https://raw.githubusercontent.com/itzzzme/spotify-key/refs/heads/main/token.json', {
            timeout: 10000,
        });
        const token = response.data?.tokens?.[0]?.access_token;
        if (token && token.length > 50) {
            cachedPublicToken = { token, expiresAt: Date.now() + 10 * 60 * 1000 };
            return token;
        }
    }
    catch (error) {
        console.warn('Failed to fetch public Spotify fallback token:', error.message);
    }
    return null;
};
const forceRefreshSpotifyToken = async () => {
    cachedToken = null;
    tokenExpiresAt = 0;
    return await (0, exports.setSpotifyAnonymousToken)();
};
const respectSpotifyRateLimit = async () => {
    const now = Date.now();
    const elapsed = now - lastSpotifyApiRequestTime;
    if (elapsed < SPOTIFY_REQUEST_MIN_INTERVAL_MS) {
        await sleep(SPOTIFY_REQUEST_MIN_INTERVAL_MS - elapsed);
    }
    lastSpotifyApiRequestTime = Date.now();
};
const getSpotifyOAuthAppToken = async () => {
    const now = Date.now();
    if (cachedOAuthAppToken && cachedOAuthAppToken.expiresAt > now + 10000) {
        const isValid = await validateToken(cachedOAuthAppToken.token, undefined, cachedUserAgent || generateUserAgent(), true);
        if (isValid) {
            return cachedOAuthAppToken.token;
        }
        cachedOAuthAppToken = null;
    }
    const { clientId, clientSecret } = getSpotifyOAuthAppCredentials();
    if (!clientId || !clientSecret) {
        throw new Error('Missing Spotify OAuth app credentials (SP_APP_CLIENT_ID / SP_APP_CLIENT_SECRET).');
    }
    const basicAuth = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
    const response = await axios_1.default.post('https://accounts.spotify.com/api/token', new URLSearchParams({ grant_type: 'client_credentials' }).toString(), {
        headers: {
            Authorization: `Basic ${basicAuth}`,
            'Content-Type': 'application/x-www-form-urlencoded',
        },
        timeout: 20000,
    });
    const accessToken = response.data?.access_token;
    const expiresIn = Number(response.data?.expires_in || 3600);
    if (!accessToken) {
        throw new Error('Spotify OAuth app token response missing access_token.');
    }
    const validationUserAgent = cachedUserAgent || generateUserAgent();
    const isValid = await validateToken(accessToken, undefined, validationUserAgent, true);
    if (!isValid) {
        throw new Error('Spotify OAuth app token validation failed.');
    }
    cachedOAuthAppToken = {
        token: accessToken,
        expiresAt: Date.now() + Math.max(60, expiresIn - 30) * 1000,
    };
    return accessToken;
};
const fetchTracksIndividuallyWithOAuthApp = async (ids, userAgent, onProgress) => {
    let token = '';
    let tokenSource = 'oauth-app';
    let tokenClientId;
    try {
        token = await getSpotifyOAuthAppToken();
    }
    catch (error) {
        console.warn(`⚠️ Spotify OAuth app fallback unavailable: ${error.message}`);
        try {
            const refreshedToken = await ensureValidToken();
            token = refreshedToken.accessToken;
            tokenSource = 'cookie';
            tokenClientId = refreshedToken.clientId;
            console.log('🔁 Falling back to Spotify cookie token for per-track metadata fetch');
        }
        catch {
            const publicToken = await getPublicSpotifyToken();
            if (!publicToken) {
                throw error;
            }
            token = publicToken;
            tokenSource = 'public';
            console.log('🔁 Falling back to public Spotify token for per-track metadata fetch');
        }
    }
    const tracks = [];
    for (let index = 0; index < ids.length; index++) {
        const id = ids[index];
        let fetched = false;
        emitSpotifyProgress(onProgress, {
            phase: 'metadata',
            message: `Fetching Spotify metadata ${index + 1}/${ids.length}...`,
            current: index + 1,
            total: ids.length,
            percentage: Math.round(((index + 1) / ids.length) * 100),
        });
        for (let attempt = 1; attempt <= 3; attempt++) {
            try {
                await respectSpotifyRateLimit();
                const response = await withTimeout(axios_1.default.get(`https://api.spotify.com/v1/tracks/${id}`, {
                    headers: {
                        Authorization: `Bearer ${token}`,
                        'User-Agent': userAgent,
                        Accept: 'application/json',
                        ...(tokenSource === 'cookie' && tokenClientId ? { 'Client-Id': tokenClientId } : {}),
                    },
                    timeout: 25000,
                }), 30000, `Spotify OAuth track request timed out for ${id}`);
                if (response.data?.id && response.data?.name) {
                    tracks.push(response.data);
                }
                fetched = true;
                break;
            }
            catch (error) {
                const status = getSpotifyErrorStatus(error);
                if (status === 429) {
                    const waitMs = getRetryAfterMs((error?.headers || error?.response?.headers), 2000 * attempt, 10000);
                    await sleep(waitMs);
                    continue;
                }
                if (status === 401 && attempt === 1) {
                    if (token === cachedOAuthAppToken?.token) {
                        cachedOAuthAppToken = null;
                    }
                    else if (tokenSource === 'cookie') {
                        const refreshedToken = await forceRefreshSpotifyToken();
                        token = refreshedToken.accessToken;
                        tokenClientId = refreshedToken.clientId;
                        continue;
                    }
                    else if (token === cachedPublicToken?.token) {
                        cachedPublicToken = null;
                        const refreshedPublicToken = await getPublicSpotifyToken();
                        if (refreshedPublicToken) {
                            token = refreshedPublicToken;
                            continue;
                        }
                    }
                    continue;
                }
                if (status === 403 && token === cachedOAuthAppToken?.token) {
                    console.warn(`⚠️ Spotify OAuth app token blocked for track ${id}, trying cookie token fallback`);
                    cachedOAuthAppToken = null;
                    try {
                        const refreshedToken = await ensureValidToken();
                        token = refreshedToken.accessToken;
                        tokenSource = 'cookie';
                        tokenClientId = refreshedToken.clientId;
                        continue;
                    }
                    catch {
                        const publicToken = await getPublicSpotifyToken();
                        if (publicToken) {
                            token = publicToken;
                            tokenSource = 'public';
                            continue;
                        }
                    }
                }
                break;
            }
        }
        if (!fetched) {
            const pageTrack = await scrapeSpotifyTrackPageMetadata(id, userAgent);
            if (pageTrack) {
                console.log(`🔁 Using Spotify track page fallback for ${id}`);
                tracks.push(pageTrack);
                fetched = true;
            }
        }
        if (!fetched) {
            console.warn(`⚠️ OAuth fallback could not fetch Spotify track ${id}`);
        }
    }
    return tracks;
};
const fetchTracksWithBearer = async (ids, accessToken, userAgent) => {
    const response = await withTimeout(axios_1.default.get('https://api.spotify.com/v1/tracks', {
        params: {
            ids: ids.join(','),
        },
        headers: {
            Authorization: `Bearer ${accessToken}`,
            'User-Agent': userAgent,
            Accept: 'application/json',
        },
        timeout: 30000,
    }), 35000, 'Spotify track metadata request timed out');
    return (response.data?.tracks || []).filter((track) => {
        return Boolean(track && track.id && track.name);
    });
};
const fetchSpotifyTracksChunk = async (ids, onProgress) => {
    const maxRetries = 5;
    let publicFallbackToken = null;
    const userAgent = cachedUserAgent || generateUserAgent();
    let lastError = null;
    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            const token = publicFallbackToken ||
                (() => {
                    if (!cachedToken || tokenExpiresAt <= Date.now()) {
                        return '';
                    }
                    return cachedToken.accessToken;
                })();
            if (!token) {
                const refreshedToken = await ensureValidToken();
                console.log(`🔑 Spotify metadata auth refresh (attempt ${attempt}/${maxRetries})`);
                return await fetchTracksWithBearer(ids, refreshedToken.accessToken, userAgent);
            }
            return await fetchTracksWithBearer(ids, token, userAgent);
        }
        catch (error) {
            lastError = error;
            const status = getSpotifyErrorStatus(error);
            console.warn(`⚠️ Spotify metadata chunk attempt ${attempt}/${maxRetries} failed (status: ${status || 'unknown'})`);
            if (status === 401) {
                if (!publicFallbackToken) {
                    publicFallbackToken = await getPublicSpotifyToken();
                    if (publicFallbackToken) {
                        console.log('🔁 Falling back to public Spotify token for metadata fetch');
                        continue;
                    }
                }
                await forceRefreshSpotifyToken();
                continue;
            }
            if (status === 429) {
                if (attempt >= 2) {
                    console.log('🔁 Switching to OAuth fallback for Spotify metadata chunk');
                    emitSpotifyProgress(onProgress, {
                        phase: 'metadata',
                        message: 'Rate limited on Spotify metadata. Switching to fallback mode...',
                    });
                    const fallbackTracks = await fetchTracksIndividuallyWithOAuthApp(ids, userAgent, onProgress);
                    if (fallbackTracks.length > 0) {
                        return fallbackTracks;
                    }
                }
                const waitMs = getRetryAfterMs((error?.headers || error?.response?.headers), 1500 * attempt, 10000);
                console.warn(`⏳ Spotify rate limited while fetching metadata, waiting ${Math.ceil(waitMs / 1000)}s`);
                emitSpotifyProgress(onProgress, {
                    phase: 'metadata',
                    message: `Spotify rate limit reached. Waiting ${Math.ceil(waitMs / 1000)}s...`,
                });
                await sleep(waitMs);
                continue;
            }
            if (attempt < maxRetries && (!status || status >= 500 || status === 403)) {
                await sleep(600 * attempt);
                continue;
            }
            throw error;
        }
    }
    console.log('🔁 Switching to OAuth fallback for Spotify metadata chunk');
    emitSpotifyProgress(onProgress, {
        phase: 'metadata',
        message: 'Using fallback mode for Spotify metadata...',
    });
    const fallbackTracks = await fetchTracksIndividuallyWithOAuthApp(ids, userAgent, onProgress);
    if (fallbackTracks.length > 0) {
        return fallbackTracks;
    }
    throw new Error(`Failed to fetch Spotify track metadata after multiple attempts.${lastError ? ` Last error: ${lastError.message}` : ''}`);
};
const fetchSpotifyTracksByIds = async (ids, onProgress) => {
    const tracks = [];
    const chunkSize = 50;
    const totalChunks = Math.ceil(ids.length / chunkSize) || 1;
    for (let index = 0; index < ids.length; index += chunkSize) {
        const chunk = ids.slice(index, index + chunkSize);
        const chunkNumber = Math.floor(index / chunkSize) + 1;
        console.log(`🎧 Fetching Spotify track metadata chunk ${chunkNumber}/${totalChunks} (${chunk.length} tracks)`);
        emitSpotifyProgress(onProgress, {
            phase: 'metadata',
            message: `Fetching Spotify metadata chunk ${chunkNumber}/${totalChunks}...`,
            current: chunkNumber,
            total: totalChunks,
            percentage: Math.round((chunkNumber / totalChunks) * 100),
        });
        const chunkTracks = await fetchSpotifyTracksChunk(chunk, onProgress);
        if (chunkTracks.length === 0 && chunk.length > 0) {
            throw new Error(`Spotify metadata chunk ${chunkNumber}/${totalChunks} returned no tracks for ${chunk.length} IDs.`);
        }
        tracks.push(...chunkTracks);
    }
    return tracks;
};
const fetchSpclientPage = async (playlistId, offset, limit, token, clientId, userAgent) => {
    const headers = {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
        'User-Agent': userAgent,
        Accept: 'application/json',
        Referer: 'https://open.spotify.com/',
    };
    if (clientId) {
        headers['Client-Id'] = clientId;
    }
    const response = await axios_1.default.get(`https://spclient.wg.spotify.com/playlist/v2/playlist/${playlistId}`, {
        headers,
        params: { offset, limit },
        timeout: 30000,
    });
    return response.data;
};
const fetchSpclientPlaylistSnapshot = async (playlistId, onProgress) => {
    const tokenData = await ensureValidToken();
    let token = tokenData.accessToken;
    let clientId = tokenData.clientId;
    let userAgent = cachedUserAgent || generateUserAgent();
    let usePublicToken = false;
    const limit = 100;
    let offset = 0;
    let totalTracks = 0;
    let name = 'Unknown Playlist';
    let description = '';
    let imageUrl = '';
    let ownerId = 'spotify';
    let ownerName = 'Spotify';
    const seenTrackIds = new Set();
    const maxPages = 1000;
    let pageCount = 0;
    let hasMorePages = true;
    while (hasMorePages) {
        pageCount++;
        if (pageCount > maxPages) {
            throw new Error(`Spotify playlist pagination exceeded ${maxPages} pages. Aborting to avoid infinite loop.`);
        }
        const maxRetries = 5;
        let pageData = null;
        for (let attempt = 1; attempt <= maxRetries; attempt++) {
            try {
                pageData = await fetchSpclientPage(playlistId, offset, limit, token, clientId, userAgent);
                break;
            }
            catch (error) {
                const status = getSpotifyErrorStatus(error);
                if (status === 401) {
                    usePublicToken = false;
                    const refreshed = await forceRefreshSpotifyToken();
                    token = refreshed.accessToken;
                    clientId = refreshed.clientId;
                    userAgent = cachedUserAgent || userAgent;
                    continue;
                }
                if (status === 429) {
                    if (!usePublicToken) {
                        const publicToken = await getPublicSpotifyToken();
                        if (publicToken) {
                            token = publicToken;
                            usePublicToken = true;
                            await sleep(1000);
                            continue;
                        }
                    }
                    const waitMs = getRetryAfterMs((error?.response?.headers || error?.headers), 2000 * attempt);
                    await sleep(waitMs);
                    continue;
                }
                if (status === 403) {
                    throw new Error('Access denied. Playlist may be private or unavailable.');
                }
                if (status === 404) {
                    throw new Error('Playlist not found. Please verify the Spotify URL or ID.');
                }
                if (attempt < maxRetries && (!status || status >= 500)) {
                    await sleep(1000 * attempt);
                    continue;
                }
                throw error;
            }
        }
        if (!pageData) {
            throw new Error('Failed to fetch Spotify playlist data after multiple attempts.');
        }
        if (offset === 0) {
            name = pageData.attributes?.name || name;
            description = pageData.attributes?.description || description;
            imageUrl = normalizeSpotifyImageUrl(pageData.attributes?.picture) || imageUrl;
            ownerName = pageData.attributes?.owner_name || ownerName;
            ownerId = pageData.attributes?.owner_username || ownerId;
            totalTracks = Number(pageData.length || 0);
        }
        const items = pageData.contents?.items || [];
        let newTrackIds = 0;
        for (const item of items) {
            const id = extractTrackIdFromUri(item.uri);
            if (id && !seenTrackIds.has(id)) {
                seenTrackIds.add(id);
                newTrackIds++;
            }
        }
        console.log(`🎼 Spotify playlist page ${pageCount}: offset=${offset}, items=${items.length}, unique_ids=${seenTrackIds.size}, total=${totalTracks || 'unknown'}`);
        emitSpotifyProgress(onProgress, {
            phase: 'playlist',
            message: totalTracks > 0
                ? `Reading playlist tracks ${Math.min(seenTrackIds.size, totalTracks)}/${totalTracks}...`
                : `Reading playlist tracks... (${seenTrackIds.size} found)`,
            current: totalTracks > 0 ? Math.min(seenTrackIds.size, totalTracks) : seenTrackIds.size,
            total: totalTracks > 0 ? totalTracks : undefined,
            percentage: totalTracks > 0 ? Math.round((Math.min(seenTrackIds.size, totalTracks) / totalTracks) * 100) : undefined,
        });
        if (items.length > 0 && newTrackIds === 0) {
            console.warn('⚠️ Spotify pagination returned no new track IDs; stopping pagination to avoid loop.');
            hasMorePages = false;
            continue;
        }
        if (items.length === 0) {
            hasMorePages = false;
        }
        else if (totalTracks > 0 && seenTrackIds.size >= totalTracks) {
            hasMorePages = false;
        }
        else if (totalTracks === 0 && items.length < limit) {
            hasMorePages = false;
        }
        else {
            offset += limit;
        }
    }
    if (!imageUrl || !name || name === 'Unknown Playlist') {
        const playlistPageMeta = await scrapeSpotifyPlaylistPageMetadata(playlistId);
        imageUrl = normalizeSpotifyImageUrl(playlistPageMeta.imageUrl) || imageUrl;
        name = String(playlistPageMeta.title || name || 'Unknown Playlist');
        description = String(playlistPageMeta.description || description || '');
    }
    return {
        id: playlistId,
        name,
        description,
        imageUrl,
        ownerId,
        ownerName,
        totalTracks: totalTracks > 0 ? totalTracks : seenTrackIds.size,
        trackIds: Array.from(seenTrackIds),
    };
};
const getSpotifyPlaylistBundle = async (id, onProgress) => {
    emitSpotifyProgress(onProgress, {
        phase: 'playlist',
        message: 'Fetching Spotify playlist details...',
        percentage: 0,
    });
    const snapshot = await fetchSpclientPlaylistSnapshot(id, onProgress);
    emitSpotifyProgress(onProgress, {
        phase: 'metadata',
        message: `Resolving ${snapshot.trackIds.length} Spotify tracks...`,
        current: 0,
        total: snapshot.trackIds.length,
        percentage: 0,
    });
    const tracks = await fetchSpotifyTracksFromMetadataEndpoint(snapshot.trackIds, onProgress);
    emitSpotifyProgress(onProgress, {
        phase: 'metadata',
        message: `Resolved ${tracks.length} Spotify tracks.`,
        current: tracks.length,
        total: snapshot.trackIds.length,
        percentage: 100,
    });
    return {
        ...snapshot,
        tracks,
    };
};
exports.getSpotifyPlaylistBundle = getSpotifyPlaylistBundle;
const fetchServerTime = async (userAgent) => {
    try {
        const response = await axios_1.default.head('https://open.spotify.com/', {
            headers: {
                'User-Agent': userAgent,
                Accept: '*/*',
            },
            timeout: SERVER_TIME_TIMEOUT_MS,
        });
        const headers = response.headers;
        const dateHeader = headers?.date || headers?.Date;
        if (dateHeader) {
            return Math.floor(new Date(dateHeader).getTime() / 1000);
        }
        throw new Error('No Date header in response');
    }
    catch (error) {
        console.warn('Failed to fetch server time, using local time:', error.message);
        return Math.floor(Date.now() / 1000);
    }
};
const fetchUpdatedSecrets = async (userAgent) => {
    const source = SECRET_DICT_SOURCE;
    if (!source) {
        return null;
    }
    try {
        console.log('?? Fetching updated secrets...');
        let payload;
        if (/^https?:\/\//i.test(source)) {
            const response = await axios_1.default.get(source, {
                timeout: SECRET_FETCH_TIMEOUT_MS,
                headers: {
                    'User-Agent': userAgent,
                    Accept: 'application/json',
                },
            });
            payload = response.data;
        }
        else {
            let localPath = source;
            if (source.startsWith('file:')) {
                try {
                    localPath = (0, url_1.fileURLToPath)(new URL(source));
                }
                catch {
                    localPath = source.replace(/^file:\/\//, '');
                }
            }
            const resolvedPath = path.isAbsolute(localPath) ? localPath : path.resolve(process.cwd(), localPath);
            const fileContents = await fs.promises.readFile(resolvedPath, 'utf8');
            payload = JSON.parse(fileContents);
        }
        if (typeof payload !== 'object' || payload === null) {
            throw new Error('Invalid secrets payload');
        }
        const secrets = payload;
        for (const [key, value] of Object.entries(secrets)) {
            if (!/^\d+$/.test(key) || !Array.isArray(value) || !value.every((item) => typeof item === 'number')) {
                throw new Error(`Invalid secret format for key ${key}`);
            }
        }
        console.log('? Updated secrets loaded');
        return secrets;
    }
    catch (error) {
        console.warn('?? Failed to get updated secrets:', error.message);
        return null;
    }
};
const generateTotpWithSecrets = (secretDict, serverTime) => {
    const ver = TOTP_VER || Math.max(...Object.keys(secretDict).map((k) => parseInt(k)));
    const verStr = ver.toString();
    if (!(verStr in secretDict)) {
        throw new Error(`TOTP version ${ver} not found in secret dictionary`);
    }
    const secretCipherBytes = secretDict[verStr];
    const transformed = secretCipherBytes.map((e, t) => e ^ ((t % 33) + 9));
    const joined = transformed.join('');
    const secretBytes = new TextEncoder().encode(joined);
    const hexStr = Array.from(secretBytes)
        .map((b) => b.toString(16).padStart(2, '0'))
        .join('');
    const secret = base_1.base32.encode(new Uint8Array(Buffer.from(hexStr, 'hex'))).replace(/=/g, '');
    const totp = new otpauth_1.TOTP({
        algorithm: 'SHA1',
        digits: 6,
        period: 30,
        secret: secret,
    });
    return totp.generate({ timestamp: serverTime * 1000 });
};
const validateToken = async (accessToken, clientId, userAgent, oauthApp = false) => {
    try {
        const headers = {
            Authorization: `Bearer ${accessToken}`,
            'User-Agent': userAgent,
        };
        if (!oauthApp && clientId) {
            headers['Client-Id'] = clientId;
        }
        const response = await axios_1.default.get(oauthApp
            ? 'https://api.spotify.com/v1/tracks/7tFiyTwD0nx5a1eklYtX2J'
            : 'https://guc-spclient.spotify.com/presence-view/v1/buddylist', {
            headers,
            timeout: 10000,
        });
        return response.status === 200;
    }
    catch {
        return false;
    }
};
const generateTotp = async () => {
    const userAgent = generateUserAgent();
    const serverTime = await fetchServerTime(userAgent);
    return generateTotpWithSecrets(SECRET_CIPHER_DICT, serverTime);
};
const refreshAccessToken = async (mode, spDc, secretDict, userAgent) => {
    const serverTime = await fetchServerTime(userAgent);
    const clientTime = Date.now();
    const otp = generateTotpWithSecrets(secretDict, serverTime);
    const totpVer = TOTP_VER || Math.max(...Object.keys(secretDict).map((k) => parseInt(k)));
    const params = {
        reason: mode,
        productType: 'web-player',
        totp: otp,
        totpServer: otp,
        totpVer,
    };
    if (totpVer < 10) {
        const buildDate = new Date(serverTime * 1000).toISOString().split('T')[0];
        params.sTime = serverTime;
        params.cTime = clientTime;
        params.buildDate = buildDate;
        params.buildVer = `web-player_${buildDate}_${serverTime * 1000}_${generateRandomHex(8)}`;
    }
    const headers = {
        'User-Agent': userAgent,
        Accept: 'application/json',
        Referer: 'https://open.spotify.com/',
        'App-Platform': 'WebPlayer',
        Origin: 'https://open.spotify.com',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        Cookie: `sp_dc=${spDc}`,
    };
    try {
        const response = await axios_1.default.get('https://open.spotify.com/api/token', {
            params,
            headers,
            timeout: 15000,
        });
        if (!response.data || !response.data.accessToken) {
            throw new Error(`No access token in ${mode} mode response`);
        }
        return response.data;
    }
    catch (error) {
        console.log(`[spotify] Token request failed (mode=${mode}, totpVer=${params.totpVer}, status=${error.response?.status})`);
        throw new Error(`Failed to get token in ${mode} mode: ${error.message}`);
    }
};
const setSpotifyAnonymousToken = async () => {
    const now = Date.now();
    if (cachedToken && tokenExpiresAt > now) {
        console.log('[spotify] Using cached token');
        exports.spotifyApi = new spotify_web_api_node_1.default({ clientId: cachedToken.clientId });
        exports.spotifyApi.setAccessToken(cachedToken.accessToken);
        return cachedToken;
    }
    const spDc = getSpDcFromConfig();
    if (!spDc) {
        showCookieInstructions();
        throw new Error(`Spotify sp_dc cookie not found. Please add it to ${DEFAULT_CONFIG_FILE} (see instructions above)`);
    }
    console.log('[spotify] Found sp_dc cookie in config');
    let lastError = null;
    const updatedSecrets = await fetchUpdatedSecrets(generateUserAgent());
    const primarySecrets = updatedSecrets || SECRET_CIPHER_DICT;
    const fallbackSecrets = updatedSecrets ? SECRET_CIPHER_DICT : null;
    const attemptWithSecrets = async (secrets, label) => {
        const userAgent = generateUserAgent();
        let attemptError = null;
        for (const mode of ['transport', 'init']) {
            for (let attempt = 1; attempt <= TOKEN_MAX_RETRIES; attempt++) {
                try {
                    const tokenData = await refreshAccessToken(mode, spDc, secrets, userAgent);
                    const isValid = await validateToken(tokenData.accessToken, tokenData.clientId, userAgent, false);
                    if (isValid) {
                        console.log('[spotify] Token validation passed');
                    }
                    else {
                        console.log('[spotify] Token validation failed; continuing with anonymous token');
                    }
                    cachedToken = tokenData;
                    tokenExpiresAt = tokenData.accessTokenExpirationTimestampMs;
                    cachedUserAgent = userAgent;
                    exports.spotifyApi = new spotify_web_api_node_1.default({ clientId: tokenData.clientId });
                    exports.spotifyApi.setAccessToken(tokenData.accessToken);
                    console.log(`[spotify] Authentication successful via ${label} (${mode})`);
                    return tokenData;
                }
                catch (error) {
                    attemptError = error;
                    console.log(`[spotify] ${label} ${mode} attempt ${attempt} failed: ${attemptError.message}`);
                    if (attempt < TOKEN_MAX_RETRIES) {
                        await sleep(TOKEN_RETRY_DELAY_MS * attempt);
                    }
                }
            }
        }
        throw attemptError ?? new Error('Unknown authentication error');
    };
    try {
        return await attemptWithSecrets(primarySecrets, updatedSecrets ? 'updated secrets' : 'default secrets');
    }
    catch (error) {
        lastError = error;
    }
    if (fallbackSecrets) {
        try {
            return await attemptWithSecrets(fallbackSecrets, 'default secrets fallback');
        }
        catch (error) {
            lastError = error;
        }
    }
    console.log('\n[spotify] All authentication attempts failed.');
    console.log('[spotify] Troubleshooting:');
    console.log('  - Your sp_dc cookie might be expired - get a fresh one');
    console.log('  - Check your internet connection');
    console.log('  - Try again in a few minutes (rate limiting)');
    throw new Error(`Failed to authenticate with Spotify. Last error: ${lastError?.message || 'Unknown error'}`);
};
exports.setSpotifyAnonymousToken = setSpotifyAnonymousToken;
const ensureValidToken = async () => {
    if (!cachedToken || tokenExpiresAt <= Date.now()) {
        console.log('🔄 No valid token found, generating new one...');
        return await (0, exports.setSpotifyAnonymousToken)();
    }
    exports.spotifyApi = new spotify_web_api_node_1.default({ clientId: cachedToken.clientId });
    exports.spotifyApi.setAccessToken(cachedToken.accessToken);
    return cachedToken;
};
const track2deezer = async (id) => {
    await ensureValidToken();
    const { body } = await exports.spotifyApi.getTrack(id);
    const artistName = body.artists[0]?.name || '';
    const albumName = body.album?.name;
    const durationSeconds = body.duration_ms ? Math.round(body.duration_ms / 1000) : undefined;
    return await (0, deezer_1.isrc2deezer)(body.name, body.external_ids.isrc, artistName, albumName, durationSeconds);
};
exports.track2deezer = track2deezer;
const album2deezer = async (id) => {
    await ensureValidToken();
    const { body } = await exports.spotifyApi.getAlbum(id);
    return await (0, deezer_1.upc2deezer)(body.name, body.external_ids.upc);
};
exports.album2deezer = album2deezer;
const playlist2Deezer = async (id, onError) => {
    console.log('📋 Fetching Spotify playlist data via spclient...');
    const playlistBundle = await (0, exports.getSpotifyPlaylistBundle)(id);
    const tracks = [];
    const spotifyTracks = playlistBundle.tracks;
    await queue.addAll(spotifyTracks.map((spotifyTrack, index) => {
        return async () => {
            try {
                const artistName = spotifyTrack.artists[0]?.name || '';
                const albumName = spotifyTrack.album?.name;
                const durationSeconds = spotifyTrack.duration_ms ? Math.round(spotifyTrack.duration_ms / 1000) : undefined;
                const track = await (0, deezer_1.isrc2deezer)(spotifyTrack.name, spotifyTrack.external_ids?.isrc, artistName, albumName, durationSeconds);
                track.TRACK_POSITION = index + 1;
                tracks.push(track);
            }
            catch (err) {
                if (onError) {
                    onError({ track: spotifyTrack }, index, err);
                }
            }
        };
    }));
    const dateCreated = new Date().toISOString();
    const playlistInfoData = {
        PLAYLIST_ID: playlistBundle.id,
        PARENT_USERNAME: playlistBundle.ownerName,
        PARENT_USER_ID: playlistBundle.ownerId,
        PICTURE_TYPE: 'cover',
        PLAYLIST_PICTURE: playlistBundle.imageUrl || '',
        TITLE: playlistBundle.name,
        TYPE: '0',
        STATUS: '0',
        USER_ID: playlistBundle.ownerId,
        DATE_ADD: dateCreated,
        DATE_MOD: dateCreated,
        DATE_CREATE: dateCreated,
        NB_SONG: playlistBundle.totalTracks,
        NB_FAN: 0,
        CHECKSUM: playlistBundle.id,
        HAS_ARTIST_LINKED: false,
        IS_SPONSORED: false,
        IS_EDITO: false,
        __TYPE__: 'playlist',
    };
    return [playlistInfoData, tracks];
};
exports.playlist2Deezer = playlist2Deezer;
const artist2Deezer = async (id, onError) => {
    await ensureValidToken();
    const { body } = await exports.spotifyApi.getArtistTopTracks(id, 'GB');
    const tracks = [];
    await queue.addAll(body.tracks.map((item, index) => {
        return async () => {
            try {
                const artistName = item.artists[0]?.name || '';
                const albumName = item.album?.name;
                const durationSeconds = item.duration_ms ? Math.round(item.duration_ms / 1000) : undefined;
                const track = await (0, deezer_1.isrc2deezer)(item.name, item.external_ids.isrc, artistName, albumName, durationSeconds);
                tracks.push(track);
            }
            catch (err) {
                if (onError) {
                    onError(item, index, err);
                }
            }
        };
    }));
    return tracks;
};
exports.artist2Deezer = artist2Deezer;
