"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.playlist2Deezer = exports.artist2Deezer = exports.albumArtToUrl = exports.getPlaylistTracks = exports.getPlaylist = exports.getArtistTopTracks = exports.getArtistAlbums = exports.getAlbumTracks = exports.album2deezer = exports.getAlbum = exports.track2deezer = exports.getTrack = void 0;
const axios_1 = __importDefault(require("axios"));
const p_queue_1 = __importDefault(require("p-queue"));
const deezer_1 = require("./deezer");
const client = axios_1.default.create({
    baseURL: 'https://api.tidal.com/v1/',
    timeout: 15000,
    headers: {
        'user-agent': 'TIDAL/3704 CFNetwork/1220.1 Darwin/20.3.0',
        'x-tidal-token': 'i4ZDjcyhed7Mu47q',
    },
    params: { limit: 500, countryCode: 'US' },
});
const queue = new p_queue_1.default({ concurrency: 25 });
const getTrack = async (id) => {
    const { data } = await client.get(`tracks/${id}`);
    return data;
};
exports.getTrack = getTrack;
const track2deezer = async (id) => {
    const track = await (0, exports.getTrack)(id);
    return await (0, deezer_1.isrc2deezer)(track.title, track.isrc);
};
exports.track2deezer = track2deezer;
const getAlbum = async (id) => {
    const { data } = await client.get(`albums/${id}`);
    return data;
};
exports.getAlbum = getAlbum;
const album2deezer = async (id) => {
    const album = await (0, exports.getAlbum)(id);
    return await (0, deezer_1.upc2deezer)(album.title, album.upc);
};
exports.album2deezer = album2deezer;
const getAlbumTracks = async (id) => {
    const { data } = await client.get(`albums/${id}/tracks`);
    return data;
};
exports.getAlbumTracks = getAlbumTracks;
const getArtistAlbums = async (id) => {
    const { data } = await client.get(`artists/${id}/albums`);
    data.items = data.items.filter((item) => item.artist.id.toString() === id);
    return data;
};
exports.getArtistAlbums = getArtistAlbums;
const getArtistTopTracks = async (id) => {
    const { data } = await client.get(`artists/${id}/toptracks`);
    data.items = data.items.filter((item) => item.artist.id.toString() === id);
    return data;
};
exports.getArtistTopTracks = getArtistTopTracks;
const getPlaylist = async (uuid) => {
    const { data } = await client.get(`playlists/${uuid}`);
    return data;
};
exports.getPlaylist = getPlaylist;
const getPlaylistTracks = async (uuid) => {
    const { data } = await client.get(`playlists/${uuid}/tracks`);
    return data;
};
exports.getPlaylistTracks = getPlaylistTracks;
const albumArtToUrl = (uuid) => {
    const baseUrl = `https://resources.tidal.com/images/${uuid.replace(/-/g, '/')}`;
    return {
        sm: `${baseUrl}/160x160.jpg`,
        md: `${baseUrl}/320x320.jpg`,
        lg: `${baseUrl}/640x640.jpg`,
        xl: `${baseUrl}/1280x1280.jpg`,
    };
};
exports.albumArtToUrl = albumArtToUrl;
const artist2Deezer = async (id, onError) => {
    const { items } = await (0, exports.getArtistTopTracks)(id);
    const tracks = [];
    await queue.addAll(items.map((item, index) => {
        return async () => {
            try {
                const track = await (0, deezer_1.isrc2deezer)(item.title, item.isrc);
                tracks.push(track);
            }
            catch (err) {
                if (onError) {
                    onError(item, index, err);
                }
            }
        };
    }));
    return tracks;
};
exports.artist2Deezer = artist2Deezer;
const playlist2Deezer = async (uuid, onError) => {
    const body = await (0, exports.getPlaylist)(uuid);
    const { items } = await (0, exports.getPlaylistTracks)(uuid);
    const tracks = [];
    await queue.addAll(items.map((item, index) => {
        return async () => {
            try {
                const track = await (0, deezer_1.isrc2deezer)(item.title, item.isrc);
                track.TRACK_POSITION = index + 1;
                tracks.push(track);
            }
            catch (err) {
                if (onError) {
                    onError(item, index, err);
                }
            }
        };
    }));
    const userId = body.creator.id.toString();
    const playlistInfoData = {
        PLAYLIST_ID: body.uuid,
        PARENT_USERNAME: userId,
        PARENT_USER_ID: userId,
        PICTURE_TYPE: 'cover',
        PLAYLIST_PICTURE: body.image,
        TITLE: body.title,
        TYPE: '0',
        STATUS: '0',
        USER_ID: userId,
        DATE_ADD: body.created,
        DATE_MOD: body.lastUpdated,
        DATE_CREATE: body.created,
        NB_SONG: body.numberOfTracks,
        NB_FAN: 0,
        CHECKSUM: body.created,
        HAS_ARTIST_LINKED: false,
        IS_SPONSORED: false,
        IS_EDITO: false,
        __TYPE__: 'playlist',
    };
    return [playlistInfoData, tracks];
};
exports.playlist2Deezer = playlist2Deezer;
