"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.downloadAlbumCover = void 0;
const axios_1 = __importDefault(require("axios"));
const fast_lru_1 = __importDefault(require("../../lib/fast-lru"));
const lru = new fast_lru_1.default({
    maxSize: 50,
    ttl: 30 * 60000,
});
const downloadAlbumCover = async (track, albumCoverSize) => {
    if (!track.ALB_PICTURE) {
        return null;
    }
    const cache = lru.get(track.ALB_PICTURE + albumCoverSize);
    if (cache) {
        return cache;
    }
    try {
        const url = `https://e-cdns-images.dzcdn.net/images/cover/${track.ALB_PICTURE}/${albumCoverSize}x${albumCoverSize}-000000-80-0-0.jpg`;
        const { data } = await axios_1.default.get(url, { responseType: 'arraybuffer' });
        lru.set(track.ALB_PICTURE + albumCoverSize, data);
        return data;
    }
    catch (err) {
        return null;
    }
};
exports.downloadAlbumCover = downloadAlbumCover;
