"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fast_lru_1 = __importDefault(require("../../lib/fast-lru"));
const lru = new fast_lru_1.default({
    maxSize: 1000,
    ttl: 60 * 60000,
});
exports.default = lru;
