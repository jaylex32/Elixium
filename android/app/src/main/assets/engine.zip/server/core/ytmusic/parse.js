"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseShelves = exports.parseGenres = exports.parseArtist = exports.parseCollection = exports.parseCollectionTrack = exports.parseGrid = exports.parseSearchContinuation = exports.shelfContinuationOf = exports.continuationOf = exports.parseSearch = exports.parseSearchItem = exports.isExplicitRow = exports.linkedIdsOf = exports.isAlbumAudio = exports.musicVideoTypeOf = exports.thumbnailOf = exports.upgradeThumbnail = exports.durationToSeconds = void 0;
const BULLET = '•';
const runsOf = (node) => {
    const runs = node?.runs ?? node?.text?.runs;
    return Array.isArray(runs) ? runs.map((run) => String(run?.text ?? '')) : [];
};
const columnText = (item, index) => runsOf(item?.flexColumns?.[index]?.musicResponsiveListItemFlexColumnRenderer).join('');
const segmentsOf = (item, index) => {
    const runs = runsOf(item?.flexColumns?.[index]?.musicResponsiveListItemFlexColumnRenderer);
    const segments = [];
    let current = '';
    for (const run of runs) {
        if (run.trim() === BULLET) {
            segments.push(current.trim());
            current = '';
            continue;
        }
        current += run;
    }
    if (current.trim())
        segments.push(current.trim());
    return segments.filter(Boolean);
};
const durationToSeconds = (value) => {
    const parts = value.trim().split(':');
    if (parts.length < 2 || parts.length > 3)
        return null;
    if (!parts.every((part) => /^\d+$/.test(part)))
        return null;
    return parts.reduce((total, part) => total * 60 + Number(part), 0);
};
exports.durationToSeconds = durationToSeconds;
const isDuration = (value) => (0, exports.durationToSeconds)(value) !== null;
const upgradeThumbnail = (url, size = 1000) => {
    if (!url)
        return '';
    if (/=w\d+-h\d+/.test(url))
        return url.replace(/=w\d+-h\d+/, `=w${size}-h${size}`);
    if (/i\.ytimg\.com\/vi\//.test(url))
        return url.replace(/\/[a-z]+default\.jpg/, '/maxresdefault.jpg');
    return url;
};
exports.upgradeThumbnail = upgradeThumbnail;
const thumbnailOf = (item, size = 1000) => {
    const thumbs = item?.thumbnail?.musicThumbnailRenderer?.thumbnail?.thumbnails ??
        item?.thumbnail?.croppedSquareThumbnailRenderer?.thumbnail?.thumbnails ??
        item?.thumbnailRenderer?.musicThumbnailRenderer?.thumbnail?.thumbnails ??
        item?.thumbnails ??
        [];
    if (!Array.isArray(thumbs) || thumbs.length === 0)
        return '';
    const largest = [...thumbs].sort((a, b) => (a?.width ?? 0) - (b?.width ?? 0)).pop();
    return (0, exports.upgradeThumbnail)(String(largest?.url ?? ''), size);
};
exports.thumbnailOf = thumbnailOf;
const videoIdOf = (item) => String(item?.playlistItemData?.videoId ??
    item?.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint
        ?.watchEndpoint?.videoId ??
    '');
const musicVideoTypeOf = (item) => {
    const endpoints = [
        item?.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint,
        item?.flexColumns?.[0]?.musicResponsiveListItemFlexColumnRenderer?.text?.runs?.[0]?.navigationEndpoint,
        item?.navigationEndpoint,
    ];
    for (const endpoint of endpoints) {
        const kind = endpoint?.watchEndpoint?.watchEndpointMusicSupportedConfigs?.watchEndpointMusicConfig?.musicVideoType;
        if (kind)
            return String(kind);
    }
    return '';
};
exports.musicVideoTypeOf = musicVideoTypeOf;
const isAlbumAudio = (musicVideoType) => String(musicVideoType ?? '') === 'MUSIC_VIDEO_TYPE_ATV';
exports.isAlbumAudio = isAlbumAudio;
const browseIdOf = (item) => String(item?.navigationEndpoint?.browseEndpoint?.browseId ??
    item?.overlay?.musicItemThumbnailOverlayRenderer?.content?.musicPlayButtonRenderer?.playNavigationEndpoint
        ?.watchPlaylistEndpoint?.playlistId ??
    '');
const yearOf = (segments) => {
    const year = segments.find((segment) => /^(19|20)\d{2}$/.test(segment.trim()));
    return year ? Number(year) : null;
};
const linkedIdsOf = (item) => {
    const found = {};
    for (const column of item?.flexColumns ?? []) {
        for (const run of column?.musicResponsiveListItemFlexColumnRenderer?.text?.runs ?? []) {
            const endpoint = run?.navigationEndpoint?.browseEndpoint;
            const browseId = endpoint?.browseId;
            if (!browseId)
                continue;
            const pageType = String(endpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType ?? '');
            if (pageType === 'MUSIC_PAGE_TYPE_ARTIST' && !found.artistId)
                found.artistId = String(browseId);
            if (pageType === 'MUSIC_PAGE_TYPE_ALBUM' && !found.albumId)
                found.albumId = String(browseId);
        }
    }
    return found;
};
exports.linkedIdsOf = linkedIdsOf;
const isExplicitRow = (item) => (item?.badges ?? []).some((badge) => badge?.musicInlineBadgeRenderer?.icon?.iconType === 'MUSIC_EXPLICIT_BADGE');
exports.isExplicitRow = isExplicitRow;
const parseSearchItem = (item, type) => {
    if (!item)
        return null;
    const title = columnText(item, 0).trim();
    if (!title)
        return null;
    const segments = segmentsOf(item, 1);
    const cover = (0, exports.thumbnailOf)(item);
    if (type === 'artist') {
        const id = browseIdOf(item);
        if (!id)
            return null;
        return {
            id,
            title,
            artist: title,
            album: '',
            duration: '',
            type: 'artist',
            rawData: { ytmusic: true, browseId: id, cover, subscribers: segments[1] ?? '' },
        };
    }
    if (type === 'track') {
        const id = videoIdOf(item);
        if (!id)
            return null;
        const durationText = segments.find(isDuration) ?? '';
        const withoutDuration = segments.filter((segment) => !isDuration(segment));
        const artist = withoutDuration[0] ?? '';
        const album = withoutDuration.length > 1 ? withoutDuration[withoutDuration.length - 1] : '';
        return {
            id,
            title,
            artist,
            album,
            duration: durationText,
            type: 'track',
            rawData: {
                ytmusic: true,
                videoId: id,
                cover,
                durationSeconds: (0, exports.durationToSeconds)(durationText),
                artists: withoutDuration.slice(0, Math.max(1, withoutDuration.length - 1)),
                explicit: (0, exports.isExplicitRow)(item),
                musicVideoType: (0, exports.musicVideoTypeOf)(item),
                ...(0, exports.linkedIdsOf)(item),
            },
        };
    }
    const id = browseIdOf(item);
    if (!id)
        return null;
    if (type === 'album') {
        return {
            id,
            title,
            artist: segments.find((segment) => !/^(19|20)\d{2}$/.test(segment) && !/^(Album|Single|EP)$/i.test(segment)) ?? '',
            album: title,
            duration: '',
            year: yearOf(segments),
            type: 'album',
            rawData: { ytmusic: true, browseId: id, cover, segments, explicit: (0, exports.isExplicitRow)(item), ...(0, exports.linkedIdsOf)(item) },
        };
    }
    const countSegment = segments.find((segment) => /\d+\s+(song|track)/i.test(segment));
    const trackCount = countSegment ? Number(/\d+/.exec(countSegment)?.[0] ?? 0) : undefined;
    return {
        id,
        title,
        artist: segments.find((segment) => !/^Playlist$/i.test(segment) && segment !== countSegment) ?? 'YouTube Music',
        album: '',
        duration: '',
        type: 'playlist',
        ...(trackCount ? { trackCount } : {}),
        rawData: { ytmusic: true, browseId: id, cover, segments, explicit: (0, exports.isExplicitRow)(item), ...(0, exports.linkedIdsOf)(item) },
    };
};
exports.parseSearchItem = parseSearchItem;
const parseSearch = (response, type, limit = 50) => {
    const sections = response?.contents?.tabbedSearchResultsRenderer?.tabs?.[0]?.tabRenderer?.content?.sectionListRenderer?.contents ??
        [];
    const results = [];
    for (const section of Array.isArray(sections) ? sections : []) {
        const rows = section?.musicShelfRenderer?.contents;
        if (!Array.isArray(rows))
            continue;
        for (const row of rows) {
            const parsed = (0, exports.parseSearchItem)(row?.musicResponsiveListItemRenderer, type);
            if (parsed)
                results.push(parsed);
            if (results.length >= limit)
                return results;
        }
    }
    return results;
};
exports.parseSearch = parseSearch;
const continuationOf = (response) => {
    const shelf = response?.contents?.tabbedSearchResultsRenderer?.tabs?.[0]?.tabRenderer?.content?.sectionListRenderer?.contents;
    const fromShelf = (Array.isArray(shelf) ? shelf : [])
        .map((section) => section?.musicShelfRenderer?.continuations?.[0]?.nextContinuationData?.continuation)
        .find(Boolean);
    if (fromShelf)
        return String(fromShelf);
    const continued = response?.continuationContents?.musicShelfContinuation;
    const fromContinued = continued?.continuations?.[0]?.nextContinuationData?.continuation;
    if (fromContinued)
        return String(fromContinued);
    const grid = response?.continuationContents?.gridContinuation ?? response?.continuationContents?.musicPlaylistShelfContinuation;
    const fromGrid = grid?.continuations?.[0]?.nextContinuationData?.continuation;
    return fromGrid ? String(fromGrid) : null;
};
exports.continuationOf = continuationOf;
const shelfContinuationOf = (response) => {
    const list = response?.contents?.singleColumnBrowseResultsRenderer?.tabs?.[0]?.tabRenderer?.content?.sectionListRenderer ??
        response?.continuationContents?.sectionListContinuation;
    const token = list?.continuations?.[0]?.nextContinuationData?.continuation;
    return token ? String(token) : null;
};
exports.shelfContinuationOf = shelfContinuationOf;
const parseSearchContinuation = (response, type, limit = 50) => {
    const rows = response?.continuationContents?.musicShelfContinuation?.contents;
    const results = [];
    for (const row of Array.isArray(rows) ? rows : []) {
        const parsed = (0, exports.parseSearchItem)(row?.musicResponsiveListItemRenderer, type);
        if (parsed)
            results.push(parsed);
        if (results.length >= limit)
            break;
    }
    return results;
};
exports.parseSearchContinuation = parseSearchContinuation;
const parseGrid = (response, artistName = '', limit = 100, artistBrowseId = '') => {
    const results = [];
    const seen = new Set();
    const take = (node) => {
        const card = parseCarouselCard(node, artistName, artistBrowseId);
        if (card && !seen.has(card.id)) {
            seen.add(card.id);
            results.push(card);
        }
    };
    const walk = (node) => {
        if (!node || typeof node !== 'object' || results.length >= limit)
            return;
        if (node.musicTwoRowItemRenderer) {
            take(node);
            return;
        }
        for (const key of Object.keys(node)) {
            const value = node[key];
            if (Array.isArray(value))
                value.forEach(walk);
            else if (value && typeof value === 'object')
                walk(value);
        }
    };
    walk(response?.contents ?? response?.continuationContents);
    return results;
};
exports.parseGrid = parseGrid;
const headerOf = (response) => {
    const sections = response?.contents?.twoColumnBrowseResultsRenderer?.tabs?.[0]?.tabRenderer?.content?.sectionListRenderer
        ?.contents ?? [];
    for (const section of Array.isArray(sections) ? sections : []) {
        const header = section?.musicResponsiveHeaderRenderer ?? section?.musicEditablePlaylistDetailHeaderRenderer;
        if (header)
            return header;
    }
    return response?.header?.musicDetailHeaderRenderer ?? null;
};
const trackRowsOf = (response) => {
    const sections = response?.contents?.twoColumnBrowseResultsRenderer?.secondaryContents?.sectionListRenderer?.contents ?? [];
    const rows = [];
    for (const section of Array.isArray(sections) ? sections : []) {
        const shelf = section?.musicShelfRenderer?.contents ?? section?.musicPlaylistShelfRenderer?.contents;
        if (Array.isArray(shelf))
            rows.push(...shelf);
    }
    return rows;
};
const fixedDurationOf = (item) => {
    const columns = item?.fixedColumns ?? [];
    for (const column of Array.isArray(columns) ? columns : []) {
        const text = runsOf(column?.musicResponsiveListItemFixedColumnRenderer).join('');
        if (isDuration(text))
            return text;
    }
    return '';
};
const parseCollectionTrack = (item, album, cover) => {
    if (!item)
        return null;
    const title = columnText(item, 0).trim();
    const id = videoIdOf(item);
    if (!title || !id)
        return null;
    const extras = [];
    const columnCount = Array.isArray(item?.flexColumns) ? item.flexColumns.length : 0;
    for (let index = 2; index < columnCount; index += 1) {
        const text = columnText(item, index).trim();
        if (text)
            extras.push(text);
    }
    const duration = fixedDurationOf(item) || extras.find(isDuration) || '';
    const albumFromRow = extras.find((text) => !isDuration(text) && !/^[\d.,]+[KMB]?\s+\S+$/i.test(text)) ?? '';
    const trackNumber = Number(runsOf(item?.index).join('') || item?.index?.runs?.[0]?.text || 0) || null;
    return {
        id,
        title,
        artist: columnText(item, 1).trim(),
        album: album || albumFromRow,
        duration,
        type: 'track',
        rawData: {
            ytmusic: true,
            videoId: id,
            cover: (0, exports.thumbnailOf)(item) || cover,
            durationSeconds: (0, exports.durationToSeconds)(duration),
            ...(trackNumber ? { trackNumber } : {}),
            explicit: (0, exports.isExplicitRow)(item),
            musicVideoType: (0, exports.musicVideoTypeOf)(item),
            ...(0, exports.linkedIdsOf)(item),
        },
    };
};
exports.parseCollectionTrack = parseCollectionTrack;
const parseCollection = (response, id) => {
    const header = headerOf(response);
    let title = runsOf(header?.title).join('').trim();
    if (!title) {
        const named = trackRowsOf(response)
            .map((row) => (0, exports.parseCollectionTrack)(row?.musicResponsiveListItemRenderer, '', ''))
            .filter((track) => track !== null);
        const counts = new Map();
        for (const track of named) {
            const album = String(track.album ?? '').trim();
            if (album)
                counts.set(album, (counts.get(album) ?? 0) + 1);
        }
        const commonest = [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0];
        title = commonest || named[0]?.title || '';
    }
    if (!title)
        return null;
    const subtitle = runsOf(header?.subtitle);
    const secondSubtitle = runsOf(header?.secondSubtitle).join('');
    const subtitleText = subtitle.join('');
    const year = Number(/(19|20)\d{2}/.exec(subtitleText)?.[0] ?? 0) || null;
    const artist = runsOf(header?.straplineTextOne).join('').trim() ||
        subtitle
            .filter((run) => run.trim() && run.trim() !== BULLET)
            .slice(1)
            .find((run) => !/^(19|20)\d{2}$/.test(run.trim())) ||
        '';
    const artistId = String((header?.straplineTextOne?.runs ?? []).find((run) => run?.navigationEndpoint?.browseEndpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig
        ?.pageType === 'MUSIC_PAGE_TYPE_ARTIST')?.navigationEndpoint?.browseEndpoint?.browseId ?? '');
    const rows = trackRowsOf(response);
    const firstRow = rows[0]?.musicResponsiveListItemRenderer;
    const cover = (0, exports.thumbnailOf)(header) || (0, exports.thumbnailOf)(header?.thumbnail) || (0, exports.thumbnailOf)(firstRow);
    const artistName = artist || (0, exports.parseCollectionTrack)(firstRow, '', '')?.artist || '';
    const tracks = rows
        .map((row) => (0, exports.parseCollectionTrack)(row?.musicResponsiveListItemRenderer, title, cover))
        .filter((track) => track !== null)
        .map((track) => (track.artist ? track : { ...track, artist: artistName.trim() }))
        .map((track) => ({
        ...track,
        rawData: {
            ...track.rawData,
            ...(artistId && !track.rawData?.artistId ? { artistId } : {}),
            ...(!track.rawData?.albumId ? { albumId: id } : {}),
        },
    }));
    const declaredCount = Number(/(\d+)\s+(song|track)/i.exec(secondSubtitle)?.[1] ?? 0);
    return {
        id,
        title,
        artist: artistName.trim(),
        year,
        cover,
        trackCount: declaredCount || tracks.length,
        tracks,
    };
};
exports.parseCollection = parseCollection;
const parseCarouselCard = (node, artistName, artistBrowseId = '') => {
    const item = node?.musicTwoRowItemRenderer;
    if (!item)
        return null;
    const title = runsOf(item.title).join('').trim();
    const endpoint = item?.navigationEndpoint?.browseEndpoint;
    const browseId = String(endpoint?.browseId ?? '');
    if (!title || !browseId)
        return null;
    const pageType = String(endpoint?.browseEndpointContextSupportedConfigs?.browseEndpointContextMusicConfig?.pageType ?? '');
    const type = pageType === 'MUSIC_PAGE_TYPE_PLAYLIST' ? 'playlist' : pageType === 'MUSIC_PAGE_TYPE_ARTIST' ? 'artist' : 'album';
    const subtitle = runsOf(item.subtitle).join('');
    const year = Number(/(19|20)\d{2}/.exec(subtitle)?.[0] ?? 0) || null;
    return {
        id: browseId,
        title,
        artist: type === 'album' ? artistName : subtitle.split('•').slice(1).join('•').trim() || artistName,
        album: type === 'album' ? title : '',
        duration: '',
        year,
        type,
        rawData: {
            ytmusic: true,
            browseId,
            cover: (0, exports.thumbnailOf)(item),
            subtitle,
            ...(type === 'album' && artistBrowseId ? { artistId: artistBrowseId } : {}),
        },
    };
};
const parseArtist = (response, id) => {
    const sections = response?.contents?.singleColumnBrowseResultsRenderer?.tabs?.[0]?.tabRenderer?.content?.sectionListRenderer
        ?.contents ?? [];
    if (!Array.isArray(sections) || sections.length === 0)
        return null;
    const header = response?.header?.musicImmersiveHeaderRenderer ?? response?.header?.musicVisualHeaderRenderer ?? headerOf(response);
    const name = runsOf(header?.title).join('').trim();
    if (!name)
        return null;
    const topTracks = [];
    const releases = [];
    const seen = new Set();
    const more = {};
    for (const section of sections) {
        const shelfRows = section?.musicShelfRenderer?.contents;
        if (Array.isArray(shelfRows)) {
            for (const row of shelfRows) {
                const track = (0, exports.parseCollectionTrack)(row?.musicResponsiveListItemRenderer, '', '');
                if (track) {
                    if (!track.artist)
                        track.artist = name;
                    topTracks.push(track);
                }
            }
            continue;
        }
        const carousel = section?.musicCarouselShelfRenderer;
        const cards = carousel?.contents;
        if (Array.isArray(cards)) {
            let kind = null;
            for (const card of cards) {
                const release = parseCarouselCard(card, name, id);
                if (!release)
                    continue;
                kind = kind ?? release.type;
                if (!seen.has(release.id)) {
                    seen.add(release.id);
                    releases.push(release);
                }
            }
            const link = carousel?.header?.musicCarouselShelfBasicHeaderRenderer?.moreContentButton?.buttonRenderer?.navigationEndpoint
                ?.browseEndpoint;
            if (link?.browseId && (kind === 'album' || kind === 'playlist')) {
                const target = { browseId: String(link.browseId), params: link.params ? String(link.params) : undefined };
                const bucket = kind === 'album' ? 'albums' : 'playlists';
                more[bucket] = [...(more[bucket] ?? []), target];
            }
        }
    }
    return {
        id,
        name,
        cover: (0, exports.thumbnailOf)(header) || (0, exports.thumbnailOf)(header?.thumbnail?.musicThumbnailRenderer ? header.thumbnail : null),
        subscribers: runsOf(header?.subscriptionButton?.subscribeButtonRenderer?.subscriberCountText).join(''),
        topTracks,
        releases,
        more,
    };
};
exports.parseArtist = parseArtist;
const parseGenres = (response) => {
    const sections = response?.contents?.singleColumnBrowseResultsRenderer?.tabs?.[0]?.tabRenderer?.content?.sectionListRenderer
        ?.contents ?? [];
    const genres = [];
    for (const section of Array.isArray(sections) ? sections : []) {
        const grid = section?.gridRenderer;
        if (!grid)
            continue;
        const sectionName = runsOf(grid?.header?.gridHeaderRenderer?.title).join('').trim();
        for (const item of grid.items ?? []) {
            const button = item?.musicNavigationButtonRenderer;
            if (!button)
                continue;
            const name = runsOf(button.buttonText).join('').trim();
            const params = String(button?.clickCommand?.browseEndpoint?.params ?? '');
            if (!name || !params)
                continue;
            genres.push({ id: params, name, section: sectionName });
        }
    }
    return genres;
};
exports.parseGenres = parseGenres;
const parseShelves = (response, limitPerShelf = 20) => {
    const sections = response?.contents?.singleColumnBrowseResultsRenderer?.tabs?.[0]?.tabRenderer?.content?.sectionListRenderer
        ?.contents ??
        response?.continuationContents?.sectionListContinuation?.contents ??
        [];
    const shelves = [];
    for (const section of Array.isArray(sections) ? sections : []) {
        const carousel = section?.musicCarouselShelfRenderer;
        if (!carousel)
            continue;
        const title = runsOf(carousel?.header?.musicCarouselShelfBasicHeaderRenderer?.title).join('').trim();
        const items = [];
        for (const card of carousel.contents ?? []) {
            const item = card?.musicTwoRowItemRenderer;
            if (!item)
                continue;
            const name = runsOf(item.title).join('').trim();
            if (!name)
                continue;
            const browseId = String(item?.navigationEndpoint?.browseEndpoint?.browseId ?? '');
            const videoId = String(item?.navigationEndpoint?.watchEndpoint?.videoId ?? '');
            const id = browseId || videoId;
            if (!id)
                continue;
            const subtitle = runsOf(item.subtitle).join('').trim();
            const type = videoId ? 'track' : browseId.startsWith('MPRE') ? 'album' : 'playlist';
            items.push({
                id,
                title: name,
                artist: subtitle,
                album: type === 'album' ? name : '',
                duration: '',
                type,
                rawData: { ytmusic: true, cover: (0, exports.thumbnailOf)(item), subtitle, ...(videoId ? { videoId } : { browseId }) },
            });
            if (items.length >= limitPerShelf)
                break;
        }
        if (items.length > 0)
            shelves.push({ title, items });
    }
    return shelves;
};
exports.parseShelves = parseShelves;
