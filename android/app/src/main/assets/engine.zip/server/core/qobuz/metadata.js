"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeMetadataFlac = exports.downloadAlbumCover = exports.addTrackTags = void 0;
const axios_1 = __importDefault(require("axios"));
const metadata_options_1 = require("../../lib/metadata-options");
const metaflac_js_1 = __importDefault(require("../lib/metaflac-js"));
const fast_lru_1 = __importDefault(require("../lib/fast-lru"));
const index_1 = require("./index");
const node_id3_1 = __importDefault(require("node-id3"));
const cover_art_1 = require("../../lib/cover-art");
const metadata_extra_1 = require("../../lib/metadata-extra");
async function writeMetadataMp3(buffer, track, cover) {
    const performerName = track.performer?.name || 'Unknown Artist';
    const albumArtistName = track.album?.artist?.name || performerName;
    const genreName = track.album?.genre?.name;
    const labelName = track.album?.label?.name;
    const composerName = track.composer?.name || '';
    const releaseDate = track.album?.release_date_original || track.release_date_original;
    const releaseYear = releaseDate ? new Date(releaseDate).getFullYear().toString() : '';
    const tags = {
        title: track.title,
        artist: performerName,
        album: track.album?.title,
        year: releaseYear,
        originalReleaseTime: track.album?.release_date_original,
        trackNumber: track.track_number.toString(),
        genre: genreName,
        performerInfo: albumArtistName,
        mediaType: 'Digital Media',
        copyright: track.copyright || undefined,
        publisher: labelName,
        date: track.album?.release_date_original,
        length: track.duration.toString(),
        musicianCreditsList: track.performers,
        composer: composerName,
        ISRC: track.isrc,
        partOfSet: track.media_number ? String(track.media_number) : undefined,
        encodedBy: metadata_extra_1.ENCODED_BY,
        subtitle: (0, metadata_extra_1.cleanVersion)(track.version) ?? undefined,
        TXXX: [
            {
                description: 'Explicit',
                value: track.parental_warning ? '1' : '0',
            },
            {
                description: 'Track Total',
                value: track.album?.tracks_count
                    ? track.album.tracks_count.toLocaleString('en-US', { minimumIntegerDigits: 2 })
                    : '0',
            },
            {
                description: 'Release Type',
                value: track.album?.release_type || 'Unknown',
            },
            {
                description: 'COMPILATION',
                value: (0, metadata_extra_1.isCompilation)(albumArtistName) ? '1' : '0',
            },
            ...((0, metadata_extra_1.formatGain)(track.audio_info?.replaygain_track_gain)
                ? [{ description: 'replaygain_track_gain', value: (0, metadata_extra_1.formatGain)(track.audio_info.replaygain_track_gain) }]
                : []),
            ...((0, metadata_extra_1.formatPeak)(track.audio_info?.replaygain_track_peak)
                ? [{ description: 'replaygain_track_peak', value: (0, metadata_extra_1.formatPeak)(track.audio_info.replaygain_track_peak) }]
                : []),
        ],
    };
    if (cover) {
        tags.image = {
            mime: 'image/jpeg',
            type: { id: 3, name: 'front cover' },
            description: 'Cover',
            imageBuffer: cover,
        };
    }
    const taggedBuffer = node_id3_1.default.write(tags, buffer);
    if (!taggedBuffer) {
        throw new Error('Failed to write ID3 tags to the buffer');
    }
    return taggedBuffer;
}
const addTrackTags = async (trackBuffer, og_track, albumCoverSize = 1000, options = metadata_options_1.DEFAULT_METADATA_OPTIONS) => {
    const track = og_track;
    if (!track.album) {
        const fullData = await (0, index_1.getTrackInfo)(og_track.id);
        track.album = fullData.album;
    }
    let cover = null;
    if (track.album) {
        cover = await (0, exports.downloadAlbumCover)(track.album, albumCoverSize);
    }
    const isFlac = trackBuffer.slice(0, 4).toString('ascii') === 'fLaC';
    if (isFlac) {
        return (0, exports.writeMetadataFlac)(trackBuffer, track, albumCoverSize, cover, options);
    }
    else {
        return writeMetadataMp3(trackBuffer, track, cover);
    }
};
exports.addTrackTags = addTrackTags;
const lru = new fast_lru_1.default({
    maxSize: 50,
    ttl: 30 * 60000,
});
const downloadAlbumCover = async (album, albumCoverSize) => {
    const cache = lru.get(album.id + albumCoverSize);
    if (cache) {
        return cache;
    }
    try {
        const url = (0, cover_art_1.qobuzCoverUrl)(album.image, albumCoverSize) ?? album.image.large;
        const { data } = await axios_1.default.get(url, { responseType: 'arraybuffer' });
        lru.set(album.id + albumCoverSize, data);
        return data;
    }
    catch (err) {
        return null;
    }
};
exports.downloadAlbumCover = downloadAlbumCover;
const writeMetadataFlac = (buffer, track, dimension, cover, options = metadata_options_1.DEFAULT_METADATA_OPTIONS) => {
    const flac = new metaflac_js_1.default(buffer);
    const albumArtistName = track.album?.artist?.name || track.performer?.name || 'Unknown Artist';
    const releaseDate = track.album?.release_date_original || track.release_date_original;
    const releaseYear = releaseDate ? releaseDate.split('-')[0] : null;
    const genreName = track.album?.genre?.name;
    const labelName = track.album?.label?.name;
    const composerName = track.composer?.name;
    flac.setTag('TITLE=' + track.title);
    flac.setTag('ARTIST=' + (track.performer?.name || 'Unknown Artist'));
    flac.setTag('TRACKNUMBER=' + track.track_number.toLocaleString('en-US', { minimumIntegerDigits: 2 }));
    if (track.album) {
        flac.setTag('ALBUM=' + track.album.title);
        const TOTALTRACKS = track.album.tracks_count.toLocaleString('en-US', { minimumIntegerDigits: 2 });
        if (genreName) {
            flac.setTag('GENRE=' + genreName);
        }
        flac.setTag('TRACKTOTAL=' + TOTALTRACKS);
        flac.setTag('TOTALTRACKS=' + TOTALTRACKS);
        if (options.releaseType)
            flac.setTag('RELEASETYPE=' + track.album.release_type);
        flac.setTag('ALBUMARTIST=' + albumArtistName);
        if (options.barcode)
            flac.setTag('BARCODE=' + track.album.upc);
        if (labelName) {
            if (options.label)
                flac.setTag('LABEL=' + labelName);
        }
        if (track.album.release_date_original) {
            flac.setTag('DATE=' + track.album.release_date_original);
        }
        if (releaseYear) {
            flac.setTag('YEAR=' + releaseYear);
        }
        flac.setTag(`COMPILATION=${(0, metadata_extra_1.isCompilation)(albumArtistName) ? '1' : '0'}`);
        flac.setTag(`UPC=${track.album.upc}`);
    }
    if (track.album?.media_count) {
        flac.setTag('TOTALDISCS=' + track.album.media_count);
        flac.setTag('DISCNUMBER=' + track.media_number);
    }
    if (options.isrc)
        flac.setTag('ISRC=' + track.isrc);
    flac.setTag('LENGTH=' + track.duration);
    if (options.media)
        flac.setTag('MEDIA=Digital Media');
    const gain = (0, metadata_extra_1.formatGain)(track.audio_info?.replaygain_track_gain);
    if (gain) {
        if (options.replayGain)
            flac.setTag('REPLAYGAIN_TRACK_GAIN=' + gain);
    }
    const peak = (0, metadata_extra_1.formatPeak)(track.audio_info?.replaygain_track_peak);
    if (peak) {
        if (options.replayGain)
            flac.setTag('REPLAYGAIN_TRACK_PEAK=' + peak);
    }
    if (track.copyright) {
        if (options.copyright)
            flac.setTag('COPYRIGHT=' + track.copyright);
    }
    const version = (0, metadata_extra_1.cleanVersion)(track.version);
    if (version) {
        flac.setTag('VERSION=' + version);
        flac.setTag('SUBTITLE=' + version);
    }
    if (track.LYRICS?.LYRICS_TEXT) {
        flac.setTag('LYRICS=' + track.LYRICS.LYRICS_TEXT);
        flac.setTag('UNSYNCEDLYRICS=' + track.LYRICS.LYRICS_TEXT);
    }
    if (track.parental_warning) {
        if (options.explicit)
            flac.setTag('EXPLICIT=1');
    }
    if (composerName) {
        if (options.credits)
            flac.setTag('COMPOSER=' + composerName);
    }
    if (track.performers) {
        flac.setTag('DESCRIPTION=' + track.performers);
    }
    if (cover) {
        flac.importPicture(cover, dimension, 'image/jpeg');
    }
    if (options.provenance) {
        flac.setTag('SOURCE=Qobuz');
        flac.setTag('SOURCEID=' + track.id);
        flac.setTag('ENCODEDBY=' + metadata_extra_1.ENCODED_BY);
    }
    return flac.getBuffer();
};
exports.writeMetadataFlac = writeMetadataFlac;
