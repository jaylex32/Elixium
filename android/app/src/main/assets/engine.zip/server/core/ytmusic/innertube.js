"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.YtMusicClient = exports.fetchSession = exports.YtMusicError = exports.SEARCH_FILTERS = exports.USER_AGENT = exports.YTMUSIC_TIMEOUT_MS = void 0;
const axios_1 = __importDefault(require("axios"));
exports.YTMUSIC_TIMEOUT_MS = 15000;
const MUSIC_ORIGIN = 'https://music.youtube.com';
exports.USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36';
const TRANSIENT_ATTEMPTS = 3;
const BASE_BACKOFF_MS = 700;
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
exports.SEARCH_FILTERS = {
    track: 'EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D',
    album: 'EgWKAQIYAWoKEAkQBRAKEAMQBA%3D%3D',
    artist: 'EgWKAQIgAWoKEAkQBRAKEAMQBA%3D%3D',
    playlist: 'EgWKAQIoAWoKEAkQBRAKEAMQBA%3D%3D',
};
class YtMusicError extends Error {
    constructor(stage, message) {
        super(message);
        this.name = 'YtMusicError';
        this.stage = stage;
    }
}
exports.YtMusicError = YtMusicError;
const newClient = () => axios_1.default.create({
    timeout: exports.YTMUSIC_TIMEOUT_MS,
    headers: { 'User-Agent': exports.USER_AGENT, 'Accept-Language': 'en-US,en;q=0.9' },
});
const SESSION_TTL_MS = 6 * 60 * 60 * 1000;
const fetchSession = async (http = newClient()) => {
    const { data } = await http.get(MUSIC_ORIGIN + '/');
    const page = typeof data === 'string' ? data : '';
    const apiKey = /"INNERTUBE_API_KEY":"([^"]+)"/.exec(page)?.[1];
    const clientVersion = /"INNERTUBE_CLIENT_VERSION":"([^"]+)"/.exec(page)?.[1];
    const visitorData = /"VISITOR_DATA":"([^"]+)"/.exec(page)?.[1];
    if (!apiKey || !clientVersion) {
        throw new YtMusicError('session', 'Could not read YouTube Music’s client configuration — they have changed their player and this needs an update');
    }
    return { apiKey, clientVersion, visitorData: visitorData ?? '', fetchedAt: Date.now() };
};
exports.fetchSession = fetchSession;
class YtMusicClient {
    constructor(http = newClient(), now = () => Date.now()) {
        this.http = http;
        this.now = now;
        this.session = null;
        this.inFlight = null;
    }
    async ensureSession(force = false) {
        if (!force && this.session && this.now() - this.session.fetchedAt < SESSION_TTL_MS)
            return this.session;
        if (!this.inFlight) {
            this.inFlight = (0, exports.fetchSession)(this.http).finally(() => {
                this.inFlight = null;
            });
        }
        this.session = await this.inFlight;
        return this.session;
    }
    async call(endpoint, body, retry = true) {
        let lastError = null;
        for (let attempt = 0; attempt < TRANSIENT_ATTEMPTS; attempt += 1) {
            try {
                return await this.attempt(endpoint, body, retry);
            }
            catch (error) {
                lastError = error;
                const status = Number(error?.ytStatus ?? 0);
                const transient = status === 429 || status >= 500 || (!status && !(error instanceof YtMusicError));
                if (!transient || attempt === TRANSIENT_ATTEMPTS - 1)
                    throw error;
                const suggested = Number(error?.retryAfterSeconds ?? 0);
                const backoff = suggested > 0 ? Math.min(suggested * 1000, 30000) : BASE_BACKOFF_MS * 2 ** attempt;
                await pause(backoff + Math.floor(Math.random() * 250));
            }
        }
        throw lastError;
    }
    async attempt(endpoint, body, retry) {
        const session = await this.ensureSession();
        const response = await this.http.post(`${MUSIC_ORIGIN}/youtubei/v1/${endpoint}?key=${encodeURIComponent(session.apiKey)}`, {
            context: {
                client: {
                    clientName: 'WEB_REMIX',
                    clientVersion: session.clientVersion,
                    hl: 'en',
                    gl: 'US',
                    ...(session.visitorData ? { visitorData: session.visitorData } : {}),
                },
            },
            ...body,
        }, {
            headers: {
                'Content-Type': 'application/json',
                Origin: MUSIC_ORIGIN,
                Referer: MUSIC_ORIGIN + '/',
                ...(session.visitorData ? { 'X-Goog-Visitor-Id': session.visitorData } : {}),
            },
            validateStatus: () => true,
        });
        if (response.status === 400 && retry) {
            await this.ensureSession(true);
            return this.attempt(endpoint, body, false);
        }
        if (response.status !== 200) {
            const failure = new YtMusicError('request', `YouTube Music answered ${response.status} for ${endpoint}`);
            failure.ytStatus = response.status;
            const retryAfter = Number(response.headers?.['retry-after'] ?? 0);
            if (Number.isFinite(retryAfter) && retryAfter > 0)
                failure.retryAfterSeconds = retryAfter;
            throw failure;
        }
        return response.data;
    }
    search(query, type) {
        return this.call('search', { query, params: exports.SEARCH_FILTERS[type] });
    }
    searchContinuation(token) {
        return this.call('search', { continuation: token });
    }
    browse(browseId) {
        return this.call('browse', { browseId });
    }
    browseMore(browseId, params, continuation) {
        if (continuation)
            return this.call('browse', { continuation });
        return this.call('browse', { browseId, ...(params ? { params } : {}) });
    }
}
exports.YtMusicClient = YtMusicClient;
