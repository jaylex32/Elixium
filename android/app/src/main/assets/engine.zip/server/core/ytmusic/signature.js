"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.resolveThrottle = exports.resolveCipher = exports.solverFor = exports.clearPlayerCache = exports.loadSolver = exports.findUrlBuilder = exports.playerUrlFrom = exports.parseCipher = void 0;
const vm_1 = __importDefault(require("vm"));
const acorn = __importStar(require("acorn"));
const LOAD_TIMEOUT_MS = 30000;
const CALL_TIMEOUT_MS = 5000;
const parseCipher = (value) => {
    if (!value || !value.includes('s=') || !value.includes('url='))
        return null;
    const params = new URLSearchParams(value);
    const url = params.get('url');
    const s = params.get('s');
    if (!url || !s)
        return null;
    return { url, s, sp: params.get('sp') || 'signature' };
};
exports.parseCipher = parseCipher;
const playerUrlFrom = (watchPageHtml) => {
    const match = /"(\/s\/player\/[^"]+\/base\.js)"/.exec(watchPageHtml);
    return match ? 'https://www.youtube.com' + match[1] : null;
};
exports.playerUrlFrom = playerUrlFrom;
const walk = (node, visit, parent = null) => {
    if (!node || typeof node.type !== 'string')
        return;
    visit(node, parent);
    for (const key of Object.keys(node)) {
        if (key === 'type' || key === 'start' || key === 'end')
            continue;
        const value = node[key];
        if (Array.isArray(value))
            value.forEach((child) => walk(child, visit, node));
        else if (value && typeof value.type === 'string')
            walk(value, visit, node);
    }
};
const setsAlrYes = (node) => node.type === 'ExpressionStatement' &&
    node.expression?.type === 'CallExpression' &&
    node.expression.callee?.type === 'MemberExpression' &&
    node.expression.arguments?.length === 2 &&
    node.expression.arguments[0]?.type === 'Literal' &&
    node.expression.arguments[0].value === 'alr' &&
    node.expression.arguments[1]?.type === 'Literal' &&
    node.expression.arguments[1].value === 'yes';
const nameOf = (node, parent) => {
    if (node.id?.name)
        return node.id.name;
    if (parent?.type === 'AssignmentExpression' && parent.left?.type === 'Identifier')
        return parent.left.name;
    if (parent?.type === 'VariableDeclarator' && parent.id?.type === 'Identifier')
        return parent.id.name;
    return null;
};
const findUrlBuilder = (playerJs) => {
    let ast;
    try {
        ast = acorn.parse(playerJs, { ecmaVersion: 'latest' });
    }
    catch {
        return null;
    }
    const candidates = [];
    walk(ast, (node, parent) => {
        if (node.type !== 'FunctionExpression' && node.type !== 'FunctionDeclaration')
            return;
        if (!Array.isArray(node.body?.body))
            return;
        if (!node.body.body.some(setsAlrYes))
            return;
        const name = nameOf(node, parent);
        if (name)
            candidates.push({ name, node });
    });
    if (candidates.length === 0)
        return null;
    const builder = candidates.find((entry) => entry.node.params?.length === 3) ?? candidates[0];
    const found = builder;
    let scope = null;
    walk(ast, (node) => {
        if (node.type !== 'FunctionExpression' && node.type !== 'FunctionDeclaration')
            return;
        if (found.node.start <= node.start || found.node.end >= node.end)
            return;
        if (!scope || node.start > scope.start)
            scope = node;
    });
    const enclosing = scope;
    return { name: found.name, injectAt: enclosing ? enclosing.body.end - 1 : playerJs.length };
};
exports.findUrlBuilder = findUrlBuilder;
const SHIMS = [
    'if (typeof globalThis.XMLHttpRequest === "undefined") globalThis.XMLHttpRequest = {prototype:{}};',
    'globalThis.location = new URL("https://www.youtube.com/watch?v=elixium");',
    'if (typeof globalThis.document === "undefined") globalThis.document = Object.create(null);',
    'if (typeof globalThis.navigator === "undefined") globalThis.navigator = Object.create(null);',
    'if (typeof globalThis.self === "undefined") globalThis.self = globalThis;',
    'if (typeof globalThis.window === "undefined") globalThis.window = globalThis;',
].join('\n');
const loadSolver = (playerJs) => {
    const builder = (0, exports.findUrlBuilder)(playerJs);
    if (!builder)
        return null;
    const patched = playerJs.slice(0, builder.injectAt) +
        `;try{globalThis.__elixiumBuild=${builder.name}}catch(e){};` +
        playerJs.slice(builder.injectAt);
    const context = {
        URL,
        URLSearchParams,
        Math,
        JSON,
        Date,
        TextDecoder,
        TextEncoder,
        setTimeout,
        clearTimeout,
        setInterval,
        clearInterval,
    };
    context.globalThis = context;
    vm_1.default.createContext(context);
    try {
        new vm_1.default.Script(SHIMS + '\n' + patched).runInContext(context, { timeout: LOAD_TIMEOUT_MS });
    }
    catch {
        return null;
    }
    const build = context.__elixiumBuild;
    if (typeof build !== 'function')
        return null;
    const render = (urlObject) => {
        const proto = Object.getPrototypeOf(urlObject);
        const names = Object.keys(proto).concat(Object.getOwnPropertyNames(proto));
        for (const name of names) {
            if (['constructor', 'set', 'get', 'clone'].includes(name))
                continue;
            const method = urlObject[name];
            if (typeof method !== 'function')
                continue;
            try {
                const rendered = method.call(urlObject);
                if (typeof rendered === 'string' && rendered.startsWith('http'))
                    return rendered;
            }
            catch {
            }
        }
        return null;
    };
    return {
        buildUrl: ({ url, signature, signatureParam, n }) => {
            try {
                const script = new vm_1.default.Script('__elixiumBuild(__u, __p, __s)');
                context.__u = url;
                context.__p = signatureParam || 's';
                context.__s = signature ? encodeURIComponent(signature) : undefined;
                const built = script.runInContext(context, { timeout: CALL_TIMEOUT_MS });
                if (!built)
                    return null;
                if (n)
                    built.set.call(built, 'n', n);
                return render(built);
            }
            catch {
                return null;
            }
        },
    };
};
exports.loadSolver = loadSolver;
const parameterOf = (url, name) => {
    try {
        return new URL(url).searchParams.get(name) || undefined;
    }
    catch {
        return undefined;
    }
};
let cached = null;
const clearPlayerCache = () => {
    cached = null;
};
exports.clearPlayerCache = clearPlayerCache;
const solverFor = async (http, watchPageHtml) => {
    const url = (0, exports.playerUrlFrom)(watchPageHtml);
    if (!url)
        return null;
    if (cached && cached.url === url)
        return cached.solver;
    const response = await http.get(url, {
        timeout: LOAD_TIMEOUT_MS,
        headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
        },
    });
    const source = typeof response.data === 'string' ? response.data : '';
    const solver = source ? (0, exports.loadSolver)(source) : null;
    cached = { url, solver };
    return solver;
};
exports.solverFor = solverFor;
const resolveCipher = (cipher, solver) => {
    if (!solver)
        return null;
    return solver.buildUrl({
        url: cipher.url,
        signature: cipher.s,
        signatureParam: cipher.sp,
        n: parameterOf(cipher.url, 'n'),
    });
};
exports.resolveCipher = resolveCipher;
const resolveThrottle = (url, solver) => {
    if (!solver)
        return url;
    const n = parameterOf(url, 'n');
    if (!n)
        return url;
    return solver.buildUrl({ url, n }) || url;
};
exports.resolveThrottle = resolveThrottle;
