"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestPublicApi = exports.requestGet = exports.requestLight = exports.request = void 0;
const request_1 = __importDefault(require("../lib/request"));
const cache_1 = __importDefault(require("./cache"));
const request = async (body, method) => {
    const cacheKey = method + ':' + Object.entries(body).join(':');
    const cache = cache_1.default.get(cacheKey);
    if (cache) {
        return cache;
    }
    const { data: { error, results }, } = await request_1.default.post('/gateway.php', body, { params: { method } });
    if (Object.keys(results).length > 0) {
        cache_1.default.set(cacheKey, results);
        return results;
    }
    const errorMessage = Object.entries(error).join(', ');
    throw new Error(errorMessage);
};
exports.request = request;
const requestLight = async (body, method) => {
    const cacheKey = method + ':' + Object.entries(body).join(':');
    const cache = cache_1.default.get(cacheKey);
    if (cache) {
        return cache;
    }
    const { data: { error, results }, } = await request_1.default.post('https://www.deezer.com/ajax/gw-light.php', body, {
        params: { method, api_version: '1.0' },
    });
    if (Object.keys(results).length > 0) {
        cache_1.default.set(cacheKey, results);
        return results;
    }
    const errorMessage = Object.entries(error).join(', ');
    throw new Error(errorMessage);
};
exports.requestLight = requestLight;
const requestGet = async (method, params = {}, key = 'get_request') => {
    const cacheKey = method + key;
    const cache = cache_1.default.get(cacheKey);
    if (cache) {
        return cache;
    }
    const { data: { error, results }, } = await request_1.default.get('/gateway.php', { params: { method, ...params } });
    if (Object.keys(results).length > 0) {
        cache_1.default.set(cacheKey, results);
        return results;
    }
    const errorMessage = Object.entries(error).join(', ');
    throw new Error(errorMessage);
};
exports.requestGet = requestGet;
const requestPublicApi = async (slug) => {
    const cache = cache_1.default.get(slug);
    if (cache) {
        return cache;
    }
    const { data } = await request_1.default.get('https://api.deezer.com' + slug);
    if (data.error) {
        const errorMessage = Object.entries(data.error).join(', ');
        throw new Error(errorMessage);
    }
    cache_1.default.set(slug, data);
    return data;
};
exports.requestPublicApi = requestPublicApi;
