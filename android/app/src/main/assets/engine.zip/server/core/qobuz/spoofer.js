"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.QobuzSpoofer = exports.QOBUZ_BUNDLE_TIMEOUT_MS = void 0;
const axios_1 = __importDefault(require("axios"));
exports.QOBUZ_BUNDLE_TIMEOUT_MS = 15000;
class QobuzSpoofer {
    constructor(http) {
        this.seed_timezone_regex = /[a-z]\.initialSeed\("([\w=]+)",window\.utimezone\.([a-z]+)\)/g;
        this.info_extracts_regex = 'name:"\\w+/({timezones})",info:"([\\w=]+)",extras:"([\\w=]+)"';
        this.productionApi_regex = /production:\{api:\{appId:"(\d+)",appSecret:"([0-9a-f]{32})"\}/;
        this.legacyAppId_regex = /{app_id:"(\d{9})",app_secret:"\w{32}",base_port:"80",base_url:"https:\/\/www\.qobuz\.com",base_method:"\/api\.json\/0\.2\/"}/;
        this.anyApi_regex = /appId:"(\d{9})",appSecret:"([0-9a-f]{32})"/;
        this.bundle = '';
        this.app_id = null;
        this.app_secret = null;
        this.http =
            http ??
                axios_1.default.create({
                    timeout: exports.QOBUZ_BUNDLE_TIMEOUT_MS,
                    headers: {
                        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
                    },
                });
    }
    async init() {
        if (this.bundle.length > 0)
            return;
        const { data } = await this.http.get('https://play.qobuz.com/login');
        const bundle_url = data.match(/<script src="(\/resources\/\d+\.\d+\.\d+-[a-z]\d{3}\/bundle\.js)"><\/script>/);
        if (!bundle_url) {
            throw new Error('Failed to fetch Qobuz API data');
        }
        const bundle_data = await this.http.get('https://play.qobuz.com' + bundle_url[1]);
        this.bundle = bundle_data.data;
    }
    get_app_id() {
        if (this.app_id !== null)
            return this.app_id;
        const production = this.bundle.match(this.productionApi_regex);
        if (production) {
            this.app_id = +production[1];
            this.app_secret = production[2];
            return this.app_id;
        }
        const legacy = this.bundle.match(this.legacyAppId_regex);
        if (legacy) {
            this.app_id = +legacy[1];
            return this.app_id;
        }
        const any = this.bundle.match(this.anyApi_regex);
        if (any) {
            this.app_id = +any[1];
            this.app_secret = any[2];
        }
        return this.app_id;
    }
    get_secrets() {
        const published = [];
        if (this.app_id === null)
            this.get_app_id();
        if (this.app_secret)
            published.push(this.app_secret);
        const secrets = [];
        let match_tmp;
        while ((match_tmp = this.seed_timezone_regex.exec(this.bundle)) !== null) {
            const [seed, timezone] = [match_tmp[1], match_tmp[2]];
            secrets.push([timezone, seed]);
        }
        if (secrets.length > 1) {
            [secrets[0], secrets[1]] = [secrets[1], secrets[0]];
        }
        if (secrets.length === 0)
            return [...published];
        const re = new RegExp(this.info_extracts_regex.replace('{timezones}', secrets.map((t) => t[0].replace(/^\w/, (c) => c.toUpperCase())).join('|')), 'g');
        while ((match_tmp = re.exec(this.bundle)) !== null) {
            const [timezone, info, extras] = [match_tmp[1], match_tmp[2], match_tmp[3]];
            for (const s of secrets) {
                if (s[0] === timezone.toLowerCase()) {
                    s.push(info);
                    s.push(extras);
                }
            }
        }
        const final_secrets = [...published];
        for (let i = 0; i < secrets.length; i++) {
            if (secrets[i].length === 4) {
                const dec = Buffer.from(secrets[i][1] + secrets[i][2] + secrets[i][3], 'base64').toString('utf-8');
                if (!final_secrets.includes(dec))
                    final_secrets.push(dec);
            }
        }
        return final_secrets;
    }
}
exports.QobuzSpoofer = QobuzSpoofer;
