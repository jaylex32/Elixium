"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTrackLyrics = void 0;
const musixmatchLyrics_1 = require("./musixmatchLyrics");
const api_1 = require("../api");
const getTrackLyricsWeb = async (track) => {
    try {
        const LYRICS_TEXT = await (0, musixmatchLyrics_1.getLyricsMusixmatch)(`${track.ART_NAME} - ${track.SNG_TITLE}`);
        return { LYRICS_TEXT };
    }
    catch (err) {
        return null;
    }
};
const getTrackLyrics = async (track) => {
    if (track.LYRICS_ID > 0) {
        try {
            return await (0, api_1.getLyrics)(track.SNG_ID);
        }
        catch (err) {
            return await getTrackLyricsWeb(track);
        }
    }
    return await getTrackLyricsWeb(track);
};
exports.getTrackLyrics = getTrackLyrics;
