"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.verifyYouTubeSession = exports.cookieHeaderFromCookiesTxt = exports.CookiesTxtError = exports.YOUTUBE_SESSION_COOKIES = void 0;
exports.YOUTUBE_SESSION_COOKIES = [
    'SID',
    'HSID',
    'SSID',
    'APISID',
    'SAPISID',
    '__Secure-1PSID',
    '__Secure-3PSID',
    '__Secure-1PSIDTS',
    '__Secure-3PSIDTS',
    '__Secure-1PAPISID',
    '__Secure-3PAPISID',
    'LOGIN_INFO',
];
const REQUIRED_COOKIE = 'SAPISID';
class CookiesTxtError extends Error {
    constructor(message) {
        super(message);
        this.name = 'CookiesTxtError';
    }
}
exports.CookiesTxtError = CookiesTxtError;
const isYouTubeDomain = (domain) => {
    const host = domain
        .replace(/^#HttpOnly_/, '')
        .replace(/^\./, '')
        .toLowerCase();
    return (host === 'youtube.com' || host.endsWith('.youtube.com') || host === 'google.com' || host.endsWith('.google.com'));
};
const cookieHeaderFromCookiesTxt = (text) => {
    if (!text || !text.trim())
        throw new CookiesTxtError('The file was empty');
    const found = new Map();
    let ignored = 0;
    let sawAnyCookie = false;
    for (const rawLine of text.split(/\r?\n/)) {
        const line = rawLine.trim();
        if (!line)
            continue;
        if (line.startsWith('#') && !line.startsWith('#HttpOnly_'))
            continue;
        const fields = line.split('\t');
        const parts = fields.length >= 7 ? fields : line.split(/\s+/);
        if (parts.length < 7)
            continue;
        const domain = parts[0];
        const name = parts[parts.length - 2];
        const value = parts[parts.length - 1];
        if (!name || !value)
            continue;
        sawAnyCookie = true;
        if (!isYouTubeDomain(domain)) {
            ignored += 1;
            continue;
        }
        const isYouTube = /youtube\.com$/i.test(domain.replace(/^#HttpOnly_/, '').replace(/^\./, ''));
        if (!found.has(name) || isYouTube)
            found.set(name, value);
    }
    if (!sawAnyCookie) {
        throw new CookiesTxtError('That does not look like a cookies.txt file — no cookie lines were found. Export it with a cookies.txt browser extension.');
    }
    if (!found.get(REQUIRED_COOKIE)) {
        throw new CookiesTxtError('No YouTube session in that file. Sign in to youtube.com first, then export cookies.txt while signed in.');
    }
    const names = [...found.keys()].sort((a, b) => {
        const rank = (name) => {
            const index = exports.YOUTUBE_SESSION_COOKIES.indexOf(name);
            return index === -1 ? exports.YOUTUBE_SESSION_COOKIES.length : index;
        };
        return rank(a) - rank(b) || a.localeCompare(b);
    });
    return {
        cookie: names.map((name) => `${name}=${found.get(name)}`).join('; '),
        names,
        ignored,
    };
};
exports.cookieHeaderFromCookiesTxt = cookieHeaderFromCookiesTxt;
const verifyYouTubeSession = async (cookie, fetchPage) => {
    const load = fetchPage ??
        (async (value) => {
            const axios = require('axios');
            const response = await axios.get('https://www.youtube.com/', {
                timeout: 15000,
                validateStatus: () => true,
                headers: {
                    Cookie: value,
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36',
                },
            });
            return typeof response.data === 'string' ? response.data : '';
        });
    let page = '';
    try {
        page = await load(cookie);
    }
    catch {
        return null;
    }
    if (!page)
        return null;
    if (/"LOGGED_IN":true/.test(page)) {
        const account = /"accountName":"([^"]{1,60})"/.exec(page)?.[1];
        return { signedIn: true, ...(account ? { account } : {}) };
    }
    if (/"LOGGED_IN":false/.test(page))
        return { signedIn: false };
    return null;
};
exports.verifyYouTubeSession = verifyYouTubeSession;
