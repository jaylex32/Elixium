"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.remuxWebmToOgg = exports.writeOggOpus = exports.readWebmOpus = exports.packetSamples = void 0;
const OPUS_RATE = 48000;
const MAX_SEGMENTS = 255;
const EBML = {
    Segment: 0x18538067,
    Tracks: 0x1654ae6b,
    TrackEntry: 0xae,
    TrackNumber: 0xd7,
    CodecID: 0x86,
    CodecPrivate: 0x63a2,
    Cluster: 0x1f43b675,
    SimpleBlock: 0xa3,
    BlockGroup: 0xa0,
    Block: 0xa1,
};
const readVint = (data, at, keepMarker) => {
    const first = data[at];
    if (first === undefined || first === 0)
        return null;
    let length = 1;
    for (let mask = 0x80; mask > 0 && (first & mask) === 0; mask >>= 1)
        length += 1;
    if (length > 8 || at + length > data.length)
        return null;
    let value = keepMarker ? first : first & (0xff >> length);
    for (let i = 1; i < length; i += 1)
        value = value * 256 + data[at + i];
    return { value, length };
};
const walk = (data, start, end, visit) => {
    let at = start;
    while (at < end) {
        const id = readVint(data, at, true);
        if (!id)
            return;
        const size = readVint(data, at + id.length, false);
        if (!size)
            return;
        const from = at + id.length + size.length;
        const unknown = size.value === Math.pow(2, 7 * size.length) - 1;
        const to = unknown ? end : Math.min(from + size.value, end);
        if (to < from)
            return;
        visit(id.value, from, to);
        at = to;
    }
};
const packetSamples = (packet) => {
    if (packet.length < 1)
        return 0;
    const toc = packet[0];
    const config = toc >> 3;
    const tenths = [
        100, 200, 400, 600, 100, 200, 400, 600, 100, 200, 400, 600, 100, 200, 100, 200, 25, 50, 100, 200, 25, 50, 100, 200,
        25, 50, 100, 200, 25, 50, 100, 200,
    ][config];
    const code = toc & 0b11;
    let frames;
    if (code === 0)
        frames = 1;
    else if (code === 1 || code === 2)
        frames = 2;
    else
        frames = packet.length >= 2 ? packet[1] & 63 : 1;
    return Math.round((tenths * OPUS_RATE * frames) / 10000);
};
exports.packetSamples = packetSamples;
const readWebmOpus = (data) => {
    if (data.length < 4 || data[0] !== 0x1a || data[1] !== 0x45 || data[2] !== 0xdf || data[3] !== 0xa3)
        return null;
    let codec = '';
    let head = null;
    let track = 1;
    const packets = [];
    const readBlock = (from, to) => {
        const number = readVint(data, from, false);
        if (!number || number.value !== track)
            return;
        const flagsAt = from + number.length + 2;
        if (flagsAt >= to)
            return;
        const lacing = (data[flagsAt] >> 1) & 0b11;
        const payload = flagsAt + 1;
        if (payload >= to)
            return;
        if (lacing !== 0)
            return;
        packets.push(data.subarray(payload, to));
    };
    walk(data, 0, data.length, (id, from, to) => {
        if (id !== EBML.Segment)
            return;
        walk(data, from, to, (sid, sfrom, sto) => {
            if (sid === EBML.Tracks) {
                walk(data, sfrom, sto, (tid, tfrom, tto) => {
                    if (tid !== EBML.TrackEntry)
                        return;
                    walk(data, tfrom, tto, (eid, efrom, eto) => {
                        if (eid === EBML.CodecID)
                            codec = data.subarray(efrom, eto).toString('latin1').replace(/\0+$/, '');
                        if (eid === EBML.CodecPrivate)
                            head = data.subarray(efrom, eto);
                        if (eid === EBML.TrackNumber && eto > efrom)
                            track = data[efrom];
                    });
                });
            }
            if (sid === EBML.Cluster) {
                walk(data, sfrom, sto, (cid, cfrom, cto) => {
                    if (cid === EBML.SimpleBlock)
                        readBlock(cfrom, cto);
                    if (cid === EBML.BlockGroup) {
                        walk(data, cfrom, cto, (bid, bfrom, bto) => {
                            if (bid === EBML.Block)
                                readBlock(bfrom, bto);
                        });
                    }
                });
            }
        });
    });
    if (codec !== 'A_OPUS' || !head)
        return null;
    const header = head;
    if (header.length < 12 || header.subarray(0, 8).toString('latin1') !== 'OpusHead')
        return null;
    if (packets.length === 0)
        return null;
    return { head: header, packets, preSkip: header.readUInt16LE(10) };
};
exports.readWebmOpus = readWebmOpus;
const CRC_TABLE = (() => {
    const table = new Uint32Array(256);
    for (let i = 0; i < 256; i += 1) {
        let value = i << 24;
        for (let bit = 0; bit < 8; bit += 1) {
            value = value & 2147483648 ? ((value << 1) ^ 79764919) >>> 0 : (value << 1) >>> 0;
        }
        table[i] = value >>> 0;
    }
    return table;
})();
const oggCrc = (data) => {
    let crc = 0;
    for (const byte of data)
        crc = ((crc << 8) ^ CRC_TABLE[((crc >>> 24) ^ byte) & 0xff]) >>> 0;
    return crc >>> 0;
};
const buildPage = (lacing, body, granule, serial, sequence, flags) => {
    const page = Buffer.alloc(27 + lacing.length + body.length);
    page.write('OggS', 0, 'latin1');
    page.writeUInt8(0, 4);
    page.writeUInt8(flags, 5);
    if (granule < 0) {
        page.writeUInt32LE(4294967295, 6);
        page.writeUInt32LE(4294967295, 10);
    }
    else {
        page.writeUInt32LE(granule >>> 0, 6);
        page.writeUInt32LE(Math.floor(granule / 4294967296), 10);
    }
    page.writeUInt32LE(serial >>> 0, 14);
    page.writeUInt32LE(sequence >>> 0, 18);
    page.writeUInt32LE(0, 22);
    page.writeUInt8(lacing.length, 26);
    for (let i = 0; i < lacing.length; i += 1)
        page.writeUInt8(lacing[i], 27 + i);
    body.copy(page, 27 + lacing.length);
    page.writeUInt32LE(oggCrc(page), 22);
    return page;
};
const toSegments = (packets, startGranule, samples) => {
    const segments = [];
    let granule = startGranule;
    for (const packet of packets) {
        granule += samples(packet);
        let at = 0;
        let left = packet.length;
        while (left >= 255) {
            segments.push({ lacing: 255, data: packet.subarray(at, at + 255), granule: null });
            at += 255;
            left -= 255;
        }
        segments.push({ lacing: left, data: packet.subarray(at), granule });
    }
    return segments;
};
const pictureBlock = (image, mime) => {
    const description = Buffer.from('', 'utf8');
    const mimeBytes = Buffer.from(mime, 'latin1');
    const block = Buffer.alloc(32 + mimeBytes.length + description.length + image.length);
    let at = 0;
    block.writeUInt32BE(3, at);
    at += 4;
    block.writeUInt32BE(mimeBytes.length, at);
    at += 4;
    mimeBytes.copy(block, at);
    at += mimeBytes.length;
    block.writeUInt32BE(description.length, at);
    at += 4;
    at += description.length;
    for (const value of [0, 0, 0, 0]) {
        block.writeUInt32BE(value, at);
        at += 4;
    }
    block.writeUInt32BE(image.length, at);
    at += 4;
    image.copy(block, at);
    return block;
};
const buildTags = (tags) => {
    const comments = [];
    const add = (key, value) => {
        const text = value === null || value === undefined ? '' : String(value).trim();
        if (text)
            comments.push(`${key}=${text}`);
    };
    add('TITLE', tags.title);
    add('ARTIST', tags.artist);
    add('ALBUM', tags.album);
    add('ALBUMARTIST', tags.albumArtist);
    add('DATE', tags.year);
    add('TRACKNUMBER', tags.trackNumber);
    add('TRACKTOTAL', tags.trackTotal);
    add('COMMENT', tags.comment);
    if (tags.cover && tags.cover.length > 0) {
        const mime = tags.coverMime || (tags.cover[0] === 0x89 ? 'image/png' : 'image/jpeg');
        comments.push(`METADATA_BLOCK_PICTURE=${pictureBlock(tags.cover, mime).toString('base64')}`);
    }
    const vendor = Buffer.from('Elixium', 'utf8');
    const encoded = comments.map((comment) => Buffer.from(comment, 'utf8'));
    const size = 8 + 4 + vendor.length + 4 + encoded.reduce((total, c) => total + 4 + c.length, 0);
    const out = Buffer.alloc(size);
    let at = 0;
    out.write('OpusTags', at, 'latin1');
    at += 8;
    out.writeUInt32LE(vendor.length, at);
    at += 4;
    vendor.copy(out, at);
    at += vendor.length;
    out.writeUInt32LE(encoded.length, at);
    at += 4;
    for (const comment of encoded) {
        out.writeUInt32LE(comment.length, at);
        at += 4;
        comment.copy(out, at);
        at += comment.length;
    }
    return out;
};
const writeOggOpus = (stream, tags, serial = 1162627416) => {
    const pages = [];
    let sequence = 0;
    const emit = (segments, flags) => {
        const lacing = segments.map((segment) => segment.lacing);
        const body = Buffer.concat(segments.map((segment) => segment.data));
        let granule = -1;
        for (let i = segments.length - 1; i >= 0; i -= 1) {
            if (segments[i].granule !== null) {
                granule = segments[i].granule;
                break;
            }
        }
        pages.push(buildPage(lacing, body, granule, serial, sequence++, flags));
    };
    const writeHeader = (packet, first) => {
        const segments = toSegments([packet], 0, () => 0);
        for (let at = 0; at < segments.length; at += MAX_SEGMENTS) {
            const slice = segments.slice(at, at + MAX_SEGMENTS);
            const continued = at > 0 ? 0x01 : first ? 0x02 : 0x00;
            emit(slice.map((segment) => ({ ...segment, granule: segment.granule === null ? null : 0 })), continued);
        }
    };
    writeHeader(stream.head, true);
    writeHeader(buildTags(tags), false);
    const audio = toSegments(stream.packets, stream.preSkip, exports.packetSamples);
    for (let at = 0; at < audio.length; at += MAX_SEGMENTS) {
        const slice = audio.slice(at, at + MAX_SEGMENTS);
        const last = at + MAX_SEGMENTS >= audio.length;
        const continued = at > 0 && audio[at - 1].granule === null ? 0x01 : 0x00;
        emit(slice, continued | (last ? 0x04 : 0x00));
    }
    return Buffer.concat(pages);
};
exports.writeOggOpus = writeOggOpus;
const remuxWebmToOgg = (webm, tags) => {
    const stream = (0, exports.readWebmOpus)(webm);
    return stream ? (0, exports.writeOggOpus)(stream, tags) : null;
};
exports.remuxWebmToOgg = remuxWebmToOgg;
