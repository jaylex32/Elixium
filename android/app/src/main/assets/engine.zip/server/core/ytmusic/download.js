"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.downloadTrack = exports.tagFile = exports.fetchCover = exports.extensionFor = void 0;
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const axios_1 = __importDefault(require("axios"));
const player_1 = require("./player");
const ogg_opus_1 = require("./ogg-opus");
const mp4_udta_1 = require("./mp4-udta");
const extensionFor = (codec) => {
    if (codec === 'aac')
        return '.m4a';
    if (codec === 'opus')
        return '.opus';
    return '.bin';
};
exports.extensionFor = extensionFor;
const newClient = () => axios_1.default.create({ timeout: 60000, validateStatus: () => true });
const fetchCover = async (url, http) => {
    if (!url)
        return null;
    try {
        const response = await http.get(url, { responseType: 'arraybuffer', timeout: 30000 });
        if (response.status !== 200)
            return null;
        const buffer = Buffer.from(response.data);
        return buffer.length > 0 ? buffer : null;
    }
    catch {
        return null;
    }
};
exports.fetchCover = fetchCover;
const tagFile = (filePath, metadata, cover, report = true) => {
    let taglib;
    try {
        taglib = require('node-taglib-sharp');
    }
    catch (error) {
        console.log('Tagging unavailable: ' + (error?.message ?? error));
        return false;
    }
    try {
        const file = taglib.File.createFromPath(filePath);
        try {
            file.tag.title = metadata.title;
            file.tag.performers = metadata.artist ? [metadata.artist] : [];
            if (metadata.album)
                file.tag.album = metadata.album;
            if (metadata.albumArtist)
                file.tag.albumArtists = [metadata.albumArtist];
            if (metadata.year)
                file.tag.year = metadata.year;
            if (metadata.trackNumber)
                file.tag.track = metadata.trackNumber;
            if (metadata.trackTotal)
                file.tag.trackCount = metadata.trackTotal;
            if (metadata.comment && metadata.provenance !== false)
                file.tag.comment = metadata.comment;
            if (metadata.lyrics)
                file.tag.lyrics = metadata.lyrics;
            if (cover && cover.length > 0) {
                const picture = taglib.Picture.fromData(taglib.ByteVector.fromByteArray(cover));
                picture.type = taglib.PictureType.FrontCover;
                picture.mimeType = cover[0] === 0x89 ? 'image/png' : 'image/jpeg';
                file.tag.pictures = [picture];
            }
            file.save();
            return true;
        }
        finally {
            file.dispose();
        }
    }
    catch (error) {
        if (report)
            console.log('Could not tag ' + filePath + ': ' + (error?.message ?? error));
        return false;
    }
};
exports.tagFile = tagFile;
const pause = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
const tagWhenReady = async (filePath, metadata, cover, attempts = 6) => {
    for (let attempt = 0; attempt < attempts; attempt += 1) {
        if (fs_1.default.existsSync(filePath) && (0, exports.tagFile)(filePath, metadata, cover, attempt === attempts - 1))
            return true;
        await pause(250 * (attempt + 1));
    }
    return false;
};
const downloadTrack = async (videoId, metadata, outputBase, options = {}) => {
    const http = options.http ?? newClient();
    const stream = await (0, player_1.getAudioStream)(videoId, {
        cookie: options.cookie,
        preferOpus: options.preferOpus,
        http,
    });
    const filePath = outputBase + (0, exports.extensionFor)(stream.codec);
    fs_1.default.mkdirSync(path_1.default.dirname(filePath), { recursive: true });
    const CHUNK_SIZE = 1024 * 1024;
    const MAX_PARALLEL = 4;
    const headers = {
        ...(stream.userAgent ? { 'User-Agent': stream.userAgent } : {}),
        ...(options.cookie ? { Cookie: options.cookie } : {}),
    };
    const expected = stream.contentLength ?? 0;
    let audio;
    if (!expected) {
        const whole = await http.get(stream.url, { responseType: 'arraybuffer', timeout: 180000, headers });
        if (whole.status !== 200 && whole.status !== 206) {
            throw new player_1.PlayerError('network', `YouTube refused the audio stream (${whole.status})`);
        }
        audio = Buffer.from(whole.data);
    }
    else {
        const ranges = [];
        for (let start = 0; start < expected; start += CHUNK_SIZE) {
            ranges.push({ start, end: Math.min(start + CHUNK_SIZE - 1, expected - 1) });
        }
        const parts = new Array(ranges.length);
        let received = 0;
        let cursor = 0;
        const worker = async () => {
            for (;;) {
                const index = cursor++;
                if (index >= ranges.length)
                    return;
                const { start, end } = ranges[index];
                const part = await http.get(stream.url, {
                    responseType: 'arraybuffer',
                    timeout: 60000,
                    headers: { ...headers, Range: `bytes=${start}-${end}` },
                });
                if (part.status !== 206 && part.status !== 200) {
                    throw new player_1.PlayerError('network', `YouTube refused a chunk of the audio (${part.status})`);
                }
                const body = Buffer.from(part.data);
                if (part.status === 200 && body.length >= expected) {
                    parts.length = 1;
                    parts[0] = body;
                    cursor = ranges.length;
                    received = body.length;
                    options.onProgress?.(received, expected);
                    return;
                }
                parts[index] = body;
                received += body.length;
                options.onProgress?.(received, expected);
            }
        };
        await Promise.all(Array.from({ length: Math.min(MAX_PARALLEL, ranges.length) }, worker));
        audio = Buffer.concat(parts.filter(Boolean));
    }
    const received = audio.length;
    const total = expected || received;
    if (total && received < total * 0.98) {
        throw new player_1.PlayerError('network', `The download stopped early — ${received} of ${total} bytes`);
    }
    const cover = await (0, exports.fetchCover)(metadata.coverUrl, http);
    if (stream.codec === 'opus') {
        const ogg = (0, ogg_opus_1.remuxWebmToOgg)(audio, {
            title: metadata.title,
            artist: metadata.artist,
            album: metadata.album,
            albumArtist: metadata.albumArtist,
            year: metadata.year,
            trackNumber: metadata.trackNumber,
            trackTotal: metadata.trackTotal,
            comment: metadata.comment,
            cover,
        });
        if (ogg) {
            fs_1.default.writeFileSync(filePath, ogg);
            options.onProgress?.(received, total);
            return {
                path: filePath,
                bytes: received,
                itag: stream.itag,
                codec: stream.codec,
                bitrate: stream.bitrate,
                tagged: true,
            };
        }
    }
    const prepared = stream.codec === 'aac' ? (0, mp4_udta_1.ensureMetadataBox)(audio) : audio;
    fs_1.default.writeFileSync(filePath, prepared);
    options.onProgress?.(received, total);
    const tagged = await tagWhenReady(filePath, metadata, cover);
    return {
        path: filePath,
        bytes: received,
        itag: stream.itag,
        codec: stream.codec,
        bitrate: stream.bitrate,
        tagged,
    };
};
exports.downloadTrack = downloadTrack;
