"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addTrackTags = exports.getLyricsMusixmatch = exports.getTrackLyrics = void 0;
const abumCover_1 = require("./abumCover");
const getTrackLyrics_1 = require("./getTrackLyrics");
const id3_1 = require("./id3");
const flacmetata_1 = require("./flacmetata");
const api_1 = require("../api");
const metadata_options_1 = require("../../../lib/metadata-options");
var getTrackLyrics_2 = require("./getTrackLyrics");
Object.defineProperty(exports, "getTrackLyrics", { enumerable: true, get: function () { return getTrackLyrics_2.getTrackLyrics; } });
var musixmatchLyrics_1 = require("./musixmatchLyrics");
Object.defineProperty(exports, "getLyricsMusixmatch", { enumerable: true, get: function () { return musixmatchLyrics_1.getLyricsMusixmatch; } });
const albumInfo = async (track) => {
    try {
        return await (0, api_1.getAlbumInfoPublicApi)(track.ALB_ID);
    }
    catch (err) {
        return null;
    }
};
const trackTempo = async (track) => {
    try {
        const info = (await (0, api_1.getTrackInfoPublicApi)(String(track.SNG_ID)));
        const bpm = Number(info?.bpm ?? 0);
        return Number.isFinite(bpm) && bpm > 0 ? bpm : 0;
    }
    catch {
        return 0;
    }
};
const addTrackTags = async (trackBuffer, track, albumCoverSize = 1000, options = metadata_options_1.DEFAULT_METADATA_OPTIONS) => {
    const [cover, lyrics, album, bpm] = await Promise.all([
        (0, abumCover_1.downloadAlbumCover)(track, albumCoverSize),
        (0, getTrackLyrics_1.getTrackLyrics)(track),
        albumInfo(track),
        options.bpm ? trackTempo(track) : Promise.resolve(0),
    ]);
    if (bpm > 0)
        track.BPM = bpm;
    if (lyrics) {
        track.LYRICS = lyrics;
    }
    if (track.ART_NAME.toLowerCase() === 'various') {
        track.ART_NAME = 'Various Artists';
    }
    if (album && album.record_type) {
        album.record_type =
            album.record_type === 'ep' ? 'EP' : album.record_type.charAt(0).toUpperCase() + album.record_type.slice(1);
    }
    const isFlac = trackBuffer.slice(0, 4).toString('ascii') === 'fLaC';
    return isFlac
        ? (0, flacmetata_1.writeMetadataFlac)(trackBuffer, track, album, albumCoverSize, cover, options)
        : (0, id3_1.writeMetadataMp3)(trackBuffer, track, album, cover, options);
};
exports.addTrackTags = addTrackTags;
