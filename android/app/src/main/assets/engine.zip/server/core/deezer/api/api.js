"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getPlaylistChannel = exports.getShowInfo = exports.getChannelList = exports.getUser = exports.searchMusicPaged = exports.searchMusic = exports.searchAlternative = exports.getProfile = exports.getDiscography = exports.getArtistInfo = exports.getPlaylistTracks = exports.getPlaylistInfo = exports.getAlbumTracks = exports.getAlbumInfo = exports.getLyrics = exports.getTrackInfo = exports.getAlbumInfoPublicApi = exports.getTrackInfoPublicApi = void 0;
const request_1 = require("./request");
const getTrackInfoPublicApi = (sng_id) => (0, request_1.requestPublicApi)('/track/' + sng_id);
exports.getTrackInfoPublicApi = getTrackInfoPublicApi;
const getAlbumInfoPublicApi = (alb_id) => (0, request_1.requestPublicApi)('/album/' + alb_id);
exports.getAlbumInfoPublicApi = getAlbumInfoPublicApi;
const getTrackInfo = (sng_id) => (0, request_1.request)({ sng_id }, 'song.getData');
exports.getTrackInfo = getTrackInfo;
const getLyrics = (sng_id) => (0, request_1.request)({ sng_id }, 'song.getLyrics');
exports.getLyrics = getLyrics;
const getAlbumInfo = (alb_id) => (0, request_1.request)({ alb_id }, 'album.getData');
exports.getAlbumInfo = getAlbumInfo;
const getAlbumTracks = async (alb_id) => (0, request_1.request)({ alb_id, lang: 'us', nb: -1 }, 'song.getListByAlbum');
exports.getAlbumTracks = getAlbumTracks;
const getPlaylistInfo = (playlist_id) => (0, request_1.request)({ playlist_id, lang: 'en' }, 'playlist.getData');
exports.getPlaylistInfo = getPlaylistInfo;
const getPlaylistTracks = async (playlist_id) => {
    const playlistTracks = await (0, request_1.request)({ playlist_id, lang: 'en', nb: -1, start: 0, tab: 0, tags: true, header: true }, 'playlist.getSongs');
    playlistTracks.data = playlistTracks.data.map((track, index) => {
        track.TRACK_POSITION = index + 1;
        return track;
    });
    return playlistTracks;
};
exports.getPlaylistTracks = getPlaylistTracks;
const getArtistInfo = (art_id) => (0, request_1.request)({ art_id, filter_role_id: [0], lang: 'en', tab: 0, nb: -1, start: 0 }, 'artist.getData');
exports.getArtistInfo = getArtistInfo;
const getDiscography = (art_id, nb = 500) => (0, request_1.request)({ art_id, filter_role_id: [0], lang: 'en', nb, nb_songs: -1, start: 0 }, 'album.getDiscography');
exports.getDiscography = getDiscography;
const getProfile = (user_id) => (0, request_1.request)({ user_id, tab: 'loved', nb: -1 }, 'mobile.pageUser');
exports.getProfile = getProfile;
const searchAlternative = (artist, song, nb = 10) => (0, request_1.request)({
    query: `artist:'${artist}' track:'${song}'`,
    types: ['TRACK'],
    nb,
}, 'mobile_suggest');
exports.searchAlternative = searchAlternative;
const searchMusic = (query, types = ['TRACK'], nb = 15, start = 0) => (0, request_1.requestLight)({ query, start, nb, suggest: true, artist_suggest: true, top_tracks: true }, 'deezer.pageSearch');
exports.searchMusic = searchMusic;
const searchMusicPaged = (query, type = 'TRACK', nb = 50, start = 0) => (0, request_1.requestLight)({ query, start, nb, output: type, filter: 'ALL' }, 'search.music');
exports.searchMusicPaged = searchMusicPaged;
const getUser = async () => (0, request_1.requestGet)('user_getInfo');
exports.getUser = getUser;
const getChannelList = async () => (0, request_1.request)({}, 'search_getChannels');
exports.getChannelList = getChannelList;
const getShowInfo = (SHOW_ID, NB = 1000, START = 0) => (0, request_1.request)({
    SHOW_ID,
    NB,
    START,
}, 'mobile.pageShow');
exports.getShowInfo = getShowInfo;
const getPlaylistChannel = async (page) => {
    const gateway_input = {
        page,
        version: '2.3',
        support: {
            'long-card-horizontal-grid': ['album', 'playlist', 'radio', 'show'],
            ads: [],
            message: [],
            highlight: ['generic', 'album', 'artist', 'playlist', 'radio', 'app'],
            'deeplink-list': ['generic', 'deeplink'],
            grid: [
                'generic',
                'album',
                'artist',
                'playlist',
                'radio',
                'channel',
                'show',
                'page',
                'smarttracklist',
                'flow',
                'video-link',
            ],
            slideshow: ['album', 'artist', 'playlist', 'radio', 'show', 'channel', 'video-link', 'external-link'],
            'large-card': ['generic', 'album', 'artist', 'playlist', 'radio', 'show', 'external-link', 'video-link'],
            'item-highlight': ['radio', 'app'],
            'small-horizontal-grid': ['album', 'artist', 'playlist', 'radio', 'channel', 'show'],
            'grid-preview-two': [
                'generic',
                'album',
                'artist',
                'playlist',
                'radio',
                'channel',
                'show',
                'page',
                'smarttracklist',
                'flow',
                'video-link',
            ],
            list: ['generic', 'album', 'artist', 'playlist', 'radio', 'show', 'video-link', 'channel', 'episode'],
            'grid-preview-one': [
                'generic',
                'album',
                'artist',
                'playlist',
                'radio',
                'channel',
                'show',
                'page',
                'smarttracklist',
                'flow',
                'video-link',
            ],
            'horizontal-grid': [
                'generic',
                'album',
                'artist',
                'playlist',
                'radio',
                'channel',
                'show',
                'video-link',
                'smarttracklist',
                'flow',
            ],
        },
        lang: 'en',
        timezone_offset: '6',
    };
    return await (0, request_1.requestGet)('app_page_get', { gateway_input }, page);
};
exports.getPlaylistChannel = getPlaylistChannel;
