"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.writeMetadataFlac = void 0;
const metaflac_js_1 = __importDefault(require("../../lib/metaflac-js"));
const metadata_extra_1 = require("../../../lib/metadata-extra");
const metadata_options_1 = require("../../../lib/metadata-options");
const writeMetadataFlac = (buffer, track, album, dimension, cover, options = metadata_options_1.DEFAULT_METADATA_OPTIONS) => {
    const flac = new metaflac_js_1.default(buffer);
    const RELEASE_DATE = (0, metadata_extra_1.bestReleaseDate)(track, album);
    const RELEASE_YEAR = RELEASE_DATE ? RELEASE_DATE.split('-')[0] : null;
    flac.setTag('TITLE=' + track.SNG_TITLE);
    flac.setTag('ALBUM=' + track.ALB_TITLE);
    flac.setTag('ARTIST=' + track.ARTISTS.map((a) => a.ART_NAME).join(', '));
    flac.setTag('TRACKNUMBER=' + track.TRACK_NUMBER.toLocaleString('en-US', { minimumIntegerDigits: 2 }));
    if (album) {
        const TOTALTRACKS = album.nb_tracks.toLocaleString('en-US', { minimumIntegerDigits: 2 });
        if (album.genres.data.length > 0) {
            for (const genre of album.genres.data) {
                flac.setTag('GENRE=' + genre.name);
            }
        }
        flac.setTag('TRACKTOTAL=' + TOTALTRACKS);
        flac.setTag('TOTALTRACKS=' + TOTALTRACKS);
        if (options.releaseType)
            flac.setTag('RELEASETYPE=' + album.record_type);
        flac.setTag('ALBUMARTIST=' + album.artist.name);
        if (options.barcode && album.upc)
            flac.setTag('BARCODE=' + album.upc);
        if (options.label && album.label)
            flac.setTag('LABEL=' + album.label);
        if (RELEASE_DATE) {
            flac.setTag('DATE=' + RELEASE_DATE);
            flac.setTag('YEAR=' + RELEASE_YEAR);
        }
        if (options.compilation)
            flac.setTag(`COMPILATION=${(0, metadata_extra_1.isCompilation)(album.artist.name) ? '1' : '0'}`);
    }
    if (track.DISK_NUMBER) {
        flac.setTag('DISCNUMBER=' + track.DISK_NUMBER);
    }
    if (options.isrc && track.ISRC)
        flac.setTag('ISRC=' + track.ISRC);
    flac.setTag('LENGTH=' + track.DURATION);
    if (options.media)
        flac.setTag('MEDIA=Digital Media');
    if (track.LYRICS) {
        flac.setTag('LYRICS=' + track.LYRICS.LYRICS_TEXT);
    }
    if (options.explicit && track.EXPLICIT_LYRICS) {
        flac.setTag('EXPLICIT=' + track.EXPLICIT_LYRICS);
    }
    if (track.SNG_CONTRIBUTORS && !Array.isArray(track.SNG_CONTRIBUTORS)) {
        if (options.copyright && track.SNG_CONTRIBUTORS.main_artist) {
            flac.setTag(`COPYRIGHT=${RELEASE_YEAR ? RELEASE_YEAR + ' ' : ''}${track.SNG_CONTRIBUTORS.main_artist[0]}`);
        }
        if (options.credits && track.SNG_CONTRIBUTORS.publisher) {
            flac.setTag('ORGANIZATION=' + track.SNG_CONTRIBUTORS.publisher.join(', '));
        }
        if (options.credits && track.SNG_CONTRIBUTORS.composer) {
            flac.setTag('COMPOSER=' + track.SNG_CONTRIBUTORS.composer.join(', '));
        }
        if (options.credits && track.SNG_CONTRIBUTORS.publisher) {
            flac.setTag('ORGANIZATION=' + track.SNG_CONTRIBUTORS.publisher.join(', '));
        }
        if (options.credits && track.SNG_CONTRIBUTORS.producer) {
            flac.setTag('PRODUCER=' + track.SNG_CONTRIBUTORS.producer.join(', '));
        }
        if (options.credits && track.SNG_CONTRIBUTORS.engineer) {
            flac.setTag('ENGINEER=' + track.SNG_CONTRIBUTORS.engineer.join(', '));
        }
        if (options.credits && track.SNG_CONTRIBUTORS.writer) {
            flac.setTag('WRITER=' + track.SNG_CONTRIBUTORS.writer.join(', '));
        }
        if (options.credits && track.SNG_CONTRIBUTORS.author) {
            flac.setTag('AUTHOR=' + track.SNG_CONTRIBUTORS.author.join(', '));
        }
        if (options.credits && track.SNG_CONTRIBUTORS.mixer) {
            flac.setTag('MIXER=' + track.SNG_CONTRIBUTORS.mixer.join(', '));
        }
    }
    if (options.extraCredits && track.SNG_CONTRIBUTORS && !Array.isArray(track.SNG_CONTRIBUTORS)) {
        const alreadyWritten = [
            'main_artist',
            'publisher',
            'composer',
            'producer',
            'engineer',
            'writer',
            'author',
            'mixer',
        ];
        for (const [role, people] of Object.entries(track.SNG_CONTRIBUTORS)) {
            if (alreadyWritten.includes(role) || !Array.isArray(people) || people.length === 0)
                continue;
            flac.setTag(role.toUpperCase() + '=' + people.join(', '));
        }
    }
    const bpm = Number(track.BPM ?? 0);
    if (options.bpm && Number.isFinite(bpm) && bpm > 0) {
        flac.setTag('BPM=' + Math.round(bpm));
    }
    const gain = options.replayGain ? (0, metadata_extra_1.formatGain)(track.GAIN) : null;
    if (gain) {
        flac.setTag('REPLAYGAIN_TRACK_GAIN=' + gain);
    }
    const version = (0, metadata_extra_1.cleanVersion)(track.VERSION);
    if (version) {
        flac.setTag('VERSION=' + version);
        flac.setTag('SUBTITLE=' + version);
    }
    if (cover) {
        flac.importPicture(cover, dimension, 'image/jpeg');
    }
    if (options.provenance) {
        flac.setTag('SOURCE=Deezer');
        flac.setTag('SOURCEID=' + track.SNG_ID);
        flac.setTag('ENCODEDBY=' + metadata_extra_1.ENCODED_BY);
    }
    return flac.getBuffer();
};
exports.writeMetadataFlac = writeMetadataFlac;
