"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getTrackDownloadUrl = exports.qobuzRequest = exports.initQobuzApi = exports.qobuzLogin = exports.qobuzInstance = exports.InvalidSecret = exports.QobuzError = void 0;
const axios_1 = __importDefault(require("axios"));
const cache_1 = __importDefault(require("./cache"));
const crypto_1 = __importDefault(require("crypto"));
let secret = null;
const m3u8 = [];
class QobuzError extends Error {
    constructor(code, message) {
        super();
        this.name = 'Qobuz API error';
        this.message = `${message} (code: ${code})`;
    }
}
exports.QobuzError = QobuzError;
class InvalidSecret extends QobuzError {
    constructor(message) {
        super(400, message);
        this.name = 'Invalid secret';
    }
}
exports.InvalidSecret = InvalidSecret;
exports.qobuzInstance = axios_1.default.create({
    baseURL: 'https://www.qobuz.com/api.json/0.2/',
    withCredentials: true,
    timeout: 15000,
    headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:83.0) Gecko/20100101 Firefox/83.0',
    },
});
const qobuzLogin = async (email, password, app_id) => {
    const { data } = await exports.qobuzInstance.get('/user/login', {
        params: {
            email,
            password,
            app_id,
        },
    });
    if (!data.user.credential?.parameters) {
        throw new Error('Free accounts are not eligible to download tracks.');
    }
    return data.user_auth_token;
};
exports.qobuzLogin = qobuzLogin;
const initQobuzApi = async (token, app_id, secrets) => {
    if (token) {
        exports.qobuzInstance.defaults.headers.common['X-User-Auth-Token'] = token;
    }
    else {
        delete exports.qobuzInstance.defaults.headers.common['X-User-Auth-Token'];
    }
    if (app_id === null || app_id === undefined || Number.isNaN(Number(app_id))) {
        throw new Error('Qobuz app id is missing — it could not be read from Qobuz and none is configured');
    }
    exports.qobuzInstance.defaults.headers.common['X-App-Id'] = app_id.toString();
    let lastFailure = null;
    for (const s of secrets) {
        const result = await test_secret(s);
        if (result.ok) {
            secret = s;
            break;
        }
        lastFailure = result.error;
    }
    if (!secret) {
        const rejected = lastFailure?.response?.status;
        if (rejected === 401 || rejected === 403) {
            const error = new Error('Qobuz rejected your credentials: the Qobuz Token may have expired, or may not match the Qobuz App ID in Settings');
            error.response = { status: rejected };
            throw error;
        }
        const transport = transportCodeOf(lastFailure);
        if (transport) {
            const error = new Error(`Could not reach Qobuz to verify its app secret (${transport})`);
            error.code = transport;
            throw error;
        }
        if (secrets.length === 0) {
            throw new Error('No Qobuz app secrets are configured, and none could be read from Qobuz');
        }
        throw new Error("Couldn't find any valid app secrets");
    }
};
exports.initQobuzApi = initQobuzApi;
const qobuzRequest = async (method, params) => {
    const cacheKey = method + ':' + Object.entries(params).join(':');
    const cache = cache_1.default.get(cacheKey);
    if (cache) {
        return cache;
    }
    try {
        const { data } = await exports.qobuzInstance.get(method, { params });
        if (Object.keys(data).length > 0) {
            cache_1.default.set(cacheKey, data);
            return data;
        }
    }
    catch (error) {
        if (!error?.response)
            throw error;
        const response = error.response;
        const errorMessage = response?.data || {};
        if (method === 'track/getFileUrl' &&
            String(errorMessage.message || '')
                .toLowerCase()
                .includes('invalid api secret')) {
            throw new InvalidSecret(errorMessage.message);
        }
        const qobuzError = new QobuzError(errorMessage.code ?? 0, errorMessage.message ?? 'Qobuz request failed');
        qobuzError.response = { status: response?.status };
        throw qobuzError;
    }
};
exports.qobuzRequest = qobuzRequest;
const getTrackDownloadUrl = async (track_id, quality, sec = null) => {
    const allowed_formats = [5, 6, 7, 27];
    if (!allowed_formats.includes(quality)) {
        throw new Error(`Invalid format ${quality}`);
    }
    const final_secret = sec ? sec : secret;
    const unix = Math.floor(Date.now() / 1000);
    const r_sig = `trackgetFileUrlformat_id${quality}intentstreamtrack_id${track_id}${unix}${final_secret}`;
    const r_sig_hashed = md5(r_sig);
    const params = {
        request_ts: unix,
        request_sig: r_sig_hashed,
        track_id,
        format_id: quality,
        intent: 'stream',
    };
    try {
        const res = await (0, exports.qobuzRequest)('track/getFileUrl', params);
        if (res.url) {
            const fileSize = await testUrl(res.url);
            if (fileSize > 0) {
                return {
                    file_size: fileSize,
                    ...res,
                };
            }
        }
    }
    catch (e) {
        if (e instanceof InvalidSecret) {
            throw new Error('Invalid API secret');
        }
        else {
            throw e;
        }
    }
    return null;
};
exports.getTrackDownloadUrl = getTrackDownloadUrl;
const testUrl = async (url) => {
    try {
        const response = await axios_1.default.head(url);
        return Number(response.headers['content-length']);
    }
    catch (err) {
        return 0;
    }
};
const md5 = (data, type = 'ascii') => {
    const md5sum = crypto_1.default.createHash('md5');
    md5sum.update(data.toString(), type);
    return md5sum.digest('hex');
};
const test_secret = async (secret) => {
    try {
        await (0, exports.getTrackDownloadUrl)(122528702, 5, secret);
        return { ok: true };
    }
    catch (error) {
        if (process.env.DEBUG_QOBUZ) {
            console.error('Secret test failed:', error.message || error);
        }
        return { ok: false, error };
    }
};
const TRANSPORT_CODES = new Set([
    'ENOTFOUND',
    'EAI_AGAIN',
    'ECONNREFUSED',
    'ECONNRESET',
    'ENETUNREACH',
    'EHOSTUNREACH',
    'ETIMEDOUT',
    'ECONNABORTED',
]);
const transportCodeOf = (error) => {
    const code = error?.code;
    return typeof code === 'string' && TRANSPORT_CODES.has(code.toUpperCase()) ? code.toUpperCase() : null;
};
