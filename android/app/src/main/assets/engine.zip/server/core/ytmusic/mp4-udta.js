"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ensureMetadataBox = void 0;
const HANDLER = Buffer.from('00000021' + '68646c72' + '00000000' + '00000000' + '6d646972' + '6170706c' + '00000000' + '00000000' + '00', 'hex');
const EMPTY_ILST = Buffer.from([0x00, 0x00, 0x00, 0x08, 0x69, 0x6c, 0x73, 0x74]);
const buildUserDataBox = () => {
    const metaSize = 8 + 4 + HANDLER.length + EMPTY_ILST.length;
    const meta = Buffer.alloc(metaSize);
    meta.writeUInt32BE(metaSize, 0);
    meta.write('meta', 4, 'latin1');
    meta.writeUInt32BE(0, 8);
    HANDLER.copy(meta, 12);
    EMPTY_ILST.copy(meta, 12 + HANDLER.length);
    const udtaSize = 8 + meta.length;
    const udta = Buffer.alloc(udtaSize);
    udta.writeUInt32BE(udtaSize, 0);
    udta.write('udta', 4, 'latin1');
    meta.copy(udta, 8);
    return udta;
};
const readBoxes = (data, start, end) => {
    const boxes = [];
    let at = start;
    while (at + 8 <= end) {
        let size = data.readUInt32BE(at);
        let headerLength = 8;
        if (size === 1) {
            if (at + 16 > end)
                break;
            const large = data.readBigUInt64BE(at + 8);
            if (large > BigInt(Number.MAX_SAFE_INTEGER))
                break;
            size = Number(large);
            headerLength = 16;
        }
        else if (size === 0) {
            size = end - at;
        }
        if (size < headerLength || at + size > end)
            break;
        boxes.push({ type: data.subarray(at + 4, at + 8).toString('latin1'), start: at, headerLength, size });
        at += size;
    }
    return boxes;
};
const hasItemList = (data, box) => {
    for (const child of readBoxes(data, box.start + box.headerLength, box.start + box.size)) {
        if (child.type === 'ilst')
            return true;
        const from = child.start + child.headerLength + (child.type === 'meta' ? 4 : 0);
        if (child.type === 'meta' || child.type === 'udta') {
            for (const grand of readBoxes(data, from, child.start + child.size)) {
                if (grand.type === 'ilst')
                    return true;
            }
        }
    }
    return false;
};
const ensureMetadataBox = (data) => {
    const top = readBoxes(data, 0, data.length);
    const moov = top.find((box) => box.type === 'moov');
    if (!moov)
        return data;
    const insideMoov = readBoxes(data, moov.start + moov.headerLength, moov.start + moov.size);
    const existing = insideMoov.find((box) => box.type === 'udta');
    if (existing && hasItemList(data, existing))
        return data;
    const udta = buildUserDataBox();
    const insertAt = moov.start + moov.size;
    const out = Buffer.alloc(data.length + udta.length);
    data.copy(out, 0, 0, insertAt);
    udta.copy(out, insertAt);
    data.copy(out, insertAt + udta.length, insertAt);
    if (moov.headerLength === 16) {
        out.writeBigUInt64BE(BigInt(moov.size + udta.length), moov.start + 8);
    }
    else {
        out.writeUInt32BE(moov.size + udta.length, moov.start);
    }
    return out;
};
exports.ensureMetadataBox = ensureMetadataBox;
