"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.searchMusic = exports.getPlaylistTracks = exports.getArtistAlbums = exports.getArtistInfo = exports.getTrackInfo = exports.getAlbumInfo = void 0;
const request_1 = require("./request");
const getAlbumInfo = async (album_id) => (0, request_1.qobuzRequest)('album/get', { album_id });
exports.getAlbumInfo = getAlbumInfo;
const getTrackInfo = async (track_id) => (0, request_1.qobuzRequest)('track/get', { track_id });
exports.getTrackInfo = getTrackInfo;
const getArtistInfo = async (artist_id) => {
    return (0, request_1.qobuzRequest)('artist/get', { artist_id: artist_id, extra: 'albums' });
};
exports.getArtistInfo = getArtistInfo;
const getArtistAlbums = async (artist_id, options = {}) => {
    return (0, request_1.qobuzRequest)('artist/get', {
        artist_id: artist_id,
        extra: 'albums',
        offset: options.offset || 0,
        limit: options.limit || 25,
    });
};
exports.getArtistAlbums = getArtistAlbums;
const getPlaylistTracks = async (playlist_id, options = {}) => {
    return (0, request_1.qobuzRequest)('playlist/get', {
        playlist_id: playlist_id,
        extra: 'tracks',
        offset: options.offset || 0,
        limit: options.limit || 50,
    });
};
exports.getPlaylistTracks = getPlaylistTracks;
const searchMusic = async (query, type = 'track', limit = 28, offset = 0) => (0, request_1.qobuzRequest)(`${type}/search`, { query, limit, offset });
exports.searchMusic = searchMusic;
