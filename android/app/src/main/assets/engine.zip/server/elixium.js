#!/usr/bin/env node
"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const fs_1 = require("fs");
const metadata_options_1 = require("./lib/metadata-options");
const core_1 = require("./core");
const core_2 = require("./core");
const download_qobuz_track_1 = __importDefault(require("./lib/download-qobuz-track"));
const to_qobuz_parser_1 = require("./lib/to-qobuz-parser");
const p_queue_1 = __importDefault(require("p-queue"));
const true_case_path_1 = require("true-case-path");
const signale_1 = __importDefault(require("./lib/signale"));
const download_track_1 = __importDefault(require("./lib/download-track"));
const config_1 = __importDefault(require("./lib/config"));
const update_check_1 = __importDefault(require("./lib/update-check"));
const auto_updater_1 = __importDefault(require("./lib/auto-updater"));
const util_1 = require("./lib/util");
const package_json_1 = __importDefault(require("../package.json"));
const cli_1 = require("./app/cli");
const brand_1 = require("./app/brand");
const catalog_search_1 = require("./app/catalog-search");
const cli_downloads_1 = require("./app/cli-downloads");
const explorer_1 = require("./app/explorer");
const session_queue_1 = require("./app/session-queue");
const service_runtime_1 = require("./app/service-runtime");
const provider_readiness_1 = require("./app/provider-readiness");
const ytmusic_service_1 = require("./app/ytmusic-service");
const download_queue_runtime_1 = require("./app/download-queue-runtime");
const web_data_1 = require("./app/web-data");
const web_downloads_1 = require("./app/web-downloads");
const web_rest_1 = require("./app/web-rest");
const artist_content_1 = require("./app/artist-content");
const charts_1 = require("./app/charts");
const genre_content_1 = require("./app/genre-content");
const favorites_store_1 = require("./app/favorites-store");
const playlist_search_1 = require("./app/playlist-search");
const log_buffer_1 = require("./app/log-buffer");
const v1_1 = require("./app/api/v1");
const process_guard_1 = require("./app/process-guard");
const auth_1 = require("./app/api/auth");
const web_socket_catalog_1 = require("./app/web-socket-catalog");
const web_socket_direct_download_1 = require("./app/web-socket-direct-download");
const web_socket_discovery_1 = require("./app/web-socket-discovery");
const web_socket_media_1 = require("./app/web-socket-media");
const web_socket_operations_1 = require("./app/web-socket-operations");
const qobuz_watchlist_1 = require("./app/qobuz-watchlist");
const web_socket_watchlist_1 = require("./app/web-socket-watchlist");
const web_shell_1 = require("./app/web-shell");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const dotenv_1 = __importDefault(require("dotenv"));
const express_1 = __importDefault(require("express"));
const http_1 = require("http");
const socket_io_1 = require("socket.io");
const cors_1 = __importDefault(require("cors"));
dotenv_1.default.config({ path: path.join(path.dirname(process.execPath), '.env'), override: false });
dotenv_1.default.config({ override: false });
(0, process_guard_1.installProcessGuard)();
(0, log_buffer_1.installLogCapture)();
(0, cli_1.ensureLegacyNodeOptions)();
(0, cli_1.printBanner)(package_json_1.default.version);
const cmd = (0, cli_1.buildCommand)();
const options = cmd.parse(process.argv).opts();
if (!options.url && cmd.args[0]) {
    options.url = cmd.args[0];
}
if (!options.web) {
    if (options.headless && !options.quality) {
        console.error(signale_1.default.error('Missing parameters --quality'));
        console.error(signale_1.default.note('Quality must be provided with headless mode'));
        process.exit(1);
    }
    if (options.headless && !options.url && !options.inputFile) {
        console.error(signale_1.default.error('Missing parameters --url'));
        console.error(signale_1.default.note('URL must be provided with headless mode'));
        process.exit(1);
    }
}
const conf = new config_1.default(options.configFile);
if (conf.userConfigLocation) {
    console.log(signale_1.default.info('Configuration loaded'));
    console.log(signale_1.default.note(conf.userConfigLocation));
}
const shouldUseVariousArtists = (settings) => {
    const candidateKeys = [
        'useVariousArtists',
        'useVariousArtist',
        'playlistUseVariousArtists',
        'playlistUseVarious',
        'groupAsVariousArtists',
        'groupAsVarious',
    ];
    if (settings) {
        for (const key of candidateKeys) {
            if (Object.prototype.hasOwnProperty.call(settings, key) && settings[key] !== undefined) {
                const value = settings[key];
                if (typeof value === 'string') {
                    const normalized = value.trim().toLowerCase();
                    if (['false', '0', 'no', 'off'].includes(normalized)) {
                        return false;
                    }
                    if (['true', '1', 'yes', 'on'].includes(normalized)) {
                        return true;
                    }
                }
                return Boolean(value);
            }
        }
    }
    const configValue = conf.get?.('playlist.useVariousArtists');
    if (configValue !== undefined) {
        if (typeof configValue === 'string') {
            const normalized = configValue.trim().toLowerCase();
            if (['false', '0', 'no', 'off'].includes(normalized)) {
                return false;
            }
            if (['true', '1', 'yes', 'on'].includes(normalized)) {
                return true;
            }
        }
        return Boolean(configValue);
    }
    return false;
};
function getQobuzConfig() {
    try {
        const configPath = path.join(process.cwd(), brand_1.DEFAULT_CONFIG_FILE);
        if (!fs.existsSync(configPath)) {
            console.log(signale_1.default.warn(`No ${brand_1.DEFAULT_CONFIG_FILE} found. Using default settings.`));
            return null;
        }
        const configData = fs.readFileSync(configPath, 'utf8');
        const config = JSON.parse(configData);
        return config.qobuz;
    }
    catch (error) {
        console.log(signale_1.default.warn("Config file found but couldn't be read. Using defaults."));
        return null;
    }
}
let io;
let currentDownloadQueue = [];
let isDownloading = false;
let downloadProgress = 0;
const activeDownloads = new Map();
const queue = new p_queue_1.default({ concurrency: Number(options.concurrency || conf.get('concurrency')) });
const urlRegex = /https?:\/\/.*\w+\.\w+\/\w+/;
const onCancel = () => {
    console.info(signale_1.default.note('Aborted!'));
    process.exit();
};
let isDeezerInitialized = false;
let isQobuzInitialized = false;
let isDeezerDownloadReady = false;
let isQobuzDownloadReady = false;
const DEEZER_QUALITY_ALIASES = {
    '128': '128',
    mp3_128: '128',
    '128kbps': '128',
    '320': '320',
    mp3_320: '320',
    '320kbps': '320',
    flac: 'flac',
    lossless: 'flac',
};
const QOBUZ_QUALITY_ALIASES = {
    '5': '320kbps',
    '320': '320kbps',
    '320kbps': '320kbps',
    mp3: '320kbps',
    '6': '44khz',
    '44khz': '44khz',
    cd: '44khz',
    flac: '44khz',
    '7': '96khz',
    '96khz': '96khz',
    hifi: '96khz',
    '27': '192khz',
    '192khz': '192khz',
    studio: '192khz',
    hires: '192khz',
};
const normalizeQuality = (quality, service) => {
    const key = String(quality ?? '')
        .trim()
        .toLowerCase();
    if (service === 'deezer') {
        const mapped = DEEZER_QUALITY_ALIASES[key];
        if (mapped)
            return mapped;
        console.log(signale_1.default.warn(`Unrecognised Deezer quality "${quality}". Using 320.`));
        return '320';
    }
    if (service === 'qobuz') {
        const mapped = QOBUZ_QUALITY_ALIASES[key];
        if (mapped)
            return mapped;
        console.log(signale_1.default.warn(`Unrecognised Qobuz quality "${quality}". Using 320kbps.`));
        return '320kbps';
    }
    return quality;
};
const toStandardTrack = (track, service) => {
    if (service === 'deezer') {
        return {
            id: String(track.SNG_ID || track.id),
            title: String(track.SNG_TITLE || track.title || 'Unknown Track') + (track.VERSION ? ` ${track.VERSION}` : ''),
            artist: String(track.ART_NAME || track.artist?.name || 'Unknown Artist'),
            album: String(track.ALB_TITLE || track.album?.title || ''),
            duration: (0, util_1.formatSecondsReadable)(Number(track.DURATION || track.duration || 0)),
            year: track.PHYSICAL_RELEASE_DATE ? new Date(track.PHYSICAL_RELEASE_DATE).getFullYear() : null,
            type: 'track',
            rawData: track,
        };
    }
    return {
        id: String(track.id),
        title: String(track.title || 'Unknown Track') + (track.version ? ` (${track.version})` : ''),
        artist: String(track.performer?.name || track.artist?.name || 'Unknown Artist'),
        album: String(track.album?.title || ''),
        duration: (0, util_1.formatSecondsReadable)(Number(track.duration || 0)),
        year: track.album?.release_date_original ? new Date(track.album.release_date_original).getFullYear() : null,
        type: 'track',
        maximum_bit_depth: track.maximum_bit_depth,
        maximum_sampling_rate: track.maximum_sampling_rate,
        hires: track.hires,
        hires_streamable: track.hires_streamable,
        rawData: track,
    };
};
const setupWebServer = () => {
    const app = (0, express_1.default)();
    const server = (0, http_1.createServer)(app);
    io = new socket_io_1.Server(server, {
        cors: (0, auth_1.buildCorsOptions)(conf),
    });
    (0, log_buffer_1.attachLogBroadcast)(io);
    io.use((socket, next) => {
        const handshake = socket.handshake;
        const presented = (typeof handshake.auth?.token === 'string' && handshake.auth.token) ||
            (typeof handshake.query?.token === 'string' && handshake.query.token) ||
            '';
        const loopback = auth_1.LOOPBACK_ADDRESSES.has(handshake.address);
        const decision = (0, auth_1.authorize)(conf, presented, loopback);
        if (decision.ok) {
            next();
            return;
        }
        next(new Error(decision.reason === 'missing_token' ? 'auth_required' : 'auth_invalid'));
    });
    app.use((0, cors_1.default)((0, auth_1.buildCorsOptions)(conf)));
    app.use(express_1.default.json());
    app.use('/api', (0, auth_1.createAuthMiddleware)(conf, '/api'));
    const staticRootCandidates = [
        path.join(process.cwd(), 'public'),
        path.join(__dirname, 'public'),
        path.join(__dirname, '..', '..', 'public'),
    ].filter((candidate, index, list) => list.indexOf(candidate) === index);
    let cachedIndexHtmlPath;
    const findIndexHtml = () => {
        if (cachedIndexHtmlPath && (0, fs_1.existsSync)(cachedIndexHtmlPath))
            return cachedIndexHtmlPath;
        cachedIndexHtmlPath = staticRootCandidates
            .map((rootDir) => path.join(rootDir, 'index.html'))
            .find((candidate) => (0, fs_1.existsSync)(candidate));
        return cachedIndexHtmlPath;
    };
    app.get('/', (req, res) => {
        try {
            const indexHtmlPath = findIndexHtml();
            if (!indexHtmlPath) {
                throw new Error('No public/index.html found');
            }
            const htmlContent = (0, fs_1.readFileSync)(indexHtmlPath, 'utf8');
            res.setHeader('Content-Type', 'text/html');
            res.send(htmlContent);
        }
        catch (error) {
            const errorMessage = error instanceof Error ? error.message : 'Unknown error';
            console.log('Failed to read bundled HTML file:', errorMessage);
            res.send((0, web_shell_1.getDefaultWebShell)(brand_1.APP_BRAND));
        }
    });
    staticRootCandidates.forEach((rootDir) => {
        app.use(express_1.default.static(rootDir));
    });
    (0, web_rest_1.registerWebRestRoutes)({
        app,
        io,
        deezer: core_1.deezer,
        qobuz: core_1.qobuz,
        ytmusic: ytmusicService,
        artistContent,
        charts,
        genreContent,
        makeHttpRequest,
        favorites,
        playlistSearch,
        performDeezerSearch,
        performQobuzSearch,
        getDiscoveryContentRest,
        getItemTracksRest,
        initDeezerForDownload,
        initQobuzForSearch,
        initQobuzForDownload,
        startDownloadProcess,
    });
    (0, v1_1.registerApiV1)({
        app,
        io,
        conf,
        appVersion: package_json_1.default.version,
        appBrand: brand_1.APP_BRAND,
        resolveYtMusicStream: (videoId) => ytmusicService.streamUrl(videoId),
        resolveYtMusicLyrics: (videoId) => ytmusicService.lyrics(videoId),
        readiness: () => providers.snapshot(),
        retryProvider: (name) => providers.retry(name),
        deezer: core_1.deezer,
        qobuz: core_1.qobuz,
        performDeezerSearch,
        performQobuzSearch,
        getDiscoveryContentRest,
        getItemTracksRest,
        getAvailableGenres: () => qobuzWatchlist.getAvailableGenres(),
        initDeezerForDownload,
        refreshDeezerSession,
        initQobuzForSearch,
        initQobuzForDownload,
        startDownloadProcess,
        normalizeQuality,
        watchlist: qobuzWatchlist,
        activeDownloads,
        getCurrentDownloadQueue: () => currentDownloadQueue,
        getIsDownloading: () => isDownloading,
        parseToQobuz: to_qobuz_parser_1.parseToQobuz,
        parseDeezerUrl: core_2.parseInfo,
        ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
        settingsHooks: {
            setIsDeezerDownloadReady: (value) => {
                isDeezerDownloadReady = value;
            },
            setIsQobuzInitialized: (value) => {
                isQobuzInitialized = value;
            },
            setIsQobuzDownloadReady: (value) => {
                isQobuzDownloadReady = value;
            },
            setConcurrency: (value) => {
                queue.concurrency = value;
            },
        },
    });
    io.on('connection', (socket) => {
        console.log('Client connected:', socket.id);
        (0, web_socket_catalog_1.registerCatalogSocketHandlers)({
            socket,
            artistContent,
            performDeezerSearch,
            performQobuzSearch,
            ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
            parseToQobuz: to_qobuz_parser_1.parseToQobuz,
            parseDeezerUrl: core_2.parseInfo,
            resolveYtMusicUrl: (url) => ytmusicService.resolveUrl(url),
        });
        (0, web_socket_operations_1.registerOperationsSocketHandlers)({
            socket,
            conf,
            queue,
            signale: signale_1.default,
            normalizeQuality,
            startDownloadProcess,
            getCurrentDownloadQueue: () => currentDownloadQueue,
            activeDownloads,
            getIsDownloading: () => isDownloading,
            setIsDeezerDownloadReady: (value) => {
                isDeezerDownloadReady = value;
            },
            setIsQobuzInitialized: (value) => {
                isQobuzInitialized = value;
            },
            setIsQobuzDownloadReady: (value) => {
                isQobuzDownloadReady = value;
            },
        });
        (0, web_socket_media_1.registerMediaSocketHandlers)({
            socket,
            deezer: core_1.deezer,
            qobuz: core_1.qobuz,
            parseDeezerUrl: core_2.parseInfo,
            parseQobuzUrl: core_2.parseQobuzUrl,
            parseToQobuz: to_qobuz_parser_1.parseToQobuz,
            ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
            ensureDeezerDownloadReady: () => providers.ensure('deezer-download'),
        });
        (0, web_socket_direct_download_1.registerDirectDownloadSocketHandler)({
            socket,
            parseToQobuz: to_qobuz_parser_1.parseToQobuz,
            parseDeezerUrl: core_2.parseInfo,
            ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
            ensureQobuzDownloadReady: () => providers.ensure('qobuz-download'),
            ensureDeezerDownloadReady: () => providers.ensure('deezer-download'),
            shouldUseVariousArtists,
            downloadQobuzTracks,
            downloadDeezerTracks,
            resolveYtMusicUrl: (url) => ytmusicService.resolveUrl(url),
            downloadYtMusicTrack: (videoId, metadata, onProgress) => ytmusicService.downloadToLibrary(videoId, metadata, onProgress),
            matchYtMusicTracks: (tracks, preferred) => ytmusicService.resolveTracks(tracks, preferred),
            matchIntoYtMusic: (sources) => ytmusicService.matchToYtMusic(sources),
            createPlaylistFile,
        });
        (0, web_socket_discovery_1.registerDiscoverySocketHandler)({
            socket,
            getDiscoveryContent: getDiscoveryContentRest,
        });
        (0, web_socket_watchlist_1.registerWatchlistSocketHandlers)({
            socket,
            io,
            watchlist: qobuzWatchlist,
        });
    });
    server.requestTimeout = 15 * 60 * 1000;
    server.headersTimeout = 70 * 1000;
    server.keepAliveTimeout = 65 * 1000;
    const portFromFlag = cmd.getOptionValueSource?.('port') === 'cli' ? Number(options.port) : NaN;
    const portFromEnv = Number(process.env.PORT);
    const portFromConfig = Number(conf.get('port'));
    const port = [portFromFlag, portFromEnv, portFromConfig].find((value) => Number.isFinite(value) && value > 0) ?? 3000;
    const host = typeof options.host === 'string' && options.host.trim() ? options.host.trim() : undefined;
    const onListening = () => {
        providers.markCoreReady();
        console.log(signale_1.default.success(`Web interface available at http://localhost:${port}`));
        if (host) {
            console.log(signale_1.default.info(`Bound to ${host} only — not reachable from other devices`));
        }
        console.log(signale_1.default.info('Open this URL in your browser to use the GUI'));
    };
    if (host)
        server.listen(port, host, onListening);
    else
        server.listen(port, onListening);
    return server;
};
const { performDeezerSearch, performQobuzSearch } = (0, catalog_search_1.createCatalogSearch)({
    deezer: core_1.deezer,
    qobuz: core_1.qobuz,
    ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
});
const ytmusicService = (0, ytmusic_service_1.createYtMusicService)({
    search: (service, query, type, limit) => service === 'qobuz' ? performQobuzSearch(query, type, limit) : performDeezerSearch(query, type, limit),
    getCookie: () => conf.get('ytmusic.cookie') || undefined,
    setCookie: (cookie) => conf.set('ytmusic.cookie', cookie),
    getDownloadPath: () => conf.get('paths.ytmusic') || './Music/YouTube Music',
    getLayout: (kind) => {
        const specific = conf.get(`saveLayout.ytmusic-${kind ?? 'track'}`);
        return specific || conf.get('saveLayout.ytmusic') || undefined;
    },
    getNumberWidth: () => 2,
    preferOpus: () => String(conf.get('quality.ytmusic') || 'aac') === 'opus',
    preferAlbumAudio: () => conf.get('ytmusic.preferAlbumAudio') !== false,
    strictAlbumAudio: () => conf.get('ytmusic.strictAlbumAudio') === true,
    embedLyrics: () => conf.get('embedLyrics') !== false,
    saveLrcFile: () => Boolean(conf.get('saveLrcFile')),
    writeProvenance: () => conf.get('metadataCustom') === true ? (0, metadata_options_1.metadataSettingsFrom)(conf.get('metadata')).ytmusic.provenance : true,
});
const searchCatalog = (service, query, type, limit = 50, offset = 0) => service === 'deezer'
    ? performDeezerSearch(query, type, limit, offset)
    : performQobuzSearch(query, type, limit, offset);
const { promptGroupedSearchSelection, promptDeezerArtistAlbumSelection, promptQobuzArtistAlbumSelection, printExplorerIntro, describeQobuzTrack, promptTrackSubsetSelection, } = (0, explorer_1.createExplorer)({
    onCancel,
    searchCatalog,
    getDeezerArtistAlbums: async (artistId) => (await core_1.deezer.getDiscography(String(artistId), 200)).data,
    getQobuzArtistAlbums: async (artistId) => (await core_1.qobuz.getArtistAlbums(String(artistId))).albums.items,
});
const { buildDeezerQueuePreview, buildQobuzQueuePreview, collectSessionQueue, resolveDeezerQueueItem, resolveQobuzQueueItem, } = (0, session_queue_1.createSessionQueue)({
    onCancel,
    urlRegex,
    printExplorerIntro,
    promptGroupedSearchSelection,
    promptDeezerArtistAlbumSelection,
    promptQobuzArtistAlbumSelection,
    parseDeezerUrl: core_2.parseInfo,
    parseToQobuz: to_qobuz_parser_1.parseToQobuz,
});
const { startDownload, startQobuzDownload } = (0, cli_downloads_1.createCliDownloads)({
    options,
    conf,
    queue,
    urlRegex,
    normalizeQuality,
    collectSessionQueue,
    resolveDeezerQueueItem,
    resolveQobuzQueueItem,
    promptGroupedSearchSelection,
    promptDeezerArtistAlbumSelection,
    promptQobuzArtistAlbumSelection,
    promptTrackSubsetSelection,
    buildDeezerQueuePreview,
    buildQobuzQueuePreview,
    describeQobuzTrack,
    onCancel,
});
const { downloadQobuzTracks, downloadDeezerTracks, createPlaylistFile } = (0, web_downloads_1.createWebDownloads)({
    conf,
    qobuzDownloadTrack: download_qobuz_track_1.default,
    deezerDownloadTrack: download_track_1.default,
    commonPath: util_1.commonPath,
    sanitizeFilename: util_1.sanitizeFilename,
    trueCasePathSync: true_case_path_1.trueCasePathSync,
});
const { getDiscoveryContentRest, getItemTracksRest, makeHttpRequest } = (0, web_data_1.createWebData)({
    deezer: core_1.deezer,
    qobuz: core_1.qobuz,
    parseDeezerUrl: core_2.parseInfo,
    parseQobuzUrl: core_2.parseQobuzUrl,
    ensureDeezerDownloadReady: () => providers.ensure('deezer-download'),
    ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
    toStandardTrack,
    getQobuzConfig,
});
const artistContent = (0, artist_content_1.createArtistContent)({
    deezer: core_1.deezer,
    qobuz: core_1.qobuz,
    makeHttpRequest,
    ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
});
const charts = (0, charts_1.createCharts)({
    qobuz: core_1.qobuz,
    makeHttpRequest,
    ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
});
const genreContent = (0, genre_content_1.createGenreContent)({
    qobuz: core_1.qobuz,
    makeHttpRequest,
    ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
});
const playlistSearch = (0, playlist_search_1.createPlaylistSearch)({
    deezer: core_1.deezer,
    qobuz: core_1.qobuz,
    ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
    setSpotifyAnonymousToken: () => core_1.spotify.setSpotifyAnonymousToken(),
    getSpotifyApi: () => core_1.spotify.spotifyApi,
    getSpotifyCredentials: () => {
        try {
            const raw = fs.readFileSync(path.resolve(options.configFile), 'utf8');
            const cookies = JSON.parse(raw)?.cookies ?? {};
            return { clientId: cookies.spotifyClientId, clientSecret: cookies.spotifyClientSecret };
        }
        catch {
            return {};
        }
    },
});
const favorites = (0, favorites_store_1.createFavoritesStore)(path.join(path.dirname(path.resolve(options.configFile)), brand_1.FAVORITES_DATA_FILE));
const { startDownloadProcess } = (0, download_queue_runtime_1.createDownloadQueueRuntime)({
    conf,
    qobuz: core_1.qobuz,
    parseDeezerUrl: core_2.parseInfo,
    parseQobuzUrl: core_2.parseQobuzUrl,
    deezerDownloadTrack: download_track_1.default,
    qobuzDownloadTrack: download_qobuz_track_1.default,
    initDeezerForDownload: () => providers.ensure('deezer-download'),
    initQobuzForDownload: () => providers.ensure('qobuz-download'),
    shouldUseVariousArtists,
    commonPath: util_1.commonPath,
    sanitizeFilename: util_1.sanitizeFilename,
    trueCasePathSync: true_case_path_1.trueCasePathSync,
    activeDownloads,
    getIsDeezerDownloadReady: () => isDeezerDownloadReady,
    getIsQobuzDownloadReady: () => isQobuzDownloadReady,
    setIsDownloading: (value) => {
        isDownloading = value;
    },
    setCurrentDownloadQueue: (value) => {
        currentDownloadQueue = value;
    },
    setDownloadProgress: (value) => {
        downloadProgress = value;
    },
    clearActiveDownloads: () => {
        activeDownloads.clear();
    },
});
const qobuzWatchlist = (0, qobuz_watchlist_1.createQobuzWatchlistService)({
    conf,
    qobuz: core_1.qobuz,
    ensureQobuzSearchReady: () => providers.ensure('qobuz-search'),
    fetchDeezerArtistAlbums: async (artistId) => {
        const collected = [];
        for (let offset = 0; offset < 300; offset += 100) {
            const page = await artistContent.getArtistAlbums('deezer', artistId, 100, offset);
            collected.push(...page);
            if (page.length < 100)
                break;
        }
        return collected;
    },
    dispatchQueueItems: async (queueItems, options) => {
        if (!Array.isArray(queueItems) || !queueItems.length)
            return;
        const shouldAutoStart = Boolean(options?.autoStart);
        const canStartServerSide = shouldAutoStart && !isDownloading;
        if (io) {
            io.emit('watchlistQueueItems', {
                queueItems,
                autoStart: false,
            });
        }
        if (canStartServerSide) {
            const broadcastSocket = io
                ? {
                    emit: (event, payload) => {
                        io.emit(event, payload);
                    },
                }
                : undefined;
            const byService = new Map();
            for (const item of queueItems) {
                const service = String(item?.service || '').toLowerCase() === 'deezer' ? 'deezer' : 'qobuz';
                if (!byService.has(service))
                    byService.set(service, []);
                byService.get(service).push(item);
            }
            for (const [service, items] of byService) {
                if (service === 'deezer') {
                    await providers.ensure('deezer-download');
                    const quality = normalizeQuality((conf.get?.('quality.deezer') || 'flac'), 'deezer');
                    await startDownloadProcess(items, quality, 'deezer', {
                        deezerPath: conf.get?.('paths.deezer') || './Music/Deezer',
                        deezerDownloadCover: conf.get?.('deezerDownloadCover'),
                    }, broadcastSocket);
                }
                else {
                    await providers.ensure('qobuz-download');
                    const quality = normalizeQuality((conf.get?.('quality.qobuz') || '44khz'), 'qobuz');
                    await startDownloadProcess(items, quality, 'qobuz', {
                        qobuzPath: conf.get?.('paths.qobuz') || './Music/Qobuz',
                        qobuzDownloadCover: conf.get?.('qobuzDownloadCover'),
                    }, broadcastSocket);
                }
            }
        }
    },
    broadcastState: (state) => {
        if (!io)
            return;
        io.emit('watchlistState', state);
        io.emit('monitorSchedules', qobuzWatchlist.getMonitorSchedules());
        io.emit('monitorHistory', { items: qobuzWatchlist.getMonitorHistory() });
    },
});
const providers = new provider_readiness_1.ProviderRegistry({
    onEvent: ({ provider, state, failure }) => {
        if (state === 'ready') {
            console.log(signale_1.default.success(`${provider} ready`));
        }
        else if (state === 'unavailable' || state === 'failed') {
            console.log(signale_1.default.warn(`${provider} unavailable (${failure?.kind ?? 'unknown'}): ${failure?.message ?? ''}`));
        }
    },
});
const { initDeezerForSearch, initDeezerForDownload, refreshDeezerSession, initQobuzForSearch, initQobuzForDownload } = (0, service_runtime_1.createServiceRuntime)({
    options,
    conf,
    deezer: core_1.deezer,
    qobuz: core_1.qobuz,
    appCommand: brand_1.APP_COMMAND,
    getIsDeezerInitialized: () => isDeezerInitialized,
    setIsDeezerInitialized: (value) => {
        isDeezerInitialized = value;
    },
    getIsQobuzInitialized: () => isQobuzInitialized,
    setIsQobuzInitialized: (value) => {
        isQobuzInitialized = value;
    },
    getIsDeezerDownloadReady: () => isDeezerDownloadReady,
    setIsDeezerDownloadReady: (value) => {
        isDeezerDownloadReady = value;
    },
    getIsQobuzDownloadReady: () => isQobuzDownloadReady,
    setIsQobuzDownloadReady: (value) => {
        isQobuzDownloadReady = value;
    },
});
const QOBUZ_INIT_TIMEOUT_MS = 45000;
providers.register({
    name: 'qobuz-search',
    optional: true,
    timeoutMs: QOBUZ_INIT_TIMEOUT_MS,
    init: () => initQobuzForSearch(),
});
providers.register({
    name: 'qobuz-download',
    optional: true,
    timeoutMs: QOBUZ_INIT_TIMEOUT_MS,
    init: () => initQobuzForDownload(),
});
providers.register({
    name: 'deezer-download',
    optional: true,
    timeoutMs: 30000,
    init: () => initDeezerForDownload(),
});
providers.register({
    name: 'ytmusic',
    optional: true,
    timeoutMs: 20000,
    init: () => ytmusicService.check(),
});
const initApp = async () => {
    if (options.web) {
        console.log(signale_1.default.info('Initializing services for web interface...'));
        await initDeezerForSearch();
        setupWebServer();
        console.log(signale_1.default.info('Web interface ready - authentication only required for downloads'));
        providers.warmUpOptional();
        return;
    }
    if (options.setArl) {
        const configPath = conf.set('cookies.arl', options.setArl);
        console.log(signale_1.default.info('cookies.arl set to --> ' + options.setArl));
        console.log(signale_1.default.note(configPath));
        process.exit();
    }
    if (options.qobuz) {
        await initQobuzForSearch();
        await initQobuzForDownload();
    }
    else {
        await initDeezerForDownload();
    }
    const saveLayout = conf.get('saveLayout');
    if (options.inputFile) {
        const lines = (0, fs_1.readFileSync)(options.inputFile, 'utf-8').split(/\r?\n/);
        for await (const line of lines) {
            if (line && line.match(urlRegex)) {
                console.log(signale_1.default.info('Starting download: ' + line));
                if (options.qobuz) {
                    await startQobuzDownload(saveLayout, line.trim(), true);
                }
                else {
                    await startDownload(saveLayout, line.trim(), true);
                }
            }
        }
    }
    else {
        if (options.qobuz) {
            startQobuzDownload(saveLayout, options.url, false);
        }
        else {
            startDownload(saveLayout, options.url, false);
        }
    }
};
if (options.update) {
    (0, auto_updater_1.default)(package_json_1.default).catch((err) => {
        console.error(signale_1.default.error(err.message));
        process.exit(1);
    });
}
else {
    (0, update_check_1.default)(package_json_1.default);
    initApp().catch((err) => {
        console.error(signale_1.default.error(err.message));
        process.exit(1);
    });
}
